package fi.dy.masa.itemscroller.mixin.item;

import net.minecraft.class_1735;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1735.class)
public interface IMixinSlot
{
    @Accessor("index")
    int itemscroller_getSlotIndex();
}
