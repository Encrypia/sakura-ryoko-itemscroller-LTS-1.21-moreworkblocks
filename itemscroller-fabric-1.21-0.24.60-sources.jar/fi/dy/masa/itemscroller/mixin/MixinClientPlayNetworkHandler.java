package fi.dy.masa.itemscroller.mixin;

import fi.dy.masa.itemscroller.config.Configs;
import fi.dy.masa.itemscroller.config.Hotkeys;
import fi.dy.masa.itemscroller.event.KeybindCallbacks;
import fi.dy.masa.itemscroller.util.InventoryUtils;
import net.minecraft.class_2617;
import net.minecraft.class_2649;
import net.minecraft.class_2653;
import net.minecraft.class_2695;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class MixinClientPlayNetworkHandler
{
    @Inject(method = "onStatistics", at = @At("RETURN"), cancellable = true)
    private void onPong(class_2617 packet, CallbackInfo ci)
    {
        if (InventoryUtils.onPong(packet))
        {
            ci.cancel();
        }
    }

    @Inject(method = "onScreenHandlerSlotUpdate", at = @At("RETURN"))
    private void onScreenHandlerSlotUpdate(class_2653 packet, CallbackInfo ci)
    {
        KeybindCallbacks.getInstance().onPacket(packet);
    }

    @Inject(
            method = "onCraftFailedResponse",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/util/thread/ThreadExecutor;)V",
                    shift = At.Shift.AFTER
            ),
            cancellable = true
    )
    private void onCraftFailedResponse(class_2695 packet, CallbackInfo ci)
    {
        // todo
    }

    @Inject(
            method = "onInventory",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/util/thread/ThreadExecutor;)V",
                    shift = At.Shift.AFTER
            ),
            cancellable = true)
    private void onInventory(class_2649 packet, CallbackInfo ci)
    {
        if (InventoryUtils.bufferInvUpdates)
        {
            InventoryUtils.invUpdatesBuffer.add(packet);
            ci.cancel();
        }
    }

    @Inject(
            method = "onScreenHandlerSlotUpdate",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/util/thread/ThreadExecutor;)V",
                    shift = At.Shift.AFTER
            ),
            cancellable = true
    )
    private void onScreenHandlerSlotUpdateInvokeMainThread(class_2653 packet, CallbackInfo ci)
    {
        if (InventoryUtils.bufferInvUpdates)
        {
            InventoryUtils.invUpdatesBuffer.add(packet);
            ci.cancel();
        }
    }
}
