package fi.dy.masa.itemscroller.mixin.screen;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import fi.dy.masa.itemscroller.util.InventoryUtils;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1714;
import net.minecraft.class_1731;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_3955;
import net.minecraft.class_8566;
import net.minecraft.class_8786;

@Mixin(class_1714.class)
public abstract class MixinCraftingScreenHandler
{
    @Shadow @Final private class_8566 input;
    @Shadow @Final private net.minecraft.class_1731 result;
    @Shadow @Final private net.minecraft.class_1657 player;

    @Inject(method = "onContentChanged", at = @At("RETURN"))
    private void onSlotChangedCraftingGrid(net.minecraft.class_1263 inventory, CallbackInfo ci)
    {
        if (class_310.method_1551().method_18854())
        {
            InventoryUtils.onSlotChangedCraftingGrid(this.player, this.input, this.result);
        }
    }

    @Inject(method = "updateResult", at = @At("RETURN"))
    private static void onUpdateResult(
            class_1703 handler,
            class_1937 world,
            class_1657 player,
            class_8566 craftingInventory,
            class_1731 resultInv,
            class_8786<class_3955> recipeEntry, CallbackInfo ci)
    {
        if (class_310.method_1551().method_18854())
        {
            InventoryUtils.onSlotChangedCraftingGrid(player, craftingInventory, resultInv);
        }
    }
}
