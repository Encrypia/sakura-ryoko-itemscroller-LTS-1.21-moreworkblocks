package fi.dy.masa.itemscroller.mixin.screen;

import net.minecraft.class_492;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_492.class)
public interface IMixinMerchantScreen
{
    @Accessor("selectedIndex")
    int itemscroller_getSelectedMerchantRecipe();
}
