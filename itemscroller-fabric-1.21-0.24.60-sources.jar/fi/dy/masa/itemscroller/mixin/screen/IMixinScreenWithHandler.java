package fi.dy.masa.itemscroller.mixin.screen;

import net.minecraft.class_1735;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(net.minecraft.class_465.class)
public interface IMixinScreenWithHandler
{
    @Invoker("getSlotAt")
    class_1735 itemscroller_getSlotAtPositionInvoker(double x, double y);

    @Invoker("onMouseClick")
    void itemscroller_handleMouseClickInvoker(class_1735 slotIn, int slotId, int mouseButton, net.minecraft.class_1713 type);

    @Accessor("focusedSlot")
    class_1735 itemscroller_getHoveredSlot();

    @Accessor("x")
    int itemscroller_getGuiLeft();

    @Accessor("y")
    int itemscroller_getGuiTop();

    @Accessor("backgroundWidth")
    int itemscroller_getBackgroundWidth();

    @Accessor("backgroundHeight")
    int itemscroller_getBackgroundHeight();
}
