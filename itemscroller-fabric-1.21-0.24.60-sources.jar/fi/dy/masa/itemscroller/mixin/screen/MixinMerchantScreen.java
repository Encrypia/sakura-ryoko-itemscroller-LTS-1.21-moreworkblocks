package fi.dy.masa.itemscroller.mixin.screen;

import javax.annotation.Nullable;
import net.minecraft.class_1661;
import net.minecraft.class_1728;
import net.minecraft.class_1914;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_492;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import fi.dy.masa.itemscroller.config.Configs;
import fi.dy.masa.itemscroller.config.Hotkeys;
import fi.dy.masa.itemscroller.gui.ItemScrollerIcons;
import fi.dy.masa.itemscroller.util.InventoryUtils;
import fi.dy.masa.itemscroller.villager.FavoriteData;
import fi.dy.masa.itemscroller.villager.IMerchantScreenHandler;
import fi.dy.masa.itemscroller.villager.VillagerData;
import fi.dy.masa.itemscroller.villager.VillagerDataStorage;
import fi.dy.masa.itemscroller.villager.VillagerUtils;
import fi.dy.masa.malilib.gui.interfaces.IGuiIcon;
import fi.dy.masa.malilib.render.RenderUtils;

@Mixin(class_492.class)
public abstract class MixinMerchantScreen extends class_465<class_1728>
{
    @Unique @Nullable private FavoriteData favoriteData;
    @Shadow private int selectedIndex;
    @Shadow int indexStartOffset;
    @Unique private int indexStartOffsetLast = -1;

    @Shadow protected abstract boolean canScroll(int listSize);

    private MixinMerchantScreen(class_1728 handler, class_1661 inventory, class_2561 title)
    {
        super(handler, inventory, title);
    }

    @Inject(
            method = "render",
            at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screen/ingame/MerchantScreen;renderScrollbar(Lnet/minecraft/client/gui/DrawContext;IILnet/minecraft/village/TradeOfferList;)V")
    )
    private void fixRenderScrollBar(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci)
    {
        if (Configs.Toggles.VILLAGER_TRADE_FEATURES.getBooleanValue() &&
            Configs.Generic.VILLAGER_TRADE_LIST_REMEMBER_SCROLL.getBooleanValue())
        {
            VillagerData data = VillagerDataStorage.getInstance().getDataForLastInteractionTarget();
            int listSize = this.field_2797.method_17438().size();

            if (data != null && this.canScroll(listSize))
            {
                this.indexStartOffset = this.getClampedIndex(data.getTradeListPosition());
            }
        }
    }

    @Inject(method = "mouseScrolled", at = @At("RETURN"))
    private void onMouseScrollPost(double mouseX, double mouseY, double horizontalAmount, double verticalAmount, CallbackInfoReturnable<Boolean> cir)
    {
        if (Configs.Toggles.VILLAGER_TRADE_FEATURES.getBooleanValue() &&
            Configs.Generic.VILLAGER_TRADE_LIST_REMEMBER_SCROLL.getBooleanValue() &&
            this.indexStartOffsetLast != this.indexStartOffset)
        {
            int index = this.getClampedIndex(this.indexStartOffset);
            VillagerDataStorage.getInstance().setTradeListPosition(index);
            this.indexStartOffsetLast = index;
        }
    }

    @Inject(method = "mouseDragged", at = @At("RETURN"))
    private void onMouseDragPost(double mouseX, double mouseY, int button, double deltaX, double deltaY, CallbackInfoReturnable<Boolean> cir)
    {
        if (Configs.Toggles.VILLAGER_TRADE_FEATURES.getBooleanValue() &&
            Configs.Generic.VILLAGER_TRADE_LIST_REMEMBER_SCROLL.getBooleanValue() &&
            this.indexStartOffsetLast != this.indexStartOffset)
        {
            int index = this.getClampedIndex(this.indexStartOffset);
            VillagerDataStorage.getInstance().setTradeListPosition(index);
            this.indexStartOffsetLast = index;
        }
    }

    @Inject(method = "mouseClicked", at = @At("RETURN"), cancellable = true)
    private void onMouseClicked(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir)
    {
        if (Configs.Toggles.VILLAGER_TRADE_FEATURES.getBooleanValue())
        {
            int visibleIndex = this.getHoveredTradeButtonIndex(mouseX, mouseY);
            int realIndex = VillagerUtils.getRealTradeIndexFor(visibleIndex, this.field_2797);

            if (realIndex >= 0)
            {
                // right click, trade everything with this trade
                if (button == 1)
                {
                    InventoryUtils.villagerTradeEverythingPossibleWithTrade(visibleIndex);
                    cir.setReturnValue(true);
                }
                // Middle click, toggle trade favorite
                else if (button == 2)
                {
                    if (Hotkeys.MODIFIER_TOGGLE_VILLAGER_GLOBAL_FAVORITE.getKeybind().isKeybindHeld())
                    {
                        class_1914 trade = this.field_2797.method_17438().get(visibleIndex);
                        VillagerDataStorage.getInstance().toggleGlobalFavorite(trade);
                    }
                    else
                    {
                        VillagerDataStorage.getInstance().toggleFavorite(realIndex);
                    }

                    this.favoriteData = null; // Force a re-build of the list

                    // Rebuild the custom list based on the new favorites (See the Mixin for MerchantScreenHandler#setOffers())
                    this.field_2797.method_17437(((IMerchantScreenHandler) this.field_2797).itemscroller$getOriginalList());

                    cir.setReturnValue(true);
                }
            }
        }
    }

    @Inject(method = "syncRecipeIndex", at = @At("HEAD"), cancellable = true)
    private void fixRecipeIndex(CallbackInfo ci)
    {
        if (Configs.Toggles.VILLAGER_TRADE_FEATURES.getBooleanValue() &&
            this.method_17577() instanceof IMerchantScreenHandler)
        {
            if (VillagerUtils.switchToTradeByVisibleIndex(this.selectedIndex))
            {
                ci.cancel();
            }
        }
    }

    @Inject(method = "render", at = @At(value = "FIELD",
            target = "Lnet/minecraft/client/gui/screen/ingame/MerchantScreen;offers:[Lnet/minecraft/client/gui/screen/ingame/MerchantScreen$WidgetButtonPage;"))
    private void renderFavoriteMarker(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci)
    {
        if (Configs.Toggles.VILLAGER_TRADE_FEATURES.getBooleanValue())
        {
            FavoriteData favoriteData = this.favoriteData;

            if (favoriteData == null)
            {
                favoriteData = VillagerDataStorage.getInstance().getFavoritesForCurrentVillager(this.field_2797);
                this.favoriteData = favoriteData;
            }

            int numFavorites = favoriteData.favorites.size();

            if (numFavorites > 0 && this.indexStartOffset < numFavorites)
            {
                int screenX = (this.field_22789 - this.field_2792) / 2;
                int screenY = (this.field_22790 - this.field_2779) / 2;
                int buttonsStartX = screenX + 5;
                int buttonsStartY = screenY + 16 + 2;
                int x = buttonsStartX + 89 - 8;
                int y = buttonsStartY + 2;
                float z = 300;
                IGuiIcon icon = favoriteData.isGlobal ? ItemScrollerIcons.STAR_5_PURPLE : ItemScrollerIcons.STAR_5_YELLOW;

                for (int i = 0; i < (numFavorites - this.indexStartOffset); ++i)
                {
                    RenderUtils.bindTexture(icon.getTexture());
                    icon.renderAt(x, y, z, false, false);
                    y += 20;
                }
            }
        }
    }

    private int getClampedIndex(int index)
    {
        int listSize = this.field_2797.method_17438().size();
        return Math.max(0, Math.min(index, listSize - 7));
    }

    private int getHoveredTradeButtonIndex(double mouseX, double mouseY)
    {
        int screenX = (this.field_22789 - this.field_2792) / 2;
        int screenY = (this.field_22790 - this.field_2779) / 2;
        int buttonsStartX = screenX + 5;
        int buttonsStartY = screenY + 16 + 2;
        int buttonWidth = 89;
        int buttonHeight = 20;

        if (mouseX >= buttonsStartX && mouseX <= buttonsStartX + buttonWidth &&
            mouseY >= buttonsStartY && mouseY <= buttonsStartY + 7 * buttonHeight)
        {
            return this.indexStartOffset + (((int) mouseY - buttonsStartY) / buttonHeight);
        }

        return -1;
    }
}
