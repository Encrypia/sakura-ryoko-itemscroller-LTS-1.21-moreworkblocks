package fi.dy.masa.itemscroller.mixin.screen;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import fi.dy.masa.itemscroller.config.Configs;
import fi.dy.masa.itemscroller.villager.IMerchantScreenHandler;
import fi.dy.masa.itemscroller.villager.VillagerUtils;
import net.minecraft.class_1703;
import net.minecraft.class_1728;
import net.minecraft.class_1915;
import net.minecraft.class_1916;
import net.minecraft.class_3917;

@Mixin(class_1728.class)
public abstract class MixinMerchantScreenHandler extends class_1703 implements IMerchantScreenHandler
{
    @Shadow @Final private class_1915 merchant;
    @Unique @Nullable private class_1916 customList;

    protected MixinMerchantScreenHandler(@Nullable class_3917<?> type, int syncId)
    {
        super(type, syncId);
    }

    @Inject(method = "getRecipes", at = @At("HEAD"), cancellable = true)
    private void replaceTradeList(CallbackInfoReturnable<class_1916> cir)
    {
        if (Configs.Toggles.VILLAGER_TRADE_FEATURES.getBooleanValue() && this.customList != null)
        {
            cir.setReturnValue(this.customList);
        }
    }

    @Inject(method = "setOffers", at = @At("HEAD"))
    private void onTradeListSet(class_1916 offers, CallbackInfo ci)
    {
        if (Configs.Toggles.VILLAGER_TRADE_FEATURES.getBooleanValue())
        {
            this.customList = VillagerUtils.buildCustomTradeList(offers);
        }
    }

    @Override
    public class_1916 itemscroller$getOriginalList()
    {
        return this.merchant.method_8264();
    }
}
