package fi.dy.masa.itemscroller.mixin.screen;

import net.minecraft.class_342;
import net.minecraft.class_471;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_471.class)
public interface IMixinAnvilScreen
{
    @Accessor("nameField")
    class_342 itemscroller_getNameField();
}
