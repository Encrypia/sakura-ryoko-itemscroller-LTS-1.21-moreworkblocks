package fi.dy.masa.itemscroller.mixin.screen;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import fi.dy.masa.itemscroller.event.RenderEventHandler;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

@Mixin(class_437.class)
public abstract class MixinScreen
{
    @Inject(method = "renderWithTooltip", at = @At(value = "RETURN"))
    private void onDrawScreenPost(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci)
    {
        RenderEventHandler.instance().onDrawScreenPost(class_310.method_1551(), context);
    }
}
