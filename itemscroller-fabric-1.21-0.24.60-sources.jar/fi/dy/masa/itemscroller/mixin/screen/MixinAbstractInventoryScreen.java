package fi.dy.masa.itemscroller.mixin.screen;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import fi.dy.masa.itemscroller.util.InputUtils;
import net.minecraft.class_485;

@Mixin(class_485.class)
public abstract class MixinAbstractInventoryScreen
{
    @Inject(method = "drawStatusEffects", at = @At("HEAD"), cancellable = true)
    private void preventPotionEffectRendering(CallbackInfo ci)
    {
        if (InputUtils.isRecipeViewOpen())
        {
            ci.cancel();
        }
    }
}
