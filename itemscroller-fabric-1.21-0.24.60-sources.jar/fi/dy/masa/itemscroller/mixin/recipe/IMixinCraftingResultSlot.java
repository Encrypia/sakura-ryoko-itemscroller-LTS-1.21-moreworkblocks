package fi.dy.masa.itemscroller.mixin.recipe;

import net.minecraft.class_1734;
import net.minecraft.class_8566;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1734.class)
public interface IMixinCraftingResultSlot
{
    @Accessor("input")
    class_8566 itemscroller_getCraftingInventory();
}
