package fi.dy.masa.itemscroller.mixin.recipe;

import fi.dy.masa.itemscroller.util.InventoryUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1735;
import net.minecraft.class_505;
import net.minecraft.class_507;
import net.minecraft.class_8786;

@Mixin(class_507.class)
public class MixinRecipeBookWidget
{
    @Shadow @Final protected class_505 ghostSlots;

    @Inject(method = "slotClicked", at = @At("HEAD"), cancellable = true)
    private void onSlotClicked(class_1735 slot, CallbackInfo ci)
    {
        if (InventoryUtils.dontUpdateRecipeBook > 0)
        {
            ci.cancel();
        }
    }

    @Inject(method = "update", at = @At("HEAD"), cancellable = true)
    private void onUpdate(CallbackInfo ci)
    {
        if (InventoryUtils.dontUpdateRecipeBook > 0)
        {
            ci.cancel();
        }
    }

    // Seems to be (intended) bug from Mojang
    @Inject(
            method = "showGhostRecipe",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onShowGhostRecipe(class_8786<?> recipe, List<class_1735> slots, CallbackInfo ci) {
        if (this.ghostSlots.method_2566() == recipe) {
            ci.cancel();
        }
    }
}
