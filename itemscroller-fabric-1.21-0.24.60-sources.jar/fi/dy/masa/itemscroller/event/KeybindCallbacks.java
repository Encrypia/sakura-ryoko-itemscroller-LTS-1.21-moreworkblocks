package fi.dy.masa.itemscroller.event;

import fi.dy.masa.itemscroller.mixin.recipe.IMixinCraftingResultSlot;
import fi.dy.masa.malilib.config.options.ConfigHotkey;
import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.Message;
import fi.dy.masa.malilib.hotkeys.IHotkeyCallback;
import fi.dy.masa.malilib.hotkeys.IKeybind;
import fi.dy.masa.malilib.hotkeys.KeyAction;
import fi.dy.masa.malilib.hotkeys.KeyCallbackToggleBooleanConfigWithMessage;
import fi.dy.masa.malilib.interfaces.IClientTickHandler;
import fi.dy.masa.malilib.util.GuiUtils;
import fi.dy.masa.malilib.util.InfoUtils;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2653;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_8566;
import fi.dy.masa.itemscroller.ItemScroller;
import fi.dy.masa.itemscroller.config.Configs;
import fi.dy.masa.itemscroller.config.Hotkeys;
import fi.dy.masa.itemscroller.gui.GuiConfigs;
import fi.dy.masa.itemscroller.recipes.AbstractRecipePattern;
import fi.dy.masa.itemscroller.recipes.CraftingHandler;
import fi.dy.masa.itemscroller.recipes.RecipePattern;
import fi.dy.masa.itemscroller.recipes.RecipeStorage;
import fi.dy.masa.itemscroller.util.*;

public class KeybindCallbacks implements IHotkeyCallback, IClientTickHandler
{
    private static final KeybindCallbacks INSTANCE = new KeybindCallbacks();

    protected int massCraftTicker;

    private boolean recipeBookClicks = false;

    public static KeybindCallbacks getInstance()
    {
        return INSTANCE;
    }

    private KeybindCallbacks()
    {
    }

    public void setCallbacks()
    {
        for (ConfigHotkey hotkey : Hotkeys.HOTKEY_LIST)
        {
            hotkey.getKeybind().setCallback(this);
        }

        Hotkeys.MASS_CRAFT_TOGGLE.getKeybind().setCallback(new KeyCallbackToggleBooleanConfigWithMessage(Configs.Generic.MASS_CRAFT_HOLD));
    }

    public boolean functionalityEnabled()
    {
        return Configs.Generic.MOD_MAIN_TOGGLE.getBooleanValue();
    }

    @Override
    public boolean onKeyAction(KeyAction action, IKeybind key)
    {
        if (Configs.Generic.RATE_LIMIT_CLICK_PACKETS.getBooleanValue())
        {
            ClickPacketBuffer.setShouldBufferClickPackets(true);
        }

        boolean cancel = this.onKeyActionImpl(action, key);

        ClickPacketBuffer.setShouldBufferClickPackets(false);

        return cancel;
    }

    private boolean onKeyActionImpl(KeyAction action, IKeybind key)
    {
        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null || mc.field_1687 == null)
        {
            return false;
        }

        if (key == Hotkeys.TOGGLE_MOD_ON_OFF.getKeybind())
        {
            Configs.Generic.MOD_MAIN_TOGGLE.toggleBooleanValue();
            String msg = this.functionalityEnabled() ? "itemscroller.message.toggled_mod_on" : "itemscroller.message.toggled_mod_off";
            InfoUtils.showGuiOrInGameMessage(Message.MessageType.INFO, msg);
            return true;
        }
        else if (key == Hotkeys.OPEN_CONFIG_GUI.getKeybind())
        {
            GuiBase.openGui(new GuiConfigs());
            return true;
        }

        if (this.functionalityEnabled() == false ||
            (GuiUtils.getCurrentScreen() instanceof class_465) == false ||
            Configs.GUI_BLACKLIST.contains(GuiUtils.getCurrentScreen().getClass().getName()))
        {
            return false;
        }

        class_465<?> gui = (class_465<?>) GuiUtils.getCurrentScreen();
        class_1735 slot = AccessorUtils.getSlotUnderMouse(gui);
        RecipeStorage recipes = RecipeStorage.getInstance();
        MoveAction moveAction = InputUtils.getDragMoveAction(key);

        if (slot != null)
        {
            if (moveAction != MoveAction.NONE)
            {
                final int mouseX = fi.dy.masa.malilib.util.InputUtils.getMouseX();
                final int mouseY = fi.dy.masa.malilib.util.InputUtils.getMouseY();
                return InventoryUtils.dragMoveItems(gui, moveAction, mouseX, mouseY, true);
            }
            else if (key == Hotkeys.KEY_MOVE_EVERYTHING.getKeybind())
            {
                InventoryUtils.tryMoveStacks(slot, gui, false, true, false);
                return true;
            }
            else if (key == Hotkeys.DROP_ALL_MATCHING.getKeybind())
            {
                if (Configs.Toggles.DROP_MATCHING.getBooleanValue() &&
                    Configs.GUI_BLACKLIST.contains(gui.getClass().getName()) == false &&
                    slot.method_7681())
                {
                    InventoryUtils.dropStacks(gui, slot.method_7677(), slot, true);
                    return true;
                }
            }
        }

        if (key == Hotkeys.CRAFT_EVERYTHING.getKeybind())
        {
            InventoryUtils.craftEverythingPossibleWithCurrentRecipe(recipes.getSelectedRecipe(), gui);
            return true;
        }
        else if (key == Hotkeys.THROW_CRAFT_RESULTS.getKeybind())
        {
            InventoryUtils.throwAllCraftingResultsToGround(recipes.getSelectedRecipe(), gui);
            return true;
        }
        else if (key == Hotkeys.MOVE_CRAFT_RESULTS.getKeybind())
        {
            InventoryUtils.moveAllCraftingResultsToOtherInventory(recipes.getSelectedRecipe(), gui);
            return true;
        }
        else if (key == Hotkeys.STORE_RECIPE.getKeybind())
        {
            if (InputUtils.isRecipeViewOpen() && InventoryUtils.isCraftingSlot(gui, slot))
            {
                recipes.storeRecipeToCurrentSelection(slot, gui, true, true, mc);
                return true;
            }
        }
        else if (key == Hotkeys.VILLAGER_TRADE_FAVORITES.getKeybind())
        {
            return InventoryUtils.villagerTradeEverythingPossibleWithAllFavoritedTrades();
        }
        else if (key == Hotkeys.SLOT_DEBUG.getKeybind())
        {
            if (slot != null)
            {
                InventoryUtils.debugPrintSlotInfo(gui, slot);
            }
            else
            {
                ItemScroller.LOGGER.info("GUI class: {}", gui.getClass().getName());
            }

            return true;
        }
        else if (key == Hotkeys.SORT_INVENTORY.getKeybind())
        {
            if (Configs.Generic.SORT_INVENTORY_TOGGLE.getBooleanValue())
            {
                InventoryUtils.sortInventory(gui);
                return true;
            }
        }

        return false;
    }

    private static void debugPrintInv(class_8566 inv)
    {
        for (int i = 0; i < inv.method_17397(); i++)
        {
            for (int j = 0; j < inv.method_17398(); j++)
            {
                System.out.print(inv.method_5438(i * inv.method_17398() + j) + " ");
            }
            System.out.println();
        }
    }

    @Override
    public void onClientTick(class_310 mc)
    {
        if (InventoryUtils.dontUpdateRecipeBook > 0) {
            --InventoryUtils.dontUpdateRecipeBook;
        }
        if (this.functionalityEnabled() == false || mc.field_1724 == null)
        {
            return;
        }

        ClickPacketBuffer.sendBufferedPackets(Configs.Generic.PACKET_RATE_LIMIT.getIntegerValue());

        if (ClickPacketBuffer.shouldCancelWindowClicks())
        {
            return;
        }

        if (GuiUtils.getCurrentScreen() instanceof class_465<?> gui &&
            (GuiUtils.getCurrentScreen() instanceof class_481) == false &&
            Configs.GUI_BLACKLIST.contains(GuiUtils.getCurrentScreen().getClass().getName()) == false &&
            (Hotkeys.MASS_CRAFT.getKeybind().isKeybindHeld() || Configs.Generic.MASS_CRAFT_HOLD.getBooleanValue() ||
             // 切石机/铁砧/砂轮只支持按住 合成 - 正常合成 按钮批量合成
             (CraftingHandler.isProcessingGui(gui) && Hotkeys.CRAFT_EVERYTHING.getKeybind().isKeybindHeld())))
        {
            if (++this.massCraftTicker < Configs.Generic.MASS_CRAFT_INTERVAL.getIntegerValue())
            {
                return;
            }

            InventoryUtils.bufferInvUpdates = true;
            class_1735 outputSlot = CraftingHandler.getFirstOutputSlotForGui(gui);

            if (outputSlot != null)
            {
                if (Configs.Generic.RATE_LIMIT_CLICK_PACKETS.getBooleanValue())
                {
                    ClickPacketBuffer.setShouldBufferClickPackets(true);
                }

                AbstractRecipePattern recipe = RecipeStorage.getInstance().getSelectedRecipe();

                if (recipe instanceof RecipePattern craftingRecipe)
                {

                int limit = Configs.Generic.MASS_CRAFT_ITERATIONS.getIntegerValue();

                if (Configs.Generic.MASS_CRAFT_RECIPE_BOOK.getBooleanValue() && craftingRecipe.lookupVanillaRecipe(mc.field_1687) != null)
                {
                    InventoryUtils.dontUpdateRecipeBook = 2;
                    for (int i = 0; i < limit; ++i)
                    {
                        class_8566 craftingInv = ((IMixinCraftingResultSlot) outputSlot).itemscroller_getCraftingInventory();
                        if (!craftingRecipe.getVanillaRecipe().method_8115(craftingInv.method_59961(), mc.field_1687))
                        {
                            CraftingHandler.SlotRange range = CraftingHandler.getCraftingGridSlots(gui, outputSlot);
                            final int invSlots = gui.method_17577().field_7761.size();
                            final int rangeSlots = range.getSlotCount();

                            for (int j = 0, slotNum = range.getFirst(); j < rangeSlots && slotNum < invSlots; j++, slotNum++)
                            {
                                InventoryUtils.shiftClickSlot(gui, slotNum);

                                class_1735 slotTmp = gui.method_17577().method_7611(slotNum);
                                class_1799 stack = slotTmp.method_7677();
                                if (!stack.method_7960())
                                {
                                    InventoryUtils.dropStack(gui, slotNum);
                                }
                            }
                        }

                        mc.field_1761.method_2912(gui.method_17577().field_7763, craftingRecipe.getVanillaRecipeEntry(), true);

                        craftingInv = ((IMixinCraftingResultSlot) outputSlot).itemscroller_getCraftingInventory();
                        if (craftingRecipe.getVanillaRecipe().method_8115(craftingInv.method_59961(), mc.field_1687))
                        {
                            break;
                        }

                        InventoryUtils.shiftClickSlot(gui, outputSlot.field_7874);

                        for (int k = 0; k < craftingRecipe.getResult().method_7914(); k++)
                        {
                            InventoryUtils.dropStack(gui, outputSlot.field_7874);
                        }

                        recipeBookClicks = true;
                    }

                    InventoryUtils.tryClearCursor(gui);
                    InventoryUtils.throwAllCraftingResultsToGround(craftingRecipe, gui);
                }
                else if (Configs.Generic.MASS_CRAFT_SWAPS.getBooleanValue())
                {
                    for (int i = 0; i < limit; ++i)
                    {
                        InventoryUtils.tryClearCursor(gui);
                        InventoryUtils.setInhibitCraftingOutputUpdate(true);
                        InventoryUtils.throwAllCraftingResultsToGround(craftingRecipe, gui);
                        InventoryUtils.throwAllNonRecipeItemsToGround(craftingRecipe, gui);
                        class_8566 inv = ((IMixinCraftingResultSlot) (outputSlot)).itemscroller_getCraftingInventory();
                        try
                        {
                            Thread.sleep(0);
                        }
                        catch (InterruptedException ignored) { }
                        InventoryUtils.setCraftingGridContentsUsingSwaps(gui, mc.field_1724.method_31548(), craftingRecipe, outputSlot);
                        InventoryUtils.setInhibitCraftingOutputUpdate(false);
                        InventoryUtils.updateCraftingOutputSlot(outputSlot);

                        if (InventoryUtils.areStacksEqual(outputSlot.method_7677(), craftingRecipe.getResult()) == false)
                        {
                            break;
                        }

                        InventoryUtils.shiftClickSlot(gui, outputSlot.field_7874);
                    }
                }
                else
                {
                    int failsafe = 0;

                    while (++failsafe < limit)
                    {
                        InventoryUtils.tryClearCursor(gui);
                        InventoryUtils.setInhibitCraftingOutputUpdate(true);
                        InventoryUtils.throwAllCraftingResultsToGround(craftingRecipe, gui);
                        InventoryUtils.throwAllNonRecipeItemsToGround(craftingRecipe, gui);
                        InventoryUtils.tryMoveItemsToFirstCraftingGrid(craftingRecipe, gui, true);
                        InventoryUtils.setInhibitCraftingOutputUpdate(false);
                        InventoryUtils.updateCraftingOutputSlot(outputSlot);

                        if (InventoryUtils.areStacksEqual(outputSlot.method_7677(), craftingRecipe.getResult()) == false)
                        {
                            break;
                        }

                        if (Configs.Generic.CARPET_CTRL_Q_CRAFTING.getBooleanValue())
                        {
                            InventoryUtils.dropStack(gui, outputSlot.field_7874);
                        }
                        else
                        {
                            InventoryUtils.dropStacksWhileHasItem(gui, outputSlot.field_7874, craftingRecipe.getResult());
                        }
                    }
                }
                }
                else
                {
                    class_1735 slot = recipe.getOutputSlot(gui);
                    if (slot != null)
                    {
                        recipe.fillInputs(gui, true, slot);
                    }
                    recipe.craftAsManyAsPossible(gui);
                }

                ClickPacketBuffer.setShouldBufferClickPackets(false);
            }

            this.massCraftTicker = 0;
            InventoryUtils.bufferInvUpdates = false;
            InventoryUtils.invUpdatesBuffer.removeIf(packet -> {
                packet.method_11054(mc.method_1562());
                return true;
            });
        }
    }

    public void onPacket(class_2653 packet)
    {
        var mc = class_310.method_1551();
    }
}
