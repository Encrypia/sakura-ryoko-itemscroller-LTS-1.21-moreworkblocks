package fi.dy.masa.itemscroller.event;

import org.joml.Matrix4fStack;
import com.mojang.blaze3d.systems.RenderSystem;
import fi.dy.masa.malilib.render.InventoryOverlay;
import fi.dy.masa.malilib.render.RenderUtils;
import fi.dy.masa.malilib.util.GuiUtils;
import fi.dy.masa.malilib.util.StringUtils;
import net.minecraft.class_1799;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import fi.dy.masa.itemscroller.config.Configs;
import fi.dy.masa.itemscroller.recipes.AbstractRecipePattern;
import fi.dy.masa.itemscroller.recipes.RecipePattern;
import fi.dy.masa.itemscroller.recipes.RecipeStorage;
import fi.dy.masa.itemscroller.util.AccessorUtils;
import fi.dy.masa.itemscroller.util.ClickPacketBuffer;
import fi.dy.masa.itemscroller.util.InputUtils;
import fi.dy.masa.itemscroller.util.InventoryUtils;

public class RenderEventHandler
{
    private static final RenderEventHandler INSTANCE = new RenderEventHandler();

    private final class_310 mc = class_310.method_1551();
    private int recipeListX;
    private int recipeListY;
    private int recipesPerColumn;
    private int columnWidth;
    private int columns;
    private int numberTextWidth;
    private int gapColumn;
    private int entryHeight;
    private double scale;

    public static RenderEventHandler instance()
    {
        return INSTANCE;
    }

    public void renderRecipeView(class_332 drawContext)
    {
        if (GuiUtils.getCurrentScreen() instanceof class_465<?> gui && InputUtils.isRecipeViewOpen())
        {
            RecipeStorage recipes = RecipeStorage.getInstance();
            final int first = recipes.getFirstVisibleRecipeId();
            final int countPerPage = recipes.getRecipeCountPerPage();
            final int lastOnPage = first + countPerPage - 1;

            this.calculateRecipePositions(gui);

            Matrix4fStack matrix4fStack = RenderSystem.getModelViewStack();
            matrix4fStack.pushMatrix();
            matrix4fStack.translate(this.recipeListX, this.recipeListY, 0);
            matrix4fStack.scale((float) this.scale, (float) this.scale, 1);

            String str = StringUtils.translate("itemscroller.gui.label.recipe_page", (first / countPerPage) + 1, recipes.getTotalRecipeCount() / countPerPage);

            drawContext.method_51433(this.mc.field_1772, str, 16, -12, 0xC0C0C0C0, false);

            for (int i = 0, recipeId = first; recipeId <= lastOnPage; ++i, ++recipeId)
            {
                class_1799 stack = recipes.getRecipe(recipeId).getResult();
                boolean selected = recipeId == recipes.getSelection();
                int row = i % this.recipesPerColumn;
                int column = i / this.recipesPerColumn;

                this.renderStoredRecipeStack(stack, recipeId, row, column, gui, selected, drawContext);
            }

            if (Configs.Generic.CRAFTING_RENDER_RECIPE_ITEMS.getBooleanValue())
            {
                final int mouseX = fi.dy.masa.malilib.util.InputUtils.getMouseX();
                final int mouseY = fi.dy.masa.malilib.util.InputUtils.getMouseY();
                final int recipeId = this.getHoveredRecipeId(mouseX, mouseY, recipes, gui);
                AbstractRecipePattern recipe = recipeId >= 0 ? recipes.getRecipe(recipeId) : recipes.getSelectedRecipe();

                if (recipe instanceof RecipePattern craftingRecipe)
                {
                    this.renderRecipeItems(craftingRecipe, recipes.getRecipeCountPerPage(), gui, drawContext);
                }
            }

            matrix4fStack.popMatrix();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.enableBlend(); // Fixes the crafting book icon rendering
        }
    }

    public void onDrawScreenPost(class_310 mc, class_332 drawContext)
    {
        this.renderRecipeView(drawContext);

        if (GuiUtils.getCurrentScreen() instanceof class_465)
        {
            class_465<?> gui = (class_465<?>) this.mc.field_1755;

            int bufferedCount = ClickPacketBuffer.getBufferedActionsCount();

            if (bufferedCount > 0)
            {
                drawContext.method_51433(mc.field_1772, "Buffered slot clicks: " + bufferedCount, 10, 10, 0xFFD0D0D0, false);
            }

            if (InputUtils.isRecipeViewOpen() == false)
            {
                return;
            }

            RecipeStorage recipes = RecipeStorage.getInstance();

            final int mouseX = fi.dy.masa.malilib.util.InputUtils.getMouseX();
            final int mouseY = fi.dy.masa.malilib.util.InputUtils.getMouseY();
            final int recipeId = this.getHoveredRecipeId(mouseX, mouseY, recipes, gui);

            float offset = 300f;
            Matrix4fStack matrix4fStack = RenderSystem.getModelViewStack();
            matrix4fStack.pushMatrix();
            matrix4fStack.translate(0, 0, offset);

            if (recipeId >= 0)
            {
                AbstractRecipePattern recipe = recipes.getRecipe(recipeId);
                if (recipe instanceof RecipePattern craftingRecipe)
                {
                    this.renderHoverTooltip(mouseX, mouseY, craftingRecipe, gui, drawContext);
                }
            }
            else if (Configs.Generic.CRAFTING_RENDER_RECIPE_ITEMS.getBooleanValue())
            {
                AbstractRecipePattern recipe = recipes.getSelectedRecipe();
                if (recipe instanceof RecipePattern craftingRecipe)
                {
                    class_1799 stack = this.getHoveredRecipeIngredient(mouseX, mouseY, craftingRecipe, recipes.getRecipeCountPerPage(), gui);

                    if (InventoryUtils.isStackEmpty(stack) == false)
                    {
                        InventoryOverlay.renderStackToolTip(mouseX, mouseY, stack, this.mc, drawContext);
                    }
                }
            }

            matrix4fStack.popMatrix();
            RenderSystem.applyModelViewMatrix();
        }
    }

    private void calculateRecipePositions(class_465<?> gui)
    {
        RecipeStorage recipes = RecipeStorage.getInstance();
        final int gapHorizontal = 2;
        final int gapVertical = 2;
        final int stackBaseHeight = 16;
        final int guiLeft = AccessorUtils.getGuiLeft(gui);

        this.recipesPerColumn = 9;
        this.columns = (int) Math.ceil((double) recipes.getRecipeCountPerPage() / (double) this.recipesPerColumn);
        this.numberTextWidth = 12;
        this.gapColumn = 4;

        int usableHeight = GuiUtils.getScaledWindowHeight();
        int usableWidth = guiLeft;
        // Scale the maximum stack size by taking into account the relative gap size
        double gapScaleVertical = (1D - (double) gapVertical / (double) (stackBaseHeight + gapVertical));
        // the +1.2 is for the gap and page text height on the top and bottom
        int maxStackDimensionsVertical = (int) ((usableHeight / ((double) this.recipesPerColumn + 1.2)) * gapScaleVertical);
        // assume a maximum of 3x3 recipe size for now... thus columns + 3 stacks rendered horizontally
        double gapScaleHorizontal = (1D - (double) gapHorizontal / (double) (stackBaseHeight + gapHorizontal));
        int maxStackDimensionsHorizontal = (int) (((usableWidth - (this.columns * (this.numberTextWidth + this.gapColumn))) / (this.columns + 3 + 0.8)) * gapScaleHorizontal);
        int stackDimensions = (int) Math.min(maxStackDimensionsVertical, maxStackDimensionsHorizontal);

        this.scale = (double) stackDimensions / (double) stackBaseHeight;
        this.entryHeight = stackBaseHeight + gapVertical;
        this.recipeListX = guiLeft - (int) ((this.columns * (stackBaseHeight + this.numberTextWidth + this.gapColumn) + gapHorizontal) * this.scale);
        this.recipeListY = (int) (this.entryHeight * this.scale);
        this.columnWidth = stackBaseHeight + this.numberTextWidth + this.gapColumn;
    }

    private void renderHoverTooltip(int mouseX, int mouseY, RecipePattern recipe, class_465<?> gui, class_332 drawContext)
    {
        class_1799 stack = recipe.getResult();

        if (InventoryUtils.isStackEmpty(stack) == false)
        {
            InventoryOverlay.renderStackToolTip(mouseX, mouseY, stack, this.mc, drawContext);
        }
    }

    public int getHoveredRecipeId(int mouseX, int mouseY, RecipeStorage recipes, class_465<?> gui)
    {
        if (InputUtils.isRecipeViewOpen())
        {
            this.calculateRecipePositions(gui);
            final int stackDimensions = (int) (16 * this.scale);

            for (int column = 0; column < this.columns; ++column)
            {
                int startX = this.recipeListX + (int) ((column * this.columnWidth + this.gapColumn + this.numberTextWidth) * this.scale);

                if (mouseX >= startX && mouseX <= startX + stackDimensions)
                {
                    for (int row = 0; row < this.recipesPerColumn; ++row)
                    {
                        int startY = this.recipeListY + (int) (row * this.entryHeight * this.scale);

                        if (mouseY >= startY && mouseY <= startY + stackDimensions)
                        {
                            return recipes.getFirstVisibleRecipeId() + column * this.recipesPerColumn + row;
                        }
                    }
                }
            }
        }

        return -1;
    }

    private void renderStoredRecipeStack(class_1799 stack, int recipeId, int row, int column, class_465<?> gui,
            boolean selected, class_332 drawContext)
    {
        final class_327 font = this.mc.field_1772;
        final String indexStr = String.valueOf(recipeId + 1);

        int x = column * this.columnWidth + this.gapColumn + this.numberTextWidth;
        int y = row * this.entryHeight;
        this.renderStackAt(stack, x, y, selected, drawContext);

        float scale = 0.75F;
        x = x - (int) (font.method_1727(indexStr) * scale) - 2;
        y = row * this.entryHeight + this.entryHeight / 2 - font.field_2000 / 2;

        // TODO DrawContext still uses the MatrixStack type
        class_4587 matrixStack = drawContext.method_51448();
        matrixStack.method_22903();
        matrixStack.method_46416(x, y, 0);
        matrixStack.method_22905(scale, scale, 1);

        drawContext.method_51433(font, indexStr, 0, 0, 0xFFC0C0C0, false);

        matrixStack.method_22909();
    }

    private void renderRecipeItems(RecipePattern recipe, int recipeCountPerPage, class_465<?> gui, class_332 drawContext)
    {
        class_1799[] items = recipe.getRecipeItems();
        final int recipeDimensions = (int) Math.ceil(Math.sqrt(recipe.getRecipeLength()));
        int x = -3 * 17 + 2;
        int y = 3 * this.entryHeight;

        for (int i = 0, row = 0; row < recipeDimensions; row++)
        {
            for (int col = 0; col < recipeDimensions; col++, i++)
            {
                int xOff = col * 17;
                int yOff = row * 17;

                this.renderStackAt(items[i], x + xOff, y + yOff, false, drawContext);
            }
        }
    }

    private class_1799 getHoveredRecipeIngredient(int mouseX, int mouseY, RecipePattern recipe, int recipeCountPerPage, class_465<?> gui)
    {
        final int recipeDimensions = (int) Math.ceil(Math.sqrt(recipe.getRecipeLength()));
        int scaledStackDimensions = (int) (16 * this.scale);
        int scaledGridEntry = (int) (17 * this.scale);
        int x = this.recipeListX - (int) ((3 * 17 - 2) * this.scale);
        int y = this.recipeListY + (int) (3 * this.entryHeight * this.scale);

        if (mouseX >= x && mouseX <= x + recipeDimensions * scaledGridEntry &&
            mouseY >= y && mouseY <= y + recipeDimensions * scaledGridEntry)
        {
            for (int i = 0, row = 0; row < recipeDimensions; row++)
            {
                for (int col = 0; col < recipeDimensions; col++, i++)
                {
                    int xOff = col * scaledGridEntry;
                    int yOff = row * scaledGridEntry;
                    int xStart = x + xOff;
                    int yStart = y + yOff;

                    if (mouseX >= xStart && mouseX < xStart + scaledStackDimensions &&
                        mouseY >= yStart && mouseY < yStart + scaledStackDimensions)
                    {
                        return recipe.getRecipeItems()[i];
                    }
                }
            }
        }

        return class_1799.field_8037;
    }

    private void renderStackAt(class_1799 stack, int x, int y, boolean border, class_332 drawContext)
    {
        final int w = 16;

        if (border)
        {
            // Draw a light/white border around the stack
            RenderUtils.drawOutline(x - 1, y - 1, w + 2, w + 2, 0xFFFFFFFF);
        }

        RenderUtils.drawRect(x, y, w, w, 0x20FFFFFF); // light background for the item

        if (InventoryUtils.isStackEmpty(stack) == false)
        {
            class_308.method_24211();

            stack = stack.method_7972();
            InventoryUtils.setStackSize(stack, 1);

            // TODO DrawContext still uses the MatrixStack type
            class_4587 matrixStack = drawContext.method_51448();
            matrixStack.method_22903();
            matrixStack.method_46416(0, 0, 100.f);

            drawContext.method_51427(stack, x, y);

            matrixStack.method_22909();
        }
    }

    /*
    public static void enableGUIStandardItemLighting(float scale)
    {
        RenderSystem.pushMatrix();
        RenderSystem.rotatef(-30.0F, 0.0F, 1.0F, 0.0F);
        RenderSystem.rotatef(165.0F, 1.0F, 0.0F, 0.0F);

        enableStandardItemLighting(scale);

        RenderSystem.popMatrix();
    }

    public static void enableStandardItemLighting(float scale)
    {
        RenderSystem.enableLighting();
        GlStateManager.enableLight(0);
        GlStateManager.enableLight(1);
        RenderSystem.enableColorMaterial();
        RenderSystem.colorMaterial(1032, 5634);

        float lightStrength = 0.3F * scale;
        float ambientLightStrength = 0.4F;

        GlStateManager.light(16384, 4611, singletonBuffer((float) LIGHT0_POS.x, (float) LIGHT0_POS.y, (float) LIGHT0_POS.z, 0.0f));
        GlStateManager.light(16384, 4609, singletonBuffer(lightStrength, lightStrength, lightStrength, 1.0F));
        GlStateManager.light(16384, 4608, singletonBuffer(0.0F, 0.0F, 0.0F, 1.0F));
        GlStateManager.light(16384, 4610, singletonBuffer(0.0F, 0.0F, 0.0F, 1.0F));

        GlStateManager.light(16385, 4611, singletonBuffer((float) LIGHT1_POS.x, (float) LIGHT1_POS.y, (float) LIGHT1_POS.z, 0.0f));
        GlStateManager.light(16385, 4609, singletonBuffer(lightStrength, lightStrength, lightStrength, 1.0F));
        GlStateManager.light(16385, 4608, singletonBuffer(0.0F, 0.0F, 0.0F, 1.0F));
        GlStateManager.light(16385, 4610, singletonBuffer(0.0F, 0.0F, 0.0F, 1.0F));

        RenderSystem.shadeModel(GL11.GL_FLAT);

        GlStateManager.lightModel(2899, singletonBuffer(ambientLightStrength, ambientLightStrength, ambientLightStrength, 1.0F));
    }

    private static FloatBuffer singletonBuffer(float val1, float val2, float val3, float val4)
    {
        FLOAT_BUFFER.clear();
        FLOAT_BUFFER.put(val1).put(val2).put(val3).put(val4);
        FLOAT_BUFFER.flip();

        return FLOAT_BUFFER;
    }
    */
}
