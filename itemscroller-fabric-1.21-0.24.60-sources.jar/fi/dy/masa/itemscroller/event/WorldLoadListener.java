package fi.dy.masa.itemscroller.event;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_638;
import fi.dy.masa.malilib.interfaces.IWorldLoadListener;
import fi.dy.masa.itemscroller.config.Configs;
import fi.dy.masa.itemscroller.recipes.RecipeStorage;
import fi.dy.masa.itemscroller.util.ClickPacketBuffer;
import fi.dy.masa.itemscroller.villager.VillagerDataStorage;

public class WorldLoadListener implements IWorldLoadListener
{
    @Override
    public void onWorldLoadPre(@Nullable class_638 worldBefore, @Nullable class_638 worldAfter, class_310 mc)
    {
        // Quitting to main menu, save the settings before the integrated server gets shut down
        if (worldBefore != null && worldAfter == null)
        {
            this.writeData(worldBefore.method_30349());
            VillagerDataStorage.getInstance().writeToDisk();
        }
    }

    @Override
    public void onWorldLoadPost(@Nullable class_638 worldBefore, @Nullable class_638 worldAfter, class_310 mc)
    {
        RecipeStorage.getInstance().reset(worldAfter == null);

        // Logging in to a world, load the data
        if (worldBefore == null && worldAfter != null)
        {
            this.readStoredData(worldAfter.method_30349());
            VillagerDataStorage.getInstance().readFromDisk();
        }

        // Logging out
        if (worldAfter == null)
        {
            ClickPacketBuffer.reset();
        }
    }

    private void writeData(@Nonnull class_5455 registryManager)
    {
        if (Configs.Generic.SCROLL_CRAFT_STORE_RECIPES_TO_FILE.getBooleanValue())
        {
            RecipeStorage.getInstance().writeToDisk(registryManager);
        }
    }

    private void readStoredData(@Nonnull class_5455 registryManager)
    {
        if (Configs.Generic.SCROLL_CRAFT_STORE_RECIPES_TO_FILE.getBooleanValue())
        {
            RecipeStorage.getInstance().readFromDisk(registryManager);
        }
    }
}
