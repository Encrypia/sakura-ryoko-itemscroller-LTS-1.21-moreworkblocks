package fi.dy.masa.itemscroller.villager;

import net.minecraft.class_1916;

public interface IMerchantScreenHandler
{
    class_1916 itemscroller$getOriginalList();
}
