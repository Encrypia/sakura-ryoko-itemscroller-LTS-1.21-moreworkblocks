package fi.dy.masa.itemscroller.villager;

import javax.annotation.Nullable;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class TradeType
{
    public final class_1792 buyItem1;
    public final class_1792 buyItem2;
    public final class_1792 sellItem;

    public TradeType(class_1792 buyItem1, class_1792 buyItem2, class_1792 sellItem)
    {
        this.buyItem1 = buyItem1;
        this.buyItem2 = buyItem2;
        this.sellItem = sellItem;
    }

    public boolean matchesTrade(class_1914 trade)
    {
        class_1799 stackBuyItem1 = trade.method_8246();
        class_1799 stackBuyItem2 = trade.method_8247();
        class_1799 stackSellItem = trade.method_8250();
        class_1792 buyItem1 = stackBuyItem1.method_7909();
        class_1792 buyItem2 = stackBuyItem2.method_7909();
        class_1792 sellItem = stackSellItem.method_7909();

        return this.buyItem1 == buyItem1 && this.buyItem2 == buyItem2 && this.sellItem == sellItem;
    }

    public class_2487 toTag()
    {
        class_2487 tag = new class_2487();

        tag.method_10582("Buy1", getNameForItem(this.buyItem1));
        tag.method_10582("Buy2", getNameForItem(this.buyItem2));
        tag.method_10582("Sell", getNameForItem(this.sellItem));

        return tag;
    }

    @Nullable
    public static TradeType fromTag(class_2487 tag)
    {
        class_1792 buy1 = getItemForName(tag.method_10558("Buy1"));
        class_1792 buy2 = getItemForName(tag.method_10558("Buy2"));
        class_1792 sell = getItemForName(tag.method_10558("Sell"));

        if (buy1 != class_1802.field_8162 || buy2 != class_1802.field_8162 || sell != class_1802.field_8162)
        {
            return new TradeType(buy1, buy2, sell);
        }

        return null;
    }

    public static class_1792 getItemForName(String name)
    {
        try
        {
            class_2960 id = class_2960.method_12829(name);
            return class_7923.field_41178.method_10223(id);
        }
        catch (Exception e)
        {
            return class_1802.field_8162;
        }
    }

    public static String getNameForItem(class_1792 item)
    {
        try
        {
            return class_7923.field_41178.method_10221(item).toString();
        }
        catch (Exception e)
        {
            return "?";
        }
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }

        TradeType tradeType = (TradeType) o;

        if (!buyItem1.equals(tradeType.buyItem1)) { return false; }
        if (!buyItem2.equals(tradeType.buyItem2)) { return false; }
        return sellItem.equals(tradeType.sellItem);
    }

    @Override
    public int hashCode()
    {
        int result = buyItem1.hashCode();
        result = 31 * result + buyItem2.hashCode();
        result = 31 * result + sellItem.hashCode();
        return result;
    }

    public static TradeType of(class_1914 trade)
    {
        class_1799 stackBuyItem1 = trade.method_8246();
        class_1799 stackBuyItem2 = trade.method_8247();
        class_1799 stackSellItem = trade.method_8250();
        class_1792 buyItem1 = stackBuyItem1.method_7909();
        class_1792 buyItem2 = stackBuyItem2.method_7909();
        class_1792 sellItem = stackSellItem.method_7909();

        return new TradeType(buyItem1, buyItem2, sellItem);
    }
}
