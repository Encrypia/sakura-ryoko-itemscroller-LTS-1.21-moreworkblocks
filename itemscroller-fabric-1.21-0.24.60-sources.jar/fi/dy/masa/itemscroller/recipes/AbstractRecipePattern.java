package fi.dy.masa.itemscroller.recipes;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_5455;
import fi.dy.masa.itemscroller.util.InventoryUtils;

public abstract class AbstractRecipePattern
{
    public enum RecipeType
    {
        CRAFTING("crafting"),
        STONECUTTER("stonecutter"),
        ANVIL("anvil"),
        GRINDSTONE("grindstone");

        private final String id;

        RecipeType(String id) { this.id = id; }
        public String getId() { return this.id; }

        @Nullable
        public static RecipeType fromId(String id)
        {
            for (RecipeType t : values())
            {
                if (t.id.equals(id)) return t;
            }
            return null;
        }
    }

    protected class_1799 result = InventoryUtils.EMPTY_STACK;

    public abstract RecipeType getType();

    public abstract void clearRecipe();

    public abstract boolean isEmpty();

    public abstract void storeRecipe(class_1735 slot, class_465<? extends class_1703> gui,
                                     boolean clearIfEmpty, boolean fromKeybind, class_310 mc);

    public abstract void readFromNBT(@Nonnull class_2487 nbt, @Nonnull class_5455 registryManager);

    @Nonnull
    public abstract class_2487 writeToNBT(@Nonnull class_5455 registryManager);

    public class_1799 getResult()
    {
        return this.result.method_7960() ? InventoryUtils.EMPTY_STACK : this.result;
    }

    public boolean isValid()
    {
        return InventoryUtils.isStackEmpty(this.getResult()) == false;
    }

    @Nullable
    public class_1735 getOutputSlot(class_465<? extends class_1703> gui)
    {
        return null;
    }

    public boolean canCraft(class_465<? extends class_1703> gui)
    {
        return this.isValid() && this.getOutputSlot(gui) != null;
    }

    public void fillInputs(class_465<? extends class_1703> gui, boolean fillStacks, class_1735 craftingOutputSlot)
    {
    }

    public void clearInputs(class_465<? extends class_1703> gui)
    {
    }

    public void craftAsManyAsPossible(class_465<? extends class_1703> gui)
    {
        class_1735 outputSlot = this.getOutputSlot(gui);
        if (outputSlot == null || this.isValid() == false) return;

        class_1799 resultStack = this.getResult();
        int failSafe = 1024;

        while (failSafe > 0 && outputSlot.method_7681() &&
                InventoryUtils.areStacksEqual(outputSlot.method_7677(), resultStack))
        {
            InventoryUtils.shiftClickSlot(gui, outputSlot.field_7874);

            if (outputSlot.method_7681() == false ||
                InventoryUtils.areStacksEqual(outputSlot.method_7677(), resultStack) == false)
            {
                this.fillInputs(gui, true, outputSlot);
            }
            else
            {
                break;
            }

            failSafe--;
        }
    }

    public void craftEverything(class_465<? extends class_1703> gui)
    {
        class_1735 outputSlot = this.getOutputSlot(gui);
        if (outputSlot == null || this.isValid() == false) return;

        this.clearInputs(gui);
        this.fillInputs(gui, true, outputSlot);

        if (outputSlot.method_7681())
        {
            this.craftAsManyAsPossible(gui);
        }
    }

    public void throwResults(class_465<? extends class_1703> gui)
    {
        class_1735 outputSlot = this.getOutputSlot(gui);
        if (outputSlot != null && this.isValid())
        {
            InventoryUtils.dropStacks(gui, this.getResult(), outputSlot, false);
        }
    }

}
