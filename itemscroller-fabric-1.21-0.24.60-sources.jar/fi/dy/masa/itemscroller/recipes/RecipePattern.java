package fi.dy.masa.itemscroller.recipes;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_310;
import net.minecraft.class_3955;
import net.minecraft.class_465;
import net.minecraft.class_5455;
import net.minecraft.class_8786;
import net.minecraft.class_9694;
import net.minecraft.class_9695;
import java.util.Arrays;
import fi.dy.masa.itemscroller.recipes.CraftingHandler.SlotRange;
import fi.dy.masa.itemscroller.util.Constants;
import fi.dy.masa.itemscroller.util.InventoryUtils;

public class RecipePattern extends AbstractRecipePattern
{
    private class_1799[] recipe = new class_1799[9];
    private class_8786<?> vanillaRecipe;

    public RecipePattern()
    {
        super();
        this.ensureRecipeSizeAndClearRecipe(9);
    }

    @Override
    public AbstractRecipePattern.RecipeType getType()
    {
        return AbstractRecipePattern.RecipeType.CRAFTING;
    }

    public void ensureRecipeSize(int size)
    {
        if (this.getRecipeLength() != size)
        {
            this.recipe = new class_1799[size];
        }
    }

    @Override
    public void clearRecipe()
    {
        Arrays.fill(this.recipe, InventoryUtils.EMPTY_STACK);
        this.result = InventoryUtils.EMPTY_STACK;
        this.vanillaRecipe = null;
    }

    public void ensureRecipeSizeAndClearRecipe(int size)
    {
        this.ensureRecipeSize(size);
        this.clearRecipe();
    }

    @SuppressWarnings("unchecked")
    @Nullable
    public <T extends class_9695> class_1860<T> lookupVanillaRecipe(class_1937 world) {
        //Assume all recipes here are of type CraftingRecipe
        this.vanillaRecipe = null;
        var mc = class_310.method_1551();
        int recipeSize;
        if (recipe.length == 4)
        {
            recipeSize = 2;
        }
        else if (recipe.length == 9)
        {
            recipeSize = 3;
        }
        else
        {
            return null;
        }

        for (class_8786<class_3955> match : mc.field_1687.method_8433().method_17877(net.minecraft.class_3956.field_17545, class_9694.method_59986(recipeSize, recipeSize, Arrays.asList(recipe)), world))
        {
            if (InventoryUtils.areStacksEqual(result, match.comp_1933().method_8110(world.method_30349())))
            {
                this.vanillaRecipe = match;
                return (class_1860<T>) match.comp_1933();
            }
        }
        return null;
    }

    @Override
    public void storeRecipe(class_1735 slot, class_465<? extends class_1703> gui, boolean clearIfEmpty, boolean fromKeybind, class_310 mc)
    {
        SlotRange range = CraftingHandler.getCraftingGridSlots(gui, slot);

        if (range != null)
        {
            if (slot.method_7681())
            {
                int gridSize = range.getSlotCount();
                int numSlots = gui.method_17577().field_7761.size();

                this.ensureRecipeSizeAndClearRecipe(gridSize);

                for (int i = 0, s = range.getFirst(); i < gridSize && s < numSlots; i++, s++)
                {
                    class_1735 slotTmp = gui.method_17577().method_7611(s);
                    this.recipe[i] = slotTmp.method_7681() ? slotTmp.method_7677().method_7972() : InventoryUtils.EMPTY_STACK;
                }

                this.result = slot.method_7677().method_7972();
                this.lookupVanillaRecipe(class_310.method_1551().field_1687);
            }
            else if (clearIfEmpty)
            {
                this.clearRecipe();
            }
        }
    }

    public void copyRecipeFrom(RecipePattern other)
    {
        int size = other.getRecipeLength();
        class_1799[] otherRecipe = other.getRecipeItems();

        this.ensureRecipeSizeAndClearRecipe(size);

        for (int i = 0; i < size; i++)
        {
            this.recipe[i] = InventoryUtils.isStackEmpty(otherRecipe[i]) == false ? otherRecipe[i].method_7972() : InventoryUtils.EMPTY_STACK;
        }

        this.result = InventoryUtils.isStackEmpty(other.getResult()) == false ? other.getResult().method_7972() : InventoryUtils.EMPTY_STACK;
        this.vanillaRecipe = other.vanillaRecipe;
    }

    @Override
    public void readFromNBT(@Nonnull class_2487 nbt, @Nonnull class_5455 registryManager)
    {
        if (nbt.method_10573("Result", Constants.NBT.TAG_COMPOUND) && nbt.method_10573("Ingredients", Constants.NBT.TAG_LIST))
        {
            class_2499 tagIngredients = nbt.method_10554("Ingredients", Constants.NBT.TAG_COMPOUND);
            int count = tagIngredients.size();
            int length = nbt.method_10550("Length");

            if (length > 0)
            {
                this.ensureRecipeSizeAndClearRecipe(length);
            }

            for (int i = 0; i < count; i++)
            {
                class_2487 tag = tagIngredients.method_10602(i);
                int slot = tag.method_10550("Slot");

                if (slot >= 0 && slot < this.recipe.length)
                {
                    this.recipe[slot] = class_1799.method_57359(registryManager, tag);
                }
            }

            this.result = class_1799.method_57359(registryManager, nbt.method_10562("Result"));
        }
    }

    @Override
    @Nonnull
    public class_2487 writeToNBT(@Nonnull class_5455 registryManager)
    {
        class_2487 nbt = new class_2487();

        if (this.isValid())
        {
            class_2487 tag = (class_2487) this.result.method_57358(registryManager);

            nbt.method_10569("Length", this.recipe.length);
            nbt.method_10566("Result", tag);

            class_2499 tagIngredients = new class_2499();

            for (int i = 0; i < this.recipe.length; i++)
            {
                if (this.recipe[i].method_7960() == false && InventoryUtils.isStackEmpty(this.recipe[i]) == false)
                {
                    tag = new class_2487();
                    tag.method_10543((class_2487) this.recipe[i].method_57358(registryManager));

                    tag.method_10569("Slot", i);
                    tagIngredients.add(tag);
                }
            }

            nbt.method_10566("Ingredients", tagIngredients);
        }

        return nbt;
    }

    public int getRecipeLength()
    {
        return this.recipe.length;
    }

    public class_1799[] getRecipeItems()
    {
        return this.recipe;
    }

    @Override
    public boolean isEmpty()
    {
        boolean empty = true;

        for (int i = 0; i < this.getRecipeLength(); i++)
        {
            if (!this.getRecipeItems()[i].method_7960())
            {
                empty = false;
            }
        }

        return empty || this.getResult().method_7960();
    }

    public int countRecipeItems()
    {
        int count = 0;

        for (class_1799 itemStack : this.recipe)
        {
            if (!itemStack.method_7960())
            {
                count++;
            }
        }

        return count;
    }

    @Nullable
    public class_8786<?> getVanillaRecipeEntry()
    {
        return this.vanillaRecipe;
    }

    @SuppressWarnings("unchecked")
    @Nullable
    public <T extends class_9695> class_1860<T> getVanillaRecipe()
    {
        if (this.recipe == null)
        {
            return null;
        }

        if (this.vanillaRecipe != null)
        {
            return (class_1860<T>) this.vanillaRecipe.comp_1933();
        }

        return null;
    }
}
