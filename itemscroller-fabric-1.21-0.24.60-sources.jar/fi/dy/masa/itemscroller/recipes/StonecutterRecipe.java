package fi.dy.masa.itemscroller.recipes;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import net.minecraft.class_3971;
import net.minecraft.class_3979;
import net.minecraft.class_465;
import net.minecraft.class_5455;
import fi.dy.masa.itemscroller.util.InventoryUtils;

public class StonecutterRecipe extends AbstractRecipePattern
{
    private class_1799 input = InventoryUtils.EMPTY_STACK;
    private int selectedRecipe = -1;

    public StonecutterRecipe()
    {
        super();
    }

    @Override
    public AbstractRecipePattern.RecipeType getType()
    {
        return AbstractRecipePattern.RecipeType.STONECUTTER;
    }

    @Override
    public void clearRecipe()
    {
        this.result = InventoryUtils.EMPTY_STACK;
        this.input = InventoryUtils.EMPTY_STACK;
        this.selectedRecipe = -1;
    }

    @Override
    public boolean isEmpty()
    {
        return this.input.method_7960() || this.result.method_7960();
    }

    @Override
    public void storeRecipe(class_1735 slot, class_465<? extends class_1703> gui,
                            boolean clearIfEmpty, boolean fromKeybind, class_310 mc)
    {
        if (!(gui instanceof class_3979) || !(gui.method_17577() instanceof class_3971 handler))
        {
            return;
        }

        if (slot.method_7681())
        {
            class_1735 inputSlot = handler.method_7611(0);
            if (inputSlot.method_7681())
            {
                this.input = inputSlot.method_7677().method_7972();
            }
            this.result = slot.method_7677().method_7972();
            this.selectedRecipe = handler.method_17862();
        }
        else if (clearIfEmpty)
        {
            this.clearRecipe();
        }
    }

    @Override
    @Nullable
    public class_1735 getOutputSlot(class_465<? extends class_1703> gui)
    {
        if (gui.method_17577() instanceof class_3971 handler)
        {
            return handler.method_7611(1);
        }
        return null;
    }

    @Override
    public boolean canCraft(class_465<? extends class_1703> gui)
    {
        if (!this.isValid()) return false;
        if (!(gui.method_17577() instanceof class_3971 handler)) return false;
        return handler.method_17862() == this.selectedRecipe;
    }

    @Override
    public void fillInputs(class_465<? extends class_1703> gui, boolean fillStacks, class_1735 outputSlot)
    {
        if (!(gui.method_17577() instanceof class_3971 handler) || this.input.method_7960())
        {
            return;
        }

        class_1735 inputSlot = handler.method_7611(0);
        class_310 mc = class_310.method_1551();

        if (inputSlot.method_7681() && InventoryUtils.areStacksEqual(inputSlot.method_7677(), this.input) == false)
        {
            InventoryUtils.shiftClickSlot(gui, inputSlot.field_7874);
        }

        if (inputSlot.method_7681() == false || InventoryUtils.areStacksEqual(inputSlot.method_7677(), this.input) == false)
        {
            InventoryUtils.tryClearCursor(gui);
            InventoryUtils.moveItemsFromInventory(gui, 0, mc.field_1724.method_31548(), this.input, fillStacks);
        }

        if (this.selectedRecipe >= 0)
        {
            mc.field_1761.method_2900(handler.field_7763, this.selectedRecipe);
        }
    }

    @Override
    public void clearInputs(class_465<? extends class_1703> gui)
    {
        if (!(gui.method_17577() instanceof class_3971 handler)) return;
        class_1735 inputSlot = handler.method_7611(0);
        if (inputSlot.method_7681())
        {
            InventoryUtils.shiftClickSlot(gui, inputSlot.field_7874);
        }
    }

    // 只支持按住 合成 - 正常合成 按钮批量合成，单次按下一键合成立即提取
    @Override
    public void craftEverything(class_465<? extends class_1703> gui)
    {
        class_1735 outputSlot = this.getOutputSlot(gui);
        if (outputSlot == null || this.isValid() == false) return;

        this.fillInputs(gui, true, outputSlot);
    }

    @Override
    public void craftAsManyAsPossible(class_465<? extends class_1703> gui)
    {
        class_1735 inputSlot = gui.method_17577().method_7611(0);
        class_1735 outputSlot = this.getOutputSlot(gui);
        if (outputSlot == null || inputSlot == null || this.isValid() == false) return;

        if (inputSlot.method_7681() == false ||
            InventoryUtils.areStacksEqual(inputSlot.method_7677(), this.input) == false)
        {
            return;
        }

        class_310 mc = class_310.method_1551();
        class_3971 handler = (class_3971) gui.method_17577();

        if (this.selectedRecipe >= 0 &&
            handler.method_17862() != this.selectedRecipe)
        {
            mc.field_1761.method_2900(handler.field_7763, this.selectedRecipe);
        }

        InventoryUtils.shiftClickSlot(gui, outputSlot.field_7874);
    }

    @Override
    public void readFromNBT(@Nonnull class_2487 nbt, @Nonnull class_5455 registryManager)
    {
        if (nbt.method_10573("Result", fi.dy.masa.itemscroller.util.Constants.NBT.TAG_COMPOUND))
        {
            this.result = class_1799.method_57359(registryManager, nbt.method_10562("Result"));
        }
        if (nbt.method_10573("Input", fi.dy.masa.itemscroller.util.Constants.NBT.TAG_COMPOUND))
        {
            this.input = class_1799.method_57359(registryManager, nbt.method_10562("Input"));
        }
        this.selectedRecipe = nbt.method_10550("SelectedRecipe");
    }

    @Override
    @Nonnull
    public class_2487 writeToNBT(@Nonnull class_5455 registryManager)
    {
        class_2487 nbt = new class_2487();

        if (this.isValid())
        {
            nbt.method_10566("Result", this.result.method_57358(registryManager));
            nbt.method_10566("Input", this.input.method_57358(registryManager));
            nbt.method_10569("SelectedRecipe", this.selectedRecipe);
        }

        return nbt;
    }

    public class_1799 getInput()
    {
        return this.input;
    }

    public void setInput(class_1799 input)
    {
        this.input = input;
    }

    public int getSelectedRecipe()
    {
        return this.selectedRecipe;
    }
}
