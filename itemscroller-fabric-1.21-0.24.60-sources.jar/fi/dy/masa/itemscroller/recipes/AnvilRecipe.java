package fi.dy.masa.itemscroller.recipes;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.class_1703;
import net.minecraft.class_1706;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_465;
import net.minecraft.class_471;
import net.minecraft.class_5455;
import fi.dy.masa.itemscroller.util.InventoryUtils;
import fi.dy.masa.itemscroller.mixin.screen.IMixinAnvilScreen;

public class AnvilRecipe extends AbstractRecipePattern
{
    private class_1799 inputLeft = InventoryUtils.EMPTY_STACK;
    private class_1799 inputRight = InventoryUtils.EMPTY_STACK;
    private String renameText = "";
    private boolean hasRename = false;

    public AnvilRecipe()
    {
        super();
    }

    @Override
    public AbstractRecipePattern.RecipeType getType()
    {
        return AbstractRecipePattern.RecipeType.ANVIL;
    }

    @Override
    public void clearRecipe()
    {
        this.result = InventoryUtils.EMPTY_STACK;
        this.inputLeft = InventoryUtils.EMPTY_STACK;
        this.inputRight = InventoryUtils.EMPTY_STACK;
        this.renameText = "";
        this.hasRename = false;
    }

    @Override
    public boolean isEmpty()
    {
        return this.inputLeft.method_7960() && this.result.method_7960();
    }

    @Override
    public void storeRecipe(class_1735 slot, class_465<? extends class_1703> gui,
                            boolean clearIfEmpty, boolean fromKeybind, class_310 mc)
    {
        if (!(gui instanceof class_471 anvilScreen) || !(gui.method_17577() instanceof class_1706 handler))
        {
            return;
        }

        if (slot.method_7681())
        {
            class_1735 leftSlot = handler.method_7611(0);
            class_1735 rightSlot = handler.method_7611(1);

            this.inputLeft = leftSlot.method_7681() ? leftSlot.method_7677().method_7972() : InventoryUtils.EMPTY_STACK;
            this.inputRight = rightSlot.method_7681() ? rightSlot.method_7677().method_7972() : InventoryUtils.EMPTY_STACK;
            this.result = slot.method_7677().method_7972();

            class_342 nameField = ((IMixinAnvilScreen) anvilScreen).itemscroller_getNameField();
            this.renameText = nameField != null ? nameField.method_1882() : "";
            this.hasRename = !this.renameText.isEmpty();
        }
        else if (clearIfEmpty)
        {
            this.clearRecipe();
        }
    }

    @Override
    @Nullable
    public class_1735 getOutputSlot(class_465<? extends class_1703> gui)
    {
        if (gui.method_17577() instanceof class_1706 handler)
        {
            return handler.method_7611(2);
        }
        return null;
    }

    @Override
    public void fillInputs(class_465<? extends class_1703> gui, boolean fillStacks, class_1735 outputSlot)
    {
        if (!(gui.method_17577() instanceof class_1706 handler) || this.inputLeft.method_7960())
        {
            return;
        }

        class_1735 leftSlot = handler.method_7611(0);
        class_1735 rightSlot = handler.method_7611(1);

        boolean needsLeft = !leftSlot.method_7681() ||
                !InventoryUtils.areStacksEqual(leftSlot.method_7677(), this.inputLeft);
        boolean needsRight = this.inputRight.method_7960() == false &&
                (!rightSlot.method_7681() ||
                 !InventoryUtils.areStacksEqual(rightSlot.method_7677(), this.inputRight));

        if (needsLeft || needsRight)
        {
            InventoryUtils.tryClearCursor(gui);

            if (needsLeft)
            {
                InventoryUtils.moveItemsFromInventory(
                    gui, 0, class_310.method_1551().field_1724.method_31548(), this.inputLeft, fillStacks);
            }

            if (needsRight)
            {
                InventoryUtils.moveItemsFromInventory(
                    gui, 1, class_310.method_1551().field_1724.method_31548(), this.inputRight, fillStacks);
            }
        }

        if (this.hasRename && gui instanceof class_471 anvilScreen)
        {
            String currentName = handler.field_7774;
            if (!this.renameText.equals(currentName))
            {
                class_342 nameField = ((IMixinAnvilScreen) anvilScreen).itemscroller_getNameField();
                nameField.method_1852(this.renameText);
            }
        }
    }

    @Override
    public void clearInputs(class_465<? extends class_1703> gui)
    {
        if (!(gui.method_17577() instanceof class_1706 handler)) return;

        for (int i = 0; i < 2; i++)
        {
            class_1735 inputSlot = handler.method_7611(i);
            if (inputSlot.method_7681())
            {
                InventoryUtils.shiftClickSlot(gui, inputSlot.field_7874);
            }
        }
    }

    @Override
    public void readFromNBT(@Nonnull class_2487 nbt, @Nonnull class_5455 registryManager)
    {
        if (nbt.method_10573("Result", fi.dy.masa.itemscroller.util.Constants.NBT.TAG_COMPOUND))
        {
            this.result = class_1799.method_57359(registryManager, nbt.method_10562("Result"));
        }
        if (nbt.method_10573("InputLeft", fi.dy.masa.itemscroller.util.Constants.NBT.TAG_COMPOUND))
        {
            this.inputLeft = class_1799.method_57359(registryManager, nbt.method_10562("InputLeft"));
        }
        if (nbt.method_10573("InputRight", fi.dy.masa.itemscroller.util.Constants.NBT.TAG_COMPOUND))
        {
            this.inputRight = class_1799.method_57359(registryManager, nbt.method_10562("InputRight"));
        }
        if (nbt.method_10545("RenameText"))
        {
            this.renameText = nbt.method_10558("RenameText");
            this.hasRename = !this.renameText.isEmpty();
        }
    }

    @Override
    @Nonnull
    public class_2487 writeToNBT(@Nonnull class_5455 registryManager)
    {
        class_2487 nbt = new class_2487();

        if (this.isValid())
        {
            nbt.method_10566("Result", this.result.method_57358(registryManager));
            nbt.method_10566("InputLeft", this.inputLeft.method_57358(registryManager));

            if (this.inputRight.method_7960() == false)
            {
                nbt.method_10566("InputRight", this.inputRight.method_57358(registryManager));
            }

            if (this.hasRename)
            {
                nbt.method_10582("RenameText", this.renameText);
            }
        }

        return nbt;
    }

    public class_1799 getInputLeft()
    {
        return this.inputLeft;
    }

    public class_1799 getInputRight()
    {
        return this.inputRight;
    }

    public String getRenameText()
    {
        return this.renameText;
    }

    public boolean hasRename()
    {
        return this.hasRename;
    }
}
