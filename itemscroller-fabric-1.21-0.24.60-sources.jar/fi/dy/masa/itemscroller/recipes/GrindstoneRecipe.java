package fi.dy.masa.itemscroller.recipes;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import net.minecraft.class_3802;
import net.minecraft.class_3803;
import net.minecraft.class_465;
import net.minecraft.class_5455;
import fi.dy.masa.itemscroller.util.InventoryUtils;

public class GrindstoneRecipe extends AbstractRecipePattern
{
    private class_1799 inputTop = InventoryUtils.EMPTY_STACK;
    private class_1799 inputBottom = InventoryUtils.EMPTY_STACK;

    public GrindstoneRecipe()
    {
        super();
    }

    @Override
    public AbstractRecipePattern.RecipeType getType()
    {
        return AbstractRecipePattern.RecipeType.GRINDSTONE;
    }

    @Override
    public void clearRecipe()
    {
        this.result = InventoryUtils.EMPTY_STACK;
        this.inputTop = InventoryUtils.EMPTY_STACK;
        this.inputBottom = InventoryUtils.EMPTY_STACK;
    }

    @Override
    public boolean isEmpty()
    {
        return this.inputTop.method_7960() && this.result.method_7960();
    }

    @Override
    public void storeRecipe(class_1735 slot, class_465<? extends class_1703> gui,
                            boolean clearIfEmpty, boolean fromKeybind, class_310 mc)
    {
        if (!(gui instanceof class_3802) || !(gui.method_17577() instanceof class_3803 handler))
        {
            return;
        }

        if (slot.method_7681())
        {
            class_1735 topSlot = handler.method_7611(0);
            class_1735 bottomSlot = handler.method_7611(1);

            this.inputTop = topSlot.method_7681() ? topSlot.method_7677().method_7972() : InventoryUtils.EMPTY_STACK;
            this.inputBottom = bottomSlot.method_7681() ? bottomSlot.method_7677().method_7972() : InventoryUtils.EMPTY_STACK;
            this.result = slot.method_7677().method_7972();
        }
        else if (clearIfEmpty)
        {
            this.clearRecipe();
        }
    }

    @Override
    @Nullable
    public class_1735 getOutputSlot(class_465<? extends class_1703> gui)
    {
        if (gui.method_17577() instanceof class_3803 handler)
        {
            return handler.method_7611(2);
        }
        return null;
    }

    @Override
    public void fillInputs(class_465<? extends class_1703> gui, boolean fillStacks, class_1735 outputSlot)
    {
        if (!(gui.method_17577() instanceof class_3803 handler))
        {
            return;
        }

        class_1735 topSlot = handler.method_7611(0);
        class_1735 bottomSlot = handler.method_7611(1);

        boolean needsTop = this.inputTop.method_7960() == false &&
                (!topSlot.method_7681() || !InventoryUtils.areStacksEqual(topSlot.method_7677(), this.inputTop));
        boolean needsBottom = this.inputBottom.method_7960() == false &&
                (!bottomSlot.method_7681() || !InventoryUtils.areStacksEqual(bottomSlot.method_7677(), this.inputBottom));

        if (needsTop || needsBottom)
        {
            InventoryUtils.tryClearCursor(gui);

            if (needsTop)
            {
                InventoryUtils.moveItemsFromInventory(
                    gui, 0, class_310.method_1551().field_1724.method_31548(), this.inputTop, fillStacks);
            }

            if (needsBottom)
            {
                InventoryUtils.moveItemsFromInventory(
                    gui, 1, class_310.method_1551().field_1724.method_31548(), this.inputBottom, fillStacks);
            }
        }
    }

    @Override
    public void clearInputs(class_465<? extends class_1703> gui)
    {
        if (!(gui.method_17577() instanceof class_3803 handler)) return;

        for (int i = 0; i < 2; i++)
        {
            class_1735 inputSlot = handler.method_7611(i);
            if (inputSlot.method_7681())
            {
                InventoryUtils.shiftClickSlot(gui, inputSlot.field_7874);
            }
        }
    }

    @Override
    public void readFromNBT(@Nonnull class_2487 nbt, @Nonnull class_5455 registryManager)
    {
        if (nbt.method_10573("Result", fi.dy.masa.itemscroller.util.Constants.NBT.TAG_COMPOUND))
        {
            this.result = class_1799.method_57359(registryManager, nbt.method_10562("Result"));
        }
        if (nbt.method_10573("InputTop", fi.dy.masa.itemscroller.util.Constants.NBT.TAG_COMPOUND))
        {
            this.inputTop = class_1799.method_57359(registryManager, nbt.method_10562("InputTop"));
        }
        if (nbt.method_10573("InputBottom", fi.dy.masa.itemscroller.util.Constants.NBT.TAG_COMPOUND))
        {
            this.inputBottom = class_1799.method_57359(registryManager, nbt.method_10562("InputBottom"));
        }
    }

    @Override
    @Nonnull
    public class_2487 writeToNBT(@Nonnull class_5455 registryManager)
    {
        class_2487 nbt = new class_2487();

        if (this.isValid())
        {
            nbt.method_10566("Result", this.result.method_57358(registryManager));
            nbt.method_10566("InputTop", this.inputTop.method_57358(registryManager));

            if (this.inputBottom.method_7960() == false)
            {
                nbt.method_10566("InputBottom", this.inputBottom.method_57358(registryManager));
            }
        }

        return nbt;
    }

    public class_1799 getInputTop()
    {
        return this.inputTop;
    }

    public class_1799 getInputBottom()
    {
        return this.inputBottom;
    }
}
