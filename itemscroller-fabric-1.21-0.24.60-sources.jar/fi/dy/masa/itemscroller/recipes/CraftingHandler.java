package fi.dy.masa.itemscroller.recipes;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_3802;
import net.minecraft.class_3979;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_471;
import fi.dy.masa.itemscroller.ItemScroller;

public class CraftingHandler
{
    private static final Map<CraftingOutputSlot, SlotRange> CRAFTING_GRID_SLOTS = new HashMap<CraftingOutputSlot, SlotRange>();
    private static final Set<Class<? extends class_465<?>>> CRAFTING_GUIS = new HashSet<>();

    public static void clearDefinitions()
    {
        CRAFTING_GRID_SLOTS.clear();
        CRAFTING_GUIS.clear();
    }

    @SuppressWarnings("unchecked")
    public static boolean addCraftingGridDefinition(String guiClassName, String slotClassName, int outputSlot, SlotRange range)
    {
        try
        {
            Class<? extends class_465<?>> guiClass = (Class<? extends class_465<?>>) Class.forName(guiClassName);
            Class<? extends class_1735> slotClass = (Class<? extends class_1735>) Class.forName(slotClassName);

            CRAFTING_GRID_SLOTS.put(new CraftingOutputSlot(guiClass, slotClass, outputSlot), range);
            CRAFTING_GUIS.add(guiClass);

            return true;
        }
        catch (Exception e)
        {
            ItemScroller.LOGGER.warn("addCraftingGridDefinition(): Failed to find classes for grid definition: gui: '{}', slot: '{}', outputSlot: {}",
                                     guiClassName, slotClassName, outputSlot);
        }

        return false;
    }

    public static boolean isCraftingGui(class_437 gui)
    {
        return (gui instanceof class_465) && CRAFTING_GUIS.contains(((class_465<?>) gui).getClass());
    }

    /**
     * Gets the crafting grid SlotRange associated with the given slot in the given gui, if any.
     * @param gui
     * @param slot
     * @return the SlotRange of the crafting grid, or null, if the given slot is not a crafting output slot
     */
    @Nullable
    public static SlotRange getCraftingGridSlots(class_465<?> gui, class_1735 slot)
    {
        return CRAFTING_GRID_SLOTS.get(CraftingOutputSlot.from(gui, slot));
    }

    @Nullable
    public static class_1735 getFirstCraftingOutputSlotForGui(class_465<? extends class_1703> gui)
    {
        if (CRAFTING_GUIS.contains(gui.getClass()))
        {
            for (class_1735 slot : gui.method_17577().field_7761)
            {
                if (getCraftingGridSlots(gui, slot) != null)
                {
                    return slot;
                }
            }
        }

        return null;
    }

    public static boolean isProcessingGui(class_437 gui)
    {
        return gui instanceof class_3979 ||
               gui instanceof class_471 ||
               gui instanceof class_3802;
    }

    public static void registerProcessingGui(Class<? extends class_465<?>> guiClass)
    {
        CRAFTING_GUIS.add(guiClass);
    }

    @Nullable
    public static class_1735 getFirstOutputSlotForGui(class_465<? extends class_1703> gui)
    {
        class_1735 slot = getFirstCraftingOutputSlotForGui(gui);

        if (slot == null)
        {
            if (gui instanceof class_3979)
            {
                slot = gui.method_17577().method_7611(1);
            }
            else if (gui instanceof class_471)
            {
                slot = gui.method_17577().method_7611(2);
            }
            else if (gui instanceof class_3802)
            {
                slot = gui.method_17577().method_7611(2);
            }
        }

        return slot;
    }

    public static class CraftingOutputSlot
    {
        private final Class<? extends class_465<?>> guiClass;
        private final Class<? extends class_1735> slotClass;
        private final int outputSlot;

        private CraftingOutputSlot (Class<? extends class_465<?>> guiClass, Class<? extends class_1735> slotClass, int outputSlot)
        {
            this.guiClass = guiClass;
            this.slotClass = slotClass;
            this.outputSlot = outputSlot;
        }

        @SuppressWarnings("unchecked")
        public static CraftingOutputSlot from(class_465<?> gui, class_1735 slot)
        {
            return new CraftingOutputSlot((Class<? extends class_465<?>>) gui.getClass(), slot.getClass(), slot.field_7874);
        }

        public Class<? extends class_465<?>> getGuiClass()
        {
            return this.guiClass;
        }

        public Class<? extends class_1735> getSlotClass()
        {
            return this.slotClass;
        }

        public int getSlotNumber()
        {
            return this.outputSlot;
        }

        public boolean matches(class_465<?> gui, class_1735 slot, int outputSlot)
        {
            return outputSlot == this.outputSlot && gui.getClass() == this.guiClass && slot.getClass() == this.slotClass;
        }

        @Override
        public int hashCode()
        {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((guiClass == null) ? 0 : guiClass.hashCode());
            result = prime * result + outputSlot;
            result = prime * result + ((slotClass == null) ? 0 : slotClass.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj)
        {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            CraftingOutputSlot other = (CraftingOutputSlot) obj;
            if (guiClass == null)
            {
                if (other.guiClass != null)
                    return false;
            }
            else if (guiClass != other.guiClass)
                return false;
            if (outputSlot != other.outputSlot)
                return false;
            if (slotClass == null)
            {
                if (other.slotClass != null)
                    return false;
            }
            else if (slotClass != other.slotClass)
                return false;
            return true;
        }

    }

    public static class SlotRange
    {
        private final int first;
        private final int last;

        public SlotRange(int start, int numSlots)
        {
            this.first = start;
            this.last = start + numSlots - 1;
        }

        public int getFirst()
        {
            return this.first;
        }

        public int getLast()
        {
            return this.last;
        }

        public int getSlotCount()
        {
            return this.last - this.first + 1;
        }

        public boolean contains(int slot)
        {
            return slot >= this.first && slot <= this.last;
        }

        @Override
        public String toString()
        {
            return String.format("SlotRange: {first: %d, last: %d}", this.first, this.last);
        }
    }
}
