package fi.dy.masa.itemscroller;

import fi.dy.masa.malilib.util.StringUtils;
import net.minecraft.class_3797;

public class Reference
{
    public static final String MOD_ID = "itemscroller";
    public static final String MOD_NAME = "Item Scroller";
    public static final String MOD_VERSION = StringUtils.getModVersionString(MOD_ID);
    public static final String MC_VERSION = class_3797.field_25319.method_48019();
    public static final String MOD_TYPE = "fabric";
    public static final String MOD_STRING = MOD_ID + "-" + MOD_TYPE + "-" + MC_VERSION + "-" + MOD_VERSION;
}
