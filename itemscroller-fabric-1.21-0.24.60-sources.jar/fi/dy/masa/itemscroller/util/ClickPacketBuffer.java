package fi.dy.masa.itemscroller.util;

import java.util.ArrayDeque;
import java.util.Queue;
import net.minecraft.class_2596;
import net.minecraft.class_310;

public class ClickPacketBuffer
{
    private static final Queue<class_2596<?>> BUFFER = new ArrayDeque<>(2048);
    private static boolean shouldBufferPackets;
    private static boolean hasBufferedPackets;

    public static void reset()
    {
        shouldBufferPackets = false;
        hasBufferedPackets = false;
        BUFFER.clear();
    }

    public static int getBufferedActionsCount()
    {
        return BUFFER.size();
    }

    public static boolean shouldBufferClickPackets()
    {
        return shouldBufferPackets;
    }

    public static boolean shouldCancelWindowClicks()
    {
        // Don't cancel the clicks on the client if we have some Item Scroller actions in progress
        return shouldBufferPackets == false && BUFFER.isEmpty() == false;
    }

    public static void setShouldBufferClickPackets(boolean shouldBuffer)
    {
        shouldBufferPackets = shouldBuffer;
    }

    public static void bufferPacket(class_2596<?> packet)
    {
        BUFFER.offer(packet);
        hasBufferedPackets = true;
    }

    public static void sendBufferedPackets(int maxCount)
    {
        class_310 mc = class_310.method_1551();

        if (hasBufferedPackets)
        {
            if (mc.field_1755 == null)
            {
                reset();
            }
            else if (mc.field_1724 != null)
            {
                maxCount = Math.min(maxCount, BUFFER.size());
    
                for (int i = 0; i < maxCount; ++i)
                {
                    mc.field_1724.field_3944.method_52787(BUFFER.poll());
                }

                hasBufferedPackets = BUFFER.isEmpty() == false;
            }
        }
    }
}
