package fi.dy.masa.itemscroller.util;

import javax.annotation.Nullable;
import java.lang.ref.WeakReference;
import java.util.*;

import java.util.stream.Collectors;
import java.util.stream.IntStream;
import it.unimi.dsi.fastutil.Pair;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntComparator;

import it.unimi.dsi.fastutil.ints.IntIntMutablePair;
import org.apache.commons.lang3.math.Fraction;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1727;
import net.minecraft.class_1728;
import net.minecraft.class_1731;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2480;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2617;
import net.minecraft.class_2799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3802;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_3979;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_471;
import net.minecraft.class_481;
import net.minecraft.class_490;
import net.minecraft.class_492;
import net.minecraft.class_495;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_8566;
import net.minecraft.class_8786;
import net.minecraft.class_9276;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import net.minecraft.class_9694;
import net.minecraft.client.gui.screen.ingame.*;
import net.minecraft.item.*;
import fi.dy.masa.malilib.util.GuiUtils;
import fi.dy.masa.malilib.util.game.wrap.GameWrap;
import fi.dy.masa.itemscroller.ItemScroller;
import fi.dy.masa.itemscroller.config.Configs;
import fi.dy.masa.itemscroller.config.Hotkeys;
import fi.dy.masa.itemscroller.mixin.recipe.IMixinCraftingResultSlot;
import fi.dy.masa.itemscroller.recipes.AbstractRecipePattern;
import fi.dy.masa.itemscroller.recipes.CraftingHandler;
import fi.dy.masa.itemscroller.recipes.CraftingHandler.SlotRange;
import fi.dy.masa.itemscroller.recipes.RecipePattern;
import fi.dy.masa.itemscroller.recipes.RecipeStorage;
import fi.dy.masa.itemscroller.villager.VillagerDataStorage;
import fi.dy.masa.itemscroller.villager.VillagerUtils;

public class InventoryUtils
{
    private static final Set<Integer> DRAGGED_SLOTS = new HashSet<>();
    private static final int SERVER_SYNC_MAGIC = 45510;
    public static int dontUpdateRecipeBook;

    private static WeakReference<class_1735> sourceSlotCandidate = null;
    private static WeakReference<class_1735> sourceSlot = null;
    private static class_1799 stackInCursorLast = class_1799.field_8037;
    @Nullable protected static class_3955 lastRecipe;
    private static MoveAction activeMoveAction = MoveAction.NONE;
    private static int lastPosX;
    private static int lastPosY;
    private static int slotNumberLast;
    private static boolean inhibitCraftResultUpdate;
    private static Runnable selectedSlotUpdateTask;
    public static boolean assumeEmptyShulkerStacking = false;
    private static List<String> topSortingPriorityList = Configs.Generic.SORT_TOP_PRIORITY_INVENTORY.getStrings();
    private static List<String> bottomSortingPriorityList = Configs.Generic.SORT_BOTTOM_PRIORITY_INVENTORY.getStrings();
    public static boolean bufferInvUpdates = false;
    public static List<class_2596<class_2602>> invUpdatesBuffer = new ArrayList<>();
    private static class_1761.class_8128 displayContext;

    /*
    private static Pair<Integer, Integer> lastSwapTry = Pair.of(-1, -1);
    private static int repeatedSwaps = 0;
    private static int MAX_REPEATED = 5;
    private static List<Pair<Integer, Integer>> hotbarSwaps = new ArrayList<>();
     */

    public static void setInhibitCraftingOutputUpdate(boolean inhibitUpdate)
    {
        inhibitCraftResultUpdate = inhibitUpdate;
    }

    public static void onSlotChangedCraftingGrid(class_1657 player,
                                                 class_8566 craftMatrix,
                                                 class_1731 inventoryCraftResult)
    {
//        if (inhibitCraftResultUpdate && Configs.Generic.MASS_CRAFT_INHIBIT_MID_UPDATES.getBooleanValue())
//        {
//            return;
//        }

        if (Configs.Generic.CLIENT_CRAFTING_FIX.getBooleanValue())
        {
            updateCraftingOutputSlot(player, craftMatrix, inventoryCraftResult, true);
        }
    }

    public static void updateCraftingOutputSlot(class_1735 outputSlot)
    {
        class_1657 player = class_310.method_1551().field_1724;

        if (player != null &&
            outputSlot instanceof class_1734 resultSlot &&
            resultSlot.field_7871 instanceof class_1731 resultInv)
        {
            class_8566 craftingInv = ((IMixinCraftingResultSlot) outputSlot).itemscroller_getCraftingInventory();
            updateCraftingOutputSlot(player, craftingInv, resultInv, true);
        }
    }

    public static void updateCraftingOutputSlot(class_1657 player,
                                                class_8566 craftMatrix,
                                                class_1731 inventoryCraftResult,
                                                boolean setEmptyStack)
    {
        class_1937 world = player.method_5770();

        if ((world instanceof class_638) && player instanceof class_746)
        {
            class_1799 stack = class_1799.field_8037;
            class_3955 recipe = Configs.Generic.USE_RECIPE_CACHING.getBooleanValue() ? lastRecipe : null;
            class_8786<?> recipeEntry = null;
            class_9694 recipeInput = craftMatrix.method_59961();

            if (recipe == null || recipe.method_8115(recipeInput, world) == false)
            {
                Optional<class_8786<class_3955>> optional = world.method_8433().method_8132(class_3956.field_17545, recipeInput, world);
                recipe = optional.map(class_8786::comp_1933).orElse(null);
                recipeEntry = optional.orElse(null);
            }

            if (recipe != null)
            {
                if ((recipe.method_8118() ||
                     world.method_8450().method_8355(class_1928.field_19407) == false ||
                     ((class_746) player).method_3130().method_14878(recipeEntry)))
                {
                    inventoryCraftResult.method_7662(recipeEntry);
                    stack = recipe.method_8116(recipeInput, world.method_30349());
                }

                if (setEmptyStack || stack.method_7960() == false)
                {
                    inventoryCraftResult.method_5447(0, stack);
                }

            }

            lastRecipe = recipe;
        }
    }

    public static String getStackString(class_1799 stack)
    {
        if (isStackEmpty(stack) == false)
        {
            class_2960 rl = class_7923.field_41178.method_10221(stack.method_7909());
            String idStr = rl != null ? rl.toString() : "null";
            String displayName = stack.method_7964().getString();
            String nbtStr = stack.method_57353() != null ? stack.method_57353().toString() : "<no NBT>";

            return String.format("[%s - display: %s - NBT: %s] (%s)", idStr, displayName, nbtStr, stack);
        }

        return "<empty>";
    }

    public static void debugPrintSlotInfo(class_465<? extends class_1703> gui, class_1735 slot)
    {
        if (slot == null)
        {
            ItemScroller.LOGGER.info("slot was null");
            return;
        }

        boolean hasSlot = gui.method_17577().field_7761.contains(slot);
        Object inv = slot.field_7871;
        String stackStr = InventoryUtils.getStackString(slot.method_7677());

        ItemScroller.LOGGER.info(String.format("slot: slotNumber: %d, getSlotIndex(): %d, getHasStack(): %s, " +
                "slot class: %s, inv class: %s, Container's slot list has slot: %s, stack: %s, numSlots: %d",
                                               slot.field_7874, AccessorUtils.getSlotIndex(slot), slot.method_7681(), slot.getClass().getName(),
                inv != null ? inv.getClass().getName() : "<null>", hasSlot ? " true" : "false", stackStr,
                                               gui.method_17577().field_7761.size()));
    }

    private static boolean isValidSlot(class_1735 slot, class_465<? extends class_1703> gui, boolean requireItems)
    {
        class_1703 container = gui.method_17577();

        return container != null && container.field_7761 != null &&
                slot != null && container.field_7761.contains(slot) &&
                (requireItems == false || slot.method_7681()) &&
                Configs.SLOT_BLACKLIST.contains(slot.getClass().getName()) == false;
    }

    public static boolean isProcessingEnabled(class_465<? extends class_1703> gui)
    {
        if (gui instanceof class_3979)
            return Configs.Toggles.STONECUTTER_FEATURES.getBooleanValue();
        if (gui instanceof class_471)
            return Configs.Toggles.ANVIL_FEATURES.getBooleanValue();
        if (gui instanceof class_3802)
            return Configs.Toggles.GRINDSTONE_FEATURES.getBooleanValue();
        return Configs.Toggles.CRAFTING_FEATURES.getBooleanValue();
    }
    public static boolean isCraftingSlot(class_465<? extends class_1703> gui, @Nullable class_1735 slot)
    {
        if (slot == null) return false;
        if (CraftingHandler.getCraftingGridSlots(gui, slot) != null) return true;
        if (gui instanceof class_3979 && slot.field_7874 == 1) return true;
        if (gui instanceof class_471 && slot.field_7874 == 2) return true;
        if (gui instanceof class_3802 && slot.field_7874 == 2) return true;
        return false;
    }

    /**
     * Checks if there are slots belonging to another inventory on screen above the given slot
     */
    private static boolean inventoryExistsAbove(class_1735 slot, class_1703 container)
    {
        for (class_1735 slotTmp : container.field_7761)
        {
            if (slotTmp.field_7872 < slot.field_7872 && areSlotsInSameInventory(slot, slotTmp) == false)
            {
                return true;
            }
        }

        return false;
    }

    public static boolean canShiftPlaceItems(class_465<? extends class_1703> gui)
    {
        class_1735 slot = AccessorUtils.getSlotUnderMouse(gui);
        class_1799 stackCursor = gui.method_17577().method_34255();

        // The target slot needs to be an empty, valid slot, and there needs to be items in the cursor
        return slot != null && isStackEmpty(stackCursor) == false && isValidSlot(slot, gui, false) &&
               slot.method_7681() == false && slot.method_7680(stackCursor);
    }

    public static boolean tryMoveItems(class_465<? extends class_1703> gui,
                                       RecipeStorage recipes,
                                       boolean scrollingUp)
    {
        class_1735 slot = AccessorUtils.getSlotUnderMouse(gui);

        // We require an empty cursor
        if (slot == null || isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            return false;
        }

        // Villager handling only happens when scrolling over the trade output slot
        boolean villagerHandling = Configs.Toggles.SCROLL_VILLAGER.getBooleanValue() && gui instanceof class_492 && slot instanceof class_1727;
        boolean craftingHandling = isCraftingSlot(gui, slot) && isProcessingEnabled(gui);
        boolean keyActiveMoveEverything = Hotkeys.MODIFIER_MOVE_EVERYTHING.getKeybind().isKeybindHeld();
        boolean keyActiveMoveMatching = Hotkeys.MODIFIER_MOVE_MATCHING.getKeybind().isKeybindHeld();
        boolean keyActiveMoveStacks = Hotkeys.MODIFIER_MOVE_STACK.getKeybind().isKeybindHeld();
        boolean nonSingleMove = keyActiveMoveEverything || keyActiveMoveMatching || keyActiveMoveStacks;
        boolean moveToOtherInventory = scrollingUp;

        if (Configs.Generic.SLOT_POSITION_AWARE_SCROLL_DIRECTION.getBooleanValue())
        {
            boolean above = inventoryExistsAbove(slot, gui.method_17577());
            // so basically: (above && scrollingUp) || (above == false && scrollingUp == false)
            moveToOtherInventory = (above == scrollingUp);
        }

        if ((Configs.Generic.REVERSE_SCROLL_DIRECTION_SINGLE.getBooleanValue() && nonSingleMove == false) ||
            (Configs.Generic.REVERSE_SCROLL_DIRECTION_STACKS.getBooleanValue() && nonSingleMove))
        {
            moveToOtherInventory = ! moveToOtherInventory;
        }

        // Check that the slot is valid, (don't require items in case of the villager output slot or a crafting slot)
        if (isValidSlot(slot, gui, villagerHandling == false && craftingHandling == false) == false)
        {
            return false;
        }

        if (craftingHandling)
        {
            return tryMoveItemsCrafting(recipes, slot, gui, moveToOtherInventory, keyActiveMoveStacks, keyActiveMoveEverything);
        }

        if (villagerHandling)
        {
            return tryMoveItemsVillager((class_492) gui, slot, moveToOtherInventory, keyActiveMoveStacks);
        }

        if ((Configs.Toggles.SCROLL_SINGLE.getBooleanValue() == false && nonSingleMove == false) ||
            (Configs.Toggles.SCROLL_STACKS.getBooleanValue() == false && keyActiveMoveStacks) ||
            (Configs.Toggles.SCROLL_MATCHING.getBooleanValue() == false && keyActiveMoveMatching) ||
            (Configs.Toggles.SCROLL_EVERYTHING.getBooleanValue() == false && keyActiveMoveEverything))
        {
            return false;
        }

        // Move everything
        if (keyActiveMoveEverything)
        {
            tryMoveStacks(slot, gui, false, moveToOtherInventory, false);
        }
        // Move all matching items
        else if (keyActiveMoveMatching)
        {
            tryMoveStacks(slot, gui, true, moveToOtherInventory, false);
            return true;
        }
        // Move one matching stack
        else if (keyActiveMoveStacks)
        {
            tryMoveStacks(slot, gui, true, moveToOtherInventory, true);
        }
        else
        {
            class_1799 stack = slot.method_7677();

            // Scrolling items from this slot/inventory into the other inventory
            if (moveToOtherInventory)
            {
                tryMoveSingleItemToOtherInventory(slot, gui);
            }
            // Scrolling items from the other inventory into this slot/inventory
            else if (getStackSize(stack) < slot.method_7676(stack))
            {
                tryMoveSingleItemToThisInventory(slot, gui);
            }
        }

        return false;
    }

    public static boolean dragMoveItems(class_465<? extends class_1703> gui,
                                        MoveAction action,
                                        int mouseX, int mouseY, boolean isClick)
    {
        if (isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            // Updating these here is part of the fix to preventing a drag after shift + place
            lastPosX = mouseX;
            lastPosY = mouseY;
            stopDragging();

            return false;
        }

        boolean cancel = false;

        if (isClick && action != MoveAction.NONE)
        {
            // Reset this or the method call won't do anything...
            slotNumberLast = -1;
            lastPosX = mouseX;
            lastPosY = mouseY;
            activeMoveAction = action;
            cancel = dragMoveFromSlotAtPosition(gui, mouseX, mouseY, action);
        }
        else
        {
            action = activeMoveAction;
        }

        if (activeMoveAction != MoveAction.NONE && cancel == false)
        {
            int distX = mouseX - lastPosX;
            int distY = mouseY - lastPosY;
            int absX = Math.abs(distX);
            int absY = Math.abs(distY);

            if (absX > absY)
            {
                int inc = distX > 0 ? 1 : -1;

                for (int x = lastPosX; ; x += inc)
                {
                    int y = absX != 0 ? lastPosY + ((x - lastPosX) * distY / absX) : mouseY;
                    dragMoveFromSlotAtPosition(gui, x, y, action);

                    if (x == mouseX)
                    {
                        break;
                    }
                }
            }
            else
            {
                int inc = distY > 0 ? 1 : -1;

                for (int y = lastPosY; ; y += inc)
                {
                    int x = absY != 0 ? lastPosX + ((y - lastPosY) * distX / absY) : mouseX;
                    dragMoveFromSlotAtPosition(gui, x, y, action);

                    if (y == mouseY)
                    {
                        break;
                    }
                }
            }
        }

        lastPosX = mouseX;
        lastPosY = mouseY;

        // Always update the slot under the mouse.
        // This should prevent a "double click/move" when shift + left clicking on slots that have more
        // than one stack of items. (the regular slotClick() + a "drag move" from the slot that is under the mouse
        // when the left mouse button is pressed down and this code runs).
        class_1735 slot = AccessorUtils.getSlotAtPosition(gui, mouseX, mouseY);

        if (slot != null)
        {
            if (gui instanceof class_481)
            {
                boolean isPlayerInv = ((class_481) gui).method_47424(); // TODO 1.19.3+
                int slotNumber = isPlayerInv ? AccessorUtils.getSlotIndex(slot) : slot.field_7874;
                slotNumberLast = slotNumber;
            }
            else
            {
                slotNumberLast = slot.field_7874;
            }
        }
        else
        {
            slotNumberLast = -1;
        }

        return cancel;
    }

    public static void stopDragging()
    {
        activeMoveAction = MoveAction.NONE;
        DRAGGED_SLOTS.clear();
    }

    private static boolean dragMoveFromSlotAtPosition(class_465<? extends class_1703> gui,
                                                      int x, int y, MoveAction action)
    {
        if (gui instanceof class_481)
        {
            return dragMoveFromSlotAtPositionCreative(gui, x, y, action);
        }

        class_1735 slot = AccessorUtils.getSlotAtPosition(gui, x, y);
        class_310 mc = class_310.method_1551();
        MoveAmount amount = InputUtils.getMoveAmount(action);
        boolean flag = slot != null && isValidSlot(slot, gui, true) && slot.method_7674(mc.field_1724);
        //boolean cancel = flag && (amount == MoveAmount.LEAVE_ONE || amount == MoveAmount.MOVE_ONE);

        if (flag && slot.field_7874 != slotNumberLast &&
            (amount != MoveAmount.MOVE_ONE || DRAGGED_SLOTS.contains(slot.field_7874) == false))
        {
            switch (action)
            {
                case MOVE_TO_OTHER_MOVE_ONE:
                    tryMoveSingleItemToOtherInventory(slot, gui);
                    break;

                case MOVE_TO_OTHER_LEAVE_ONE:
                    tryMoveAllButOneItemToOtherInventory(slot, gui);
                    break;

                case MOVE_TO_OTHER_STACKS:
                    shiftClickSlot(gui, slot.field_7874);
                    break;

                case MOVE_TO_OTHER_MATCHING:
                    tryMoveStacks(slot, gui, true, true, false);
                    break;

                case DROP_ONE:
                    clickSlot(gui, slot.field_7874, 0, class_1713.field_7795);
                    break;

                case DROP_LEAVE_ONE:
                    leftClickSlot(gui, slot.field_7874);
                    rightClickSlot(gui, slot.field_7874);
                    dropItemsFromCursor(gui);
                    break;

                case DROP_STACKS:
                    clickSlot(gui, slot.field_7874, 1, class_1713.field_7795);
                    break;

                case MOVE_DOWN_MOVE_ONE:
                case MOVE_DOWN_LEAVE_ONE:
                case MOVE_DOWN_STACKS:
                case MOVE_DOWN_MATCHING:
                    tryMoveItemsVertically(gui, slot, false, amount);
                    break;

                case MOVE_UP_MOVE_ONE:
                case MOVE_UP_LEAVE_ONE:
                case MOVE_UP_STACKS:
                case MOVE_UP_MATCHING:
                    tryMoveItemsVertically(gui, slot, true, amount);
                    break;

                default:
            }

            DRAGGED_SLOTS.add(slot.field_7874);
        }

        return true;
    }

    private static boolean dragMoveFromSlotAtPositionCreative(class_465<? extends class_1703> gui,
                                                              int x, int y, MoveAction action)
    {
        class_481 guiCreative = (class_481) gui;
        class_1735 slot = AccessorUtils.getSlotAtPosition(gui, x, y);
        boolean isPlayerInv = guiCreative.method_47424(); // TODO 1.19.3+

        // Only allow dragging from the hotbar slots
        if (slot == null || (slot.getClass() != class_1735.class && isPlayerInv == false))
        {
            return false;
        }

        class_310 mc = class_310.method_1551();
        MoveAmount amount = InputUtils.getMoveAmount(action);
        boolean flag = slot != null && isValidSlot(slot, gui, true) && slot.method_7674(mc.field_1724);
        boolean cancel = flag && (amount == MoveAmount.LEAVE_ONE || amount == MoveAmount.MOVE_ONE);
        // The player inventory tab of the creative inventory uses stupid wrapped
        // slots that all have slotNumber = 0 on the outer instance ;_;
        // However in that case we can use the slotIndex which is easy enough to get.
        int slotNumber = isPlayerInv ? AccessorUtils.getSlotIndex(slot) : slot.field_7874;

        if (flag && slotNumber != slotNumberLast && DRAGGED_SLOTS.contains(slotNumber) == false)
        {
            switch (action)
            {
                case SCROLL_TO_OTHER_MOVE_ONE:
                case MOVE_TO_OTHER_MOVE_ONE:
                    leftClickSlot(guiCreative, slot, slotNumber);
                    rightClickSlot(guiCreative, slot, slotNumber);
                    shiftClickSlot(guiCreative, slot, slotNumber);
                    leftClickSlot(guiCreative, slot, slotNumber);

                    cancel = true;
                    break;

                case MOVE_TO_OTHER_LEAVE_ONE:
                    // Too lazy to try to duplicate the proper code for the weird creative inventory...
                    if (isPlayerInv == false)
                    {
                        leftClickSlot(guiCreative, slot, slotNumber);
                        rightClickSlot(guiCreative, slot, slotNumber);

                        // Delete the rest of the stack by placing it in the first creative "source slot"
                        class_1735 slotFirst = gui.method_17577().field_7761.get(0);
                        leftClickSlot(guiCreative, slotFirst, slotFirst.field_7874);
                    }

                    cancel = true;
                    break;

                case SCROLL_TO_OTHER_STACKS:
                case MOVE_TO_OTHER_STACKS:
                    shiftClickSlot(gui, slot, slotNumber);
                    cancel = true;
                    break;

                case DROP_ONE:
                    clickSlot(gui, slot.field_7874, 0, class_1713.field_7795);
                    break;

                case DROP_LEAVE_ONE:
                    leftClickSlot(gui, slot.field_7874);
                    rightClickSlot(gui, slot.field_7874);
                    dropItemsFromCursor(gui);
                    break;

                case DROP_STACKS:
                    clickSlot(gui, slot.field_7874, 1, class_1713.field_7795);
                    cancel = true;
                    break;

                case MOVE_DOWN_MOVE_ONE:
                case MOVE_DOWN_LEAVE_ONE:
                case MOVE_DOWN_STACKS:
                    tryMoveItemsVertically(gui, slot, false, amount);
                    cancel = true;
                    break;

                case MOVE_UP_MOVE_ONE:
                case MOVE_UP_LEAVE_ONE:
                case MOVE_UP_STACKS:
                    tryMoveItemsVertically(gui, slot, true, amount);
                    cancel = true;
                    break;

                default:
            }

            DRAGGED_SLOTS.add(slotNumber);
        }

        return cancel;
    }

    public static void dropStacks(class_465<? extends class_1703> gui,
                                  class_1799 stackReference,
                                  class_1735 slotReference,
                                  boolean sameInventory)
    {
        if (slotReference != null && isStackEmpty(stackReference) == false)
        {
            class_1703 container = gui.method_17577();
            stackReference = stackReference.method_7972();

            for (class_1735 slot : container.field_7761)
            {
                // If this slot is in the same inventory that the items were picked up to the cursor from
                // and the stack is identical to the one in the cursor, then this stack will get dropped.
                if (areSlotsInSameInventory(slot, slotReference) == sameInventory &&
                    areStacksEqual(slot.method_7677(), stackReference))
                {
                    // Drop the stack
                    dropStack(gui, slot.field_7874);
                }
            }
        }
    }

    public static void dropAllMatchingStacks(class_465<? extends class_1703> gui,
                                             class_1799 stackReference)
    {
        if (isStackEmpty(stackReference) == false)
        {
            class_1703 container = gui.method_17577();
            stackReference = stackReference.method_7972();

            for (class_1735 slot : container.field_7761)
            {
                if (areStacksEqual(slot.method_7677(), stackReference))
                {
                    // Drop the stack
                    dropStack(gui, slot.field_7874);
                }
            }
        }
    }

    public static boolean shiftDropItems(class_465<? extends class_1703> gui)
    {
        class_1799 stackReference = gui.method_17577().method_34255();

        if (isStackEmpty(stackReference) == false && sourceSlot != null)
        {
            stackReference = stackReference.method_7972();

            // First drop the existing stack from the cursor
            dropItemsFromCursor(gui);

            dropStacks(gui, stackReference, sourceSlot.get(), true);
            return true;
        }

        return false;
    }

    public static boolean shiftPlaceItems(class_1735 slot, class_465<? extends class_1703> gui)
    {
        // Left click to place the items from the cursor to the slot
        leftClickSlot(gui, slot.field_7874);

        // Ugly fix to prevent accidentally drag-moving the stack from the slot that it was just placed into...
        DRAGGED_SLOTS.add(slot.field_7874);

        tryMoveStacks(slot, gui, true, false, false);

        return true;
    }

    /**
     * Store a reference to the slot when a slot is left or right clicked on.
     * The slot is then later used to determine which inventory an ItemStack was
     * picked up from, if the stack from the cursor is dropped while holding shift.
     */
    public static void storeSourceSlotCandidate(class_1735 slot, class_465<?> gui)
    {
        // Left or right mouse button was pressed
        if (slot != null)
        {
            class_1799 stackCursor = gui.method_17577().method_34255();
            class_1799 stack = EMPTY_STACK;

            if (isStackEmpty(stackCursor) == false)
            {
                // Do a cheap copy without NBT data
                stack = new class_1799(stackCursor.method_7909(), getStackSize(stackCursor));
            }

            // Store the candidate
            // NOTE: This method is called BEFORE the stack has been picked up to the cursor!
            // Thus we can't check that there is an item already in the cursor, and that's why this is just a "candidate"
            sourceSlotCandidate = new WeakReference<>(slot);
            stackInCursorLast = stack;
        }
    }

    /**
     * Check if the (previous) mouse event resulted in picking up a new ItemStack to the cursor
     */
    public static void checkForItemPickup(class_465<?> gui)
    {
        class_1799 stackCursor = gui.method_17577().method_34255();

        // Picked up or swapped items to the cursor, grab a reference to the slot that the items came from
        // Note that we are only checking the item here!
        if (isStackEmpty(stackCursor) == false && class_1799.method_7984(stackCursor, stackInCursorLast) == false && sourceSlotCandidate != null)
        {
            sourceSlot = new WeakReference<>(sourceSlotCandidate.get());
        }
    }

    private static boolean tryMoveItemsVillager(class_492 gui,
                                                class_1735 slot,
                                                boolean moveToOtherInventory,
                                                boolean fullStacks)
    {
        if (fullStacks)
        {
            // Try to fill the merchant's buy slots from the player inventory
            if (moveToOtherInventory == false)
            {
                tryMoveItemsToMerchantBuySlots(gui, true);
            }
            // Move items from sell slot to player inventory
            else if (slot.method_7681())
            {
                tryMoveStacks(slot, gui, true, true, true);
            }
            // Scrolling over an empty output slot, clear the buy slots
            else
            {
                tryMoveStacks(slot, gui, false, true, false);
            }
        }
        else
        {
            // Scrolling items from player inventory into merchant buy slots
            if (moveToOtherInventory == false)
            {
                tryMoveItemsToMerchantBuySlots(gui, false);
            }
            // Scrolling items from this slot/inventory into the other inventory
            else if (slot.method_7681())
            {
                moveOneSetOfItemsFromSlotToPlayerInventory(gui, slot);
            }
        }

        return false;
    }

    public static void villagerClearTradeInputSlots()
    {
        if (GuiUtils.getCurrentScreen() instanceof class_492 merchantGui)
        {
            class_1735 slot = merchantGui.method_17577().method_7611(0);

            if (slot.method_7681())
            {
                shiftClickSlot(merchantGui, slot.field_7874);
            }

            slot = merchantGui.method_17577().method_7611(1);

            if (slot.method_7681())
            {
                shiftClickSlot(merchantGui, slot.field_7874);
            }
        }
    }

    public static void villagerTradeEverythingPossibleWithTrade(int visibleIndex)
    {
        if (GuiUtils.getCurrentScreen() instanceof class_492 merchantGui)
        {
            class_1728 handler = merchantGui.method_17577();

            try
            {
                if (handler.method_17438().isEmpty()) return;
            }
            catch (Exception ignored)
            {
                return;
            }

            class_1735 slot = handler.method_7611(2);
            class_1799 sellItem = handler.method_17438().get(visibleIndex).method_8250().method_7972();

            while (true)
            {
                VillagerUtils.switchToTradeByVisibleIndex(visibleIndex);
                //tryMoveItemsToMerchantBuySlots(merchantGui, true);

                // Not a valid recipe
                //if (slot.hasStack() == false)
                if (areStacksEqual(sellItem, slot.method_7677()) == false)
                {
                    break;
                }

                shiftClickSlot(merchantGui, slot.field_7874);

                // No room in player inventory
                if (slot.method_7681())
                {
                    break;
                }
            }

            villagerClearTradeInputSlots();
        }
    }

    public static boolean villagerTradeEverythingPossibleWithAllFavoritedTrades()
    {
        class_437 screen = GuiUtils.getCurrentScreen();

        if (screen instanceof class_492)
        {
            class_1728 handler = ((class_492) screen).method_17577();
            IntArrayList favorites = VillagerDataStorage.getInstance().getFavoritesForCurrentVillager(handler).favorites;

            for (int index = 0; index < favorites.size(); ++index)
            {
                VillagerUtils.switchToTradeByVisibleIndex(index);
                villagerTradeEverythingPossibleWithTrade(index);
            }

            villagerClearTradeInputSlots();

            return true;
        }

        return false;
    }

    private static boolean tryMoveSingleItemToOtherInventory(class_1735 slot,
                                                             class_465<? extends class_1703> gui)
    {
        class_1799 stackOrig = slot.method_7677();
        class_1703 container = gui.method_17577();
        class_310 mc = class_310.method_1551();

        if (isStackEmpty(gui.method_17577().method_34255()) == false || slot.method_7674(mc.field_1724) == false ||
            (getStackSize(stackOrig) > 1 && slot.method_7680(stackOrig) == false))
        {
            return false;
        }

        // Can take all the items to the cursor at once, use a shift-click method to move one item from the slot
        if (getStackSize(stackOrig) <= stackOrig.method_7914())
        {
            return clickSlotsToMoveSingleItemByShiftClick(gui, slot.field_7874);
        }

        class_1799 stack = stackOrig.method_7972();
        setStackSize(stack, 1);

        class_1799[] originalStacks = getOriginalStacks(container);

        // Try to move the temporary single-item stack via the shift-click handler method
        slot.method_7673(stack);
        container.method_7601(mc.field_1724, slot.field_7874);

        // Successfully moved the item somewhere, now we want to check where it went
        if (slot.method_7681() == false)
        {
            int targetSlot = getTargetSlot(container, originalStacks);

            // Found where the item went
            if (targetSlot >= 0)
            {
                // Remove the dummy item from the target slot (on the client side)
                container.field_7761.get(targetSlot).method_7671(1);

                // Restore the original stack to the slot under the cursor (on the client side)
                restoreOriginalStacks(container, originalStacks);

                // Do the slot clicks to actually move the items (on the server side)
                return clickSlotsToMoveSingleItem(gui, slot.field_7874, targetSlot);
            }
        }

        // Restore the original stack to the slot under the cursor (on the client side)
        slot.method_7673(stackOrig);

        return false;
    }

    private static boolean tryMoveAllButOneItemToOtherInventory(class_1735 slot,
                                                                class_465<? extends class_1703> gui)
    {
        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;
        class_1799 stackOrig = slot.method_7677().method_7972();

        if (getStackSize(stackOrig) == 1 || getStackSize(stackOrig) > stackOrig.method_7914() ||
            slot.method_7674(player) == false || slot.method_7680(stackOrig) == false)
        {
            return true;
        }

        // Take half of the items from the original slot to the cursor
        rightClickSlot(gui, slot.field_7874);

        class_1799 stackInCursor = gui.method_17577().method_34255();
        if (isStackEmpty(stackInCursor))
        {
            return false;
        }

        int stackInCursorSizeOrig = getStackSize(stackInCursor);
        int tempSlotNum = -1;

        // Find some other slot where to store one of the items temporarily
        for (class_1735 slotTmp : gui.method_17577().field_7761)
        {
            if (slotTmp.field_7874 != slot.field_7874 &&
                areSlotsInSameInventory(slotTmp, slot, true) &&
                slotTmp.method_7680(stackInCursor) &&
                slotTmp.method_7674(player))
            {
                class_1799 stackInSlot = slotTmp.method_7677();

                if (isStackEmpty(stackInSlot) || areStacksEqual(stackInSlot, stackInCursor))
                {
                    // Try to put one item into the temporary slot
                    rightClickSlot(gui, slotTmp.field_7874);

                    stackInCursor = gui.method_17577().method_34255();

                    // Successfully stored one item
                    if (isStackEmpty(stackInCursor) || getStackSize(stackInCursor) < stackInCursorSizeOrig)
                    {
                        tempSlotNum = slotTmp.field_7874;
                        break;
                    }
                }
            }
        }

        if (isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            // Return the rest of the items into the original slot
            leftClickSlot(gui, slot.field_7874);
        }

        // Successfully stored one item in a temporary slot
        if (tempSlotNum != -1)
        {
            // Shift click the stack from the original slot
            shiftClickSlot(gui, slot.field_7874);

            // Take half a stack from the temporary slot
            rightClickSlot(gui, tempSlotNum);

            // Return one item into the original slot
            rightClickSlot(gui, slot.field_7874);

            // Return the rest of the items to the temporary slot, if any
            if (isStackEmpty(gui.method_17577().method_34255()) == false)
            {
                leftClickSlot(gui, tempSlotNum);
            }

            return true;
        }
        // No temporary slot found, try to move the stack manually
        else
        {
            boolean treatHotbarAsDifferent = gui.getClass() == class_490.class;
            IntArrayList slots = getSlotNumbersOfEmptySlots(gui.method_17577(), slot, false, treatHotbarAsDifferent, false);

            if (slots.isEmpty())
            {
                slots = getSlotNumbersOfMatchingStacks(gui.method_17577(), slot, false, slot.method_7677(), true, treatHotbarAsDifferent, false);
            }

            if (slots.isEmpty() == false)
            {
                // Take the stack
                leftClickSlot(gui, slot.field_7874);

                // Return one item
                rightClickSlot(gui, slot.field_7874);

                // Try to place the stack in the cursor to any valid empty or matching slots in a different inventory
                for (int slotNum : slots)
                {
                    class_1735 slotTmp = gui.method_17577().method_7611(slotNum);
                    stackInCursor = gui.method_17577().method_34255();

                    if (isStackEmpty(stackInCursor))
                    {
                        return true;
                    }

                    if (slotTmp.method_7680(stackInCursor))
                    {
                        leftClickSlot(gui, slotNum);
                    }
                }

                // Items left, return them
                if (isStackEmpty(stackInCursor) == false)
                {
                    leftClickSlot(gui, slot.field_7874);
                }
            }
        }

        return false;
    }

    private static boolean tryMoveSingleItemToThisInventory(class_1735 slot,
                                                            class_465<? extends class_1703> gui)
    {
        class_1703 container = gui.method_17577();
        class_1799 stackOrig = slot.method_7677();
        class_310 mc = class_310.method_1551();

        if (slot.method_7680(stackOrig) == false)
        {
            return false;
        }

        for (int slotNum = container.field_7761.size() - 1; slotNum >= 0; slotNum--)
        {
            class_1735 slotTmp = container.field_7761.get(slotNum);
            class_1799 stackTmp = slotTmp.method_7677();

            if (areSlotsInSameInventory(slotTmp, slot) == false &&
                isStackEmpty(stackTmp) == false && slotTmp.method_7674(mc.field_1724) &&
                (getStackSize(stackTmp) == 1 || slotTmp.method_7680(stackTmp)))
            {
                if (areStacksEqual(stackTmp, stackOrig))
                {
                    return clickSlotsToMoveSingleItem(gui, slotTmp.field_7874, slot.field_7874);
                }
            }
        }

        // If we weren't able to move any items from another inventory, then try to move items
        // within the same inventory (mostly between the hotbar and the player inventory)
        /*
        for (Slot slotTmp : container.slots)
        {
            ItemStack stackTmp = slotTmp.getStack();

            if (slotTmp.id != slot.id &&
                isStackEmpty(stackTmp) == false && slotTmp.canTakeItems(gui.mc.player) &&
                (getStackSize(stackTmp) == 1 || slotTmp.canInsert(stackTmp)))
            {
                if (areStacksEqual(stackTmp, stackOrig))
                {
                    return this.clickSlotsToMoveSingleItem(gui, slotTmp.id, slot.id);
                }
            }
        }
        */

        return false;
    }

    public static void tryMoveStacks(class_1735 slot,
                                     class_465<? extends class_1703> gui,
                                     boolean matchingOnly,
                                     boolean toOtherInventory,
                                     boolean firstOnly)
    {
        tryMoveStacks(slot.method_7677(), slot, gui, matchingOnly, toOtherInventory, firstOnly);
    }

    private static void tryMoveStacks(class_1799 stackReference,
                                      class_1735 slot,
                                      class_465<? extends class_1703> gui,
                                      boolean matchingOnly,
                                      boolean toOtherInventory,
                                      boolean firstOnly)
    {
        class_1703 container = gui.method_17577();
        final int maxSlot = container.field_7761.size() - 1;

        for (int i = maxSlot; i >= 0; i--)
        {
            class_1735 slotTmp = container.field_7761.get(i);

            if (slotTmp.field_7874 != slot.field_7874 &&
                areSlotsInSameInventory(slotTmp, slot) == toOtherInventory && slotTmp.method_7681() &&
                (matchingOnly == false || areStacksEqual(stackReference, slotTmp.method_7677())))
            {
                boolean success = shiftClickSlotWithCheck(gui, slotTmp.field_7874);

                // Failed to shift-click items, try a manual method
                if (success == false && Configs.Toggles.SCROLL_STACKS_FALLBACK.getBooleanValue())
                {
                    clickSlotsToMoveItemsFromSlot(slotTmp, gui, toOtherInventory);
                }

                if (firstOnly)
                {
                    return;
                }
            }
        }

        // If moving to the other inventory, then move the hovered slot's stack last
        if (toOtherInventory &&
            shiftClickSlotWithCheck(gui, slot.field_7874) == false &&
            Configs.Toggles.SCROLL_STACKS_FALLBACK.getBooleanValue())
        {
            clickSlotsToMoveItemsFromSlot(slot, gui, toOtherInventory);
        }
    }

    private static void tryMoveItemsToMerchantBuySlots(class_492 gui,
                                                       boolean fillStacks)
    {
        class_1916 list = gui.method_17577().method_17438();
        int index = AccessorUtils.getSelectedMerchantRecipe(gui);

        if (list == null || list.size() <= index)
        {
            return;
        }

        class_1914 recipe = list.get(index);

        if (recipe == null)
        {
            return;
        }

        class_1799 buy1 = recipe.method_19272();
        class_1799 buy2 = recipe.method_8247();

        if (isStackEmpty(buy1) == false)
        {
            fillBuySlot(gui, 0, buy1, fillStacks);
        }

        if (isStackEmpty(buy2) == false)
        {
            fillBuySlot(gui, 1, buy2, fillStacks);
        }
    }

    private static void fillBuySlot(class_465<? extends class_1703> gui,
                                    int slotNum,
                                    class_1799 buyStack,
                                    boolean fillStacks)
    {
        class_1735 slot = gui.method_17577().method_7611(slotNum);
        class_1799 existingStack = slot.method_7677();
        class_310 mc = class_310.method_1551();

        // If there are items not matching the merchant recipe, move them out first
        if (isStackEmpty(existingStack) == false && areStacksEqual(buyStack, existingStack) == false)
        {
            shiftClickSlot(gui, slotNum);
        }

        existingStack = slot.method_7677();

        if (isStackEmpty(existingStack) || areStacksEqual(buyStack, existingStack))
        {
            moveItemsFromInventory(gui, slotNum, mc.field_1724.method_31548(), buyStack, fillStacks);
        }
    }

    public static void handleRecipeClick(class_465<? extends class_1703> gui,
                                         class_310 mc,
                                         RecipeStorage recipes,
                                         int hoveredRecipeId,
                                         boolean isLeftClick,
                                         boolean isRightClick,
                                         boolean isPickBlock,
                                         boolean isShiftDown)
    {
        if (isLeftClick || isRightClick)
        {
            boolean changed = recipes.getSelection() != hoveredRecipeId;
            recipes.changeSelectedRecipe(hoveredRecipeId);

            if (changed)
            {
                AbstractRecipePattern recipe = recipes.getSelectedRecipe();
                if (recipe instanceof RecipePattern)
                {
                    InventoryUtils.clearFirstCraftingGridOfItems((RecipePattern) recipe, gui, false);
                }
            }
            else
            {
                AbstractRecipePattern recipe = recipes.getRecipe(hoveredRecipeId);
                if (recipe instanceof RecipePattern craftingRecipe)
                {
                    InventoryUtils.tryMoveItemsToFirstCraftingGrid(craftingRecipe, gui, isShiftDown);
                }
                else
                {
                    class_1735 outputSlot = recipe.getOutputSlot(gui);
                    if (outputSlot != null)
                    {
                        recipe.fillInputs(gui, isShiftDown, outputSlot);
                    }
                }
            }

            // Right click: Also craft the items
            if (isRightClick)
            {
                class_1735 outputSlot = CraftingHandler.getFirstOutputSlotForGui(gui);
                boolean dropKeyDown = mc.field_1690.field_1869.method_1434(); // FIXME 1.14

                if (outputSlot != null)
                {
                    if (dropKeyDown)
                    {
                        if (isShiftDown)
                        {
                            if (Configs.Generic.CARPET_CTRL_Q_CRAFTING.getBooleanValue())
                            {
                                InventoryUtils.dropStack(gui, outputSlot.field_7874);
                            }
                            else
                            {
                                InventoryUtils.dropStacksUntilEmpty(gui, outputSlot.field_7874);
                            }
                        }
                        else
                        {
                            InventoryUtils.dropItem(gui, outputSlot.field_7874);
                        }
                    }
                    else
                    {
                        if (isShiftDown)
                        {
                            InventoryUtils.shiftClickSlot(gui, outputSlot.field_7874);
                        }
                        else
                        {
                            InventoryUtils.moveOneSetOfItemsFromSlotToPlayerInventory(gui, outputSlot);
                        }
                    }
                }
            }
        }
        else if (isPickBlock)
        {
            InventoryUtils.clearFirstCraftingGridOfAllItems(gui);
        }
    }

    public static void tryMoveItemsToFirstCraftingGrid(RecipePattern recipe,
                                                       class_465<? extends class_1703> gui,
                                                       boolean fillStacks)
    {
        class_1735 craftingOutputSlot = CraftingHandler.getFirstCraftingOutputSlotForGui(gui);

        if (craftingOutputSlot != null)
        {
            tryMoveItemsToCraftingGridSlots(recipe, craftingOutputSlot, gui, fillStacks);
        }
    }

    public static void loadRecipeItemsToGridForOutputSlotUnderMouse(RecipePattern recipe,
                                                                    class_465<? extends class_1703> gui)
    {
        class_1735 slot = AccessorUtils.getSlotUnderMouse(gui);
        loadRecipeItemsToGridForOutputSlot(recipe, gui, slot);
    }

    private static void loadRecipeItemsToGridForOutputSlot(RecipePattern recipe,
                                                           class_465<? extends class_1703> gui,
                                                           class_1735 outputSlot)
    {
        if (isCraftingSlot(gui, outputSlot) && isStackEmpty(recipe.getResult()) == false)
        {
            tryMoveItemsToCraftingGridSlots(recipe, outputSlot, gui, false);
        }
    }

    private static boolean tryMoveItemsCrafting(RecipeStorage recipes,
                                                class_1735 slot,
                                                class_465<? extends class_1703> gui,
                                                boolean moveToOtherInventory,
                                                boolean moveStacks,
                                                boolean moveEverything)
    {
        AbstractRecipePattern recipe = recipes.getSelectedRecipe();
        class_1799 stackRecipeOutput = recipe.getResult();

        // Try to craft items
        if (moveToOtherInventory)
        {
            // Items in the output slot
            if (slot.method_7681())
            {
                // The output item matches the current recipe
                if (areStacksEqual(slot.method_7677(), stackRecipeOutput))
                {
                    if (moveEverything)
                    {
                        if (recipe instanceof RecipePattern craftingRecipe)
                        {
                            craftAsManyItemsAsPossible(craftingRecipe, slot, gui);
                        }
                        else
                        {
                            recipe.craftAsManyAsPossible(gui);
                        }
                    }
                    else if (moveStacks)
                    {
                        shiftClickSlot(gui, slot.field_7874);
                    }
                    else
                    {
                        moveOneSetOfItemsFromSlotToPlayerInventory(gui, slot);
                    }
                }
            }
            // Scrolling over an empty output slot, clear the grid
            else
            {
                if (recipe instanceof RecipePattern craftingRecipe)
                {
                    clearCraftingGridOfAllItems(gui, CraftingHandler.getCraftingGridSlots(gui, slot));
                }
            }
        }
        // Try to move items to the grid
        else if (moveToOtherInventory == false && isStackEmpty(stackRecipeOutput) == false)
        {
            if (recipe instanceof RecipePattern craftingRecipe)
            {
                tryMoveItemsToCraftingGridSlots(craftingRecipe, slot, gui, moveStacks);
            }
            else
            {
                recipe.fillInputs(gui, moveStacks, slot);
            }
        }

        return false;
    }

    private static void craftAsManyItemsAsPossible(RecipePattern recipe,
                                                   class_1735 slot,
                                                   class_465<? extends class_1703> gui)
    {
        class_1799 result = recipe.getResult();
        int failSafe = 1024;

        while (failSafe > 0 && slot.method_7681() && areStacksEqual(slot.method_7677(), result))
        {
            shiftClickSlot(gui, slot.field_7874);

            // Ran out of some or all ingredients for the recipe
            if (slot.method_7681() == false || areStacksEqual(slot.method_7677(), result) == false)
            {
                tryMoveItemsToCraftingGridSlots(recipe, slot, gui, true);
            }
            // No change in the result slot after shift clicking, let's assume the craft failed and stop here
            else
            {
                break;
            }

            failSafe--;
        }
    }

    public static void clearFirstCraftingGridOfItems(RecipePattern recipe,
                                                     class_465<? extends class_1703> gui,
                                                     boolean clearNonMatchingOnly)
    {
        class_1735 craftingOutputSlot = CraftingHandler.getFirstCraftingOutputSlotForGui(gui);

        if (craftingOutputSlot != null)
        {
            SlotRange range = CraftingHandler.getCraftingGridSlots(gui, craftingOutputSlot);
            clearCraftingGridOfItems(recipe, gui, range, clearNonMatchingOnly);
        }
    }

    public static void clearFirstCraftingGridOfAllItems(class_465<? extends class_1703> gui)
    {
        class_1735 craftingOutputSlot = CraftingHandler.getFirstCraftingOutputSlotForGui(gui);

        if (craftingOutputSlot != null)
        {
            SlotRange range = CraftingHandler.getCraftingGridSlots(gui, craftingOutputSlot);
            clearCraftingGridOfAllItems(gui, range);
        }
    }

    private static boolean clearCraftingGridOfItems(RecipePattern recipe,
                                                    class_465<? extends class_1703> gui,
                                                    SlotRange range,
                                                    boolean clearNonMatchingOnly)
    {
        final int invSlots = gui.method_17577().field_7761.size();
        final int rangeSlots = range.getSlotCount();
        final int recipeSize = recipe.getRecipeLength();
        final int slotCount = Math.min(rangeSlots, recipeSize);

        for (int i = 0, slotNum = range.getFirst(); i < slotCount && slotNum < invSlots; i++, slotNum++)
        {
            class_1735 slotTmp = gui.method_17577().method_7611(slotNum);

            if (slotTmp != null && slotTmp.method_7681() &&
                (clearNonMatchingOnly == false || areStacksEqual(recipe.getRecipeItems()[i], slotTmp.method_7677()) == false))
            {
                shiftClickSlot(gui, slotNum);

                // Failed to clear the slot
                if (slotTmp.method_7681())
                {
                    dropStack(gui, slotNum);
                }
            }
        }

        return true;
    }

    private static boolean clearCraftingGridOfAllItems(class_465<? extends class_1703> gui, SlotRange range)
    {
        final int invSlots = gui.method_17577().field_7761.size();
        final int rangeSlots = range.getSlotCount();
        boolean clearedAll = true;

        for (int i = 0, slotNum = range.getFirst(); i < rangeSlots && slotNum < invSlots; i++, slotNum++)
        {
            class_1735 slotTmp = gui.method_17577().method_7611(slotNum);

            if (slotTmp != null && slotTmp.method_7681())
            {
                shiftClickSlot(gui, slotNum);

                // Failed to clear the slot
                if (slotTmp.method_7681())
                {
                    clearedAll = false;
                }
            }
        }

        return clearedAll;
    }

    private static boolean tryMoveItemsToCraftingGridSlots(RecipePattern recipe,
                                                           class_1735 slot,
                                                           class_465<? extends class_1703> gui,
                                                           boolean fillStacks)
    {
        class_1703 container = gui.method_17577();
        int numSlots = container.field_7761.size();
        SlotRange range = CraftingHandler.getCraftingGridSlots(gui, slot);

        // Check that the slot range is valid and that the recipe can fit into this type of crafting grid
        if (range != null && range.getLast() < numSlots && recipe.getRecipeLength() <= range.getSlotCount())
        {
            // Clear non-matching items from the grid first
            if (clearCraftingGridOfItems(recipe, gui, range, true) == false)
            {
                return false;
            }

            // This slot is used to check that we get items from a DIFFERENT inventory than where this slot is in
            class_1735 slotGridFirst = container.method_7611(range.getFirst());
            Map<ItemType, IntArrayList> ingredientSlots = ItemType.getSlotsPerItem(recipe.getRecipeItems());

            for (Map.Entry<ItemType, IntArrayList> entry : ingredientSlots.entrySet())
            {
                class_1799 ingredientReference = entry.getKey().stack();
                IntArrayList recipeSlots = entry.getValue();
                IntArrayList targetSlots = new IntArrayList();

                // Get the actual target slot numbers based on the grid's start and the relative positions inside the grid
                for (int s : recipeSlots)
                {
                    targetSlots.add(s + range.getFirst());
                }

                if (fillStacks)
                {
                    fillCraftingGrid(gui, slotGridFirst, ingredientReference, targetSlots);
                }
                else
                {
                    moveOneRecipeItemIntoCraftingGrid(gui, slotGridFirst, ingredientReference, targetSlots);
                }
            }
        }

        return false;
    }

    private static void fillCraftingGrid(class_465<? extends class_1703> gui,
                                         class_1735 slotGridFirst,
                                         class_1799 ingredientReference,
                                         IntArrayList targetSlots)
    {
        class_1703 container = gui.method_17577();
        int slotNum;
        int slotReturn = -1;
        int sizeOrig;

        if (isStackEmpty(ingredientReference))
        {
            return;
        }

        while (true)
        {
            slotNum = getSlotNumberOfLargestMatchingStackFromDifferentInventory(container, slotGridFirst, ingredientReference);

            // Didn't find ingredient items
            if (slotNum < 0)
            {
                break;
            }

            if (slotReturn == -1)
            {
                slotReturn = slotNum;
            }

            // Pick up the ingredient stack from the found slot
            leftClickSlot(gui, slotNum);

            class_1799 stackCursor = gui.method_17577().method_34255();

            // Successfully picked up ingredient items
            if (areStacksEqual(ingredientReference, stackCursor))
            {
                sizeOrig = getStackSize(stackCursor);
                dragSplitItemsIntoSlots(gui, targetSlots);
                stackCursor = gui.method_17577().method_34255();

                // Items left in cursor
                if (isStackEmpty(stackCursor) == false)
                {
                    // Didn't manage to move any items anymore
                    if (getStackSize(stackCursor) >= sizeOrig)
                    {
                        break;
                    }

                    // Collect all the remaining items into the first found slot, as long as possible
                    leftClickSlot(gui, slotReturn);

                    // All of them didn't fit into the first slot anymore, switch into the current source slot
                    if (isStackEmpty(gui.method_17577().method_34255()) == false)
                    {
                        slotReturn = slotNum;
                        leftClickSlot(gui, slotReturn);
                    }
                }
            }
            // Failed to pick up the stack, break to avoid infinite loops
            // TODO: we could also "blacklist" this slot and try to continue...?
            else
            {
                break;
            }

            // Somehow items were left in the cursor, break here
            if (isStackEmpty(gui.method_17577().method_34255()) == false)
            {
                break;
            }
        }

        // Return the rest of the items to the original slot
        if (slotNum >= 0 && isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            leftClickSlot(gui, slotNum);
        }
    }

    public static void rightClickCraftOneStack(class_465<? extends class_1703> gui)
    {
        class_1735 slot = AccessorUtils.getSlotUnderMouse(gui);
        class_1799 stackCursor = gui.method_17577().method_34255();

        if (slot == null || slot.method_7681() == false ||
            (isStackEmpty(stackCursor) == false) && areStacksEqual(slot.method_7677(), stackCursor) == false)
        {
            return;
        }

        int sizeLast = 0;

        while (true)
        {
            rightClickSlot(gui, slot.field_7874);
            stackCursor = gui.method_17577().method_34255();

            // Failed to craft items, or the stack became full, or ran out of ingredients
            if (isStackEmpty(stackCursor) || getStackSize(stackCursor) <= sizeLast ||
                getStackSize(stackCursor) >= stackCursor.method_7914() ||
                areStacksEqual(slot.method_7677(), stackCursor) == false)
            {
                break;
            }

            sizeLast = getStackSize(stackCursor);
        }
    }

    public static void craftEverythingPossibleWithCurrentRecipe(AbstractRecipePattern recipe,
                                                                class_465<? extends class_1703> gui)
    {
        if (recipe instanceof RecipePattern craftingRecipe)
        {
            class_1735 slot = CraftingHandler.getFirstCraftingOutputSlotForGui(gui);

            if (slot != null && isStackEmpty(recipe.getResult()) == false)
            {
                SlotRange range = CraftingHandler.getCraftingGridSlots(gui, slot);

                if (range != null)
                {
                    // Clear all items from the grid first, to avoid unbalanced stacks
                    if (clearCraftingGridOfItems(craftingRecipe, gui, range, false) == false)
                    {
                        return;
                    }

                    tryMoveItemsToCraftingGridSlots(craftingRecipe, slot, gui, true);

                    if (slot.method_7681())
                    {
                        craftAsManyItemsAsPossible(craftingRecipe, slot, gui);
                    }
                }
            }
        }
        else
        {
            recipe.craftEverything(gui);
        }
    }

    public static void moveAllCraftingResultsToOtherInventory(AbstractRecipePattern recipe,
                                                               class_465<? extends class_1703> gui)
    {
        if (recipe instanceof RecipePattern craftingRecipe)
        {
            moveAllCraftingResultsToOtherInventoryImpl(craftingRecipe, gui);
        }
    }

    private static void moveAllCraftingResultsToOtherInventoryImpl(RecipePattern recipe,
                                                                    class_465<? extends class_1703> gui)
    {
        if (isStackEmpty(recipe.getResult()) == false)
        {
            class_1735 slot = null;
            class_1799 stackResult = recipe.getResult().method_7972();

            for (class_1735 slotTmp : gui.method_17577().field_7761)
            {
                // This slot is likely in the player inventory, as there is another inventory above
                if (areStacksEqual(slotTmp.method_7677(), stackResult) &&
                    inventoryExistsAbove(slotTmp, gui.method_17577()))
                {
                    slot = slotTmp;
                    break;
                }
            }

            if (slot != null)
            {
                // Get a list of slots with matching items, which are in the same inventory
                // as the slot that is assumed to be in the player inventory.
                IntArrayList slots = getSlotNumbersOfMatchingStacks(gui.method_17577(), slot, true, stackResult, false, false, false);

                for (int slotNum : slots)
                {
                    shiftClickSlot(gui, slotNum);
                }
            }
        }
    }

    public static void throwAllCraftingResultsToGround(AbstractRecipePattern recipe,
                                                        class_465<? extends class_1703> gui)
    {
        if (recipe instanceof RecipePattern craftingRecipe)
        {
            class_1735 slot = CraftingHandler.getFirstCraftingOutputSlotForGui(gui);

            if (slot != null && isStackEmpty(recipe.getResult()) == false)
            {
                dropStacks(gui, recipe.getResult(), slot, false);
            }
        }
    }

    public static void throwAllNonRecipeItemsToGround(RecipePattern recipe,
                                                      class_465<? extends class_1703> gui)
    {
        class_1735 outputSlot = CraftingHandler.getFirstCraftingOutputSlotForGui(gui);

        if (outputSlot != null && isStackEmpty(recipe.getResult()) == false)
        {
            SlotRange range = CraftingHandler.getCraftingGridSlots(gui, outputSlot);
            class_1799[] recipeItems = recipe.getRecipeItems();
            final int invSlots = gui.method_17577().field_7761.size();
            final int rangeSlots = Math.min(range.getSlotCount(), recipeItems.length);

            for (int i = 0, slotNum = range.getFirst(); i < rangeSlots && slotNum < invSlots; i++, slotNum++)
            {
                class_1735 slotTmp = gui.method_17577().method_7611(slotNum);
                class_1799 stack = slotTmp.method_7677();

                if (stack.method_7960() == false && areStacksEqual(stack, recipeItems[i]) == false)
                {
                    dropAllMatchingStacks(gui, stack);
                }
            }
        }
    }

    public static void setCraftingGridContentsUsingSwaps(class_465<? extends class_1703> gui,
                                                         class_1661 inv,
                                                         RecipePattern recipe,
                                                         class_1735 outputSlot)
    {
        SlotRange range = CraftingHandler.getCraftingGridSlots(gui, outputSlot);

        if (range != null && isStackEmpty(recipe.getResult()) == false)
        {
            class_1799[] recipeItems = recipe.getRecipeItems();
            final int invSlots = gui.method_17577().field_7761.size();
            final int rangeSlots = Math.min(range.getSlotCount(), recipeItems.length);
            IntArrayList toRemove = new IntArrayList();
            boolean movedSomething = false;

            setInhibitCraftingOutputUpdate(true);

            for (int i = 0, slotNum = range.getFirst(); i < rangeSlots && slotNum < invSlots; i++, slotNum++)
            {
                class_1735 craftingTableSlot = gui.method_17577().method_7611(slotNum);
                class_1799 recipeStack = recipeItems[i];
                class_1799 slotStack = craftingTableSlot.method_7677();

                if (areStacksEqual(recipeStack, slotStack) == false)
                {
                    if (recipeStack.method_7960())
                    {
                        toRemove.add(slotNum);
                    }
                    else
                    {
                        int index = getSlotNumberOfLargestMatchingStackFromDifferentInventory(gui.method_17577(), craftingTableSlot, recipeStack);

                        if (index >= 0)
                        {
                            class_1735 ingredientSlot = gui.method_17577().method_7611(index);

                            if (ingredientSlot.field_7871 instanceof class_1661 && ingredientSlot.method_34266() < 9)
                            {
                                // hotbar
                                clickSlot(gui, slotNum, ingredientSlot.method_34266(), class_1713.field_7791);
                            }
                            else
                            {
                                swapSlots(gui, slotNum, index);
                            }
                            movedSomething = true;
                        }
                    }
                }
            }

            movedSomething |= !toRemove.isEmpty();

            for (int slotNum : toRemove)
            {
                shiftClickSlot(gui, slotNum);

                if (isStackEmpty(gui.method_17577().method_7611(slotNum).method_7677()) == false)
                {
                    dropStack(gui, slotNum);
                }
            }

            setInhibitCraftingOutputUpdate(false);

            if (movedSomething)
            {
                updateCraftingOutputSlot(outputSlot);
            }
        }
    }

    private static int putSingleItemIntoSlots(class_465<? extends class_1703> gui,
                                              IntArrayList targetSlots,
                                              int startIndex)
    {
        class_1799 stackInCursor = gui.method_17577().method_34255();

        if (isStackEmpty(stackInCursor))
        {
            return 0;
        }

        int numSlots = gui.method_17577().field_7761.size();
        int numItems = getStackSize(stackInCursor);
        int loops = Math.min(numItems, targetSlots.size() - startIndex);
        int count = 0;

        for (int i = 0; i < loops; i++)
        {
            int slotNum = targetSlots.getInt(startIndex + i);

            if (slotNum >= numSlots)
            {
                break;
            }

            rightClickSlot(gui, slotNum);
            count++;
        }

        return count;
    }

    public static void moveOneSetOfItemsFromSlotToPlayerInventory(class_465<? extends class_1703> gui,
                                                                  class_1735 slot)
    {
        leftClickSlot(gui, slot.field_7874);

        class_1799 stackCursor = gui.method_17577().method_34255();

        if (isStackEmpty(stackCursor) == false)
        {
            IntArrayList slots = getSlotNumbersOfMatchingStacks(gui.method_17577(), slot, false, stackCursor, true, true, false);

            if (moveItemFromCursorToSlots(gui, slots) == false)
            {
                slots = getSlotNumbersOfEmptySlotsInPlayerInventory(gui.method_17577(), false);
                moveItemFromCursorToSlots(gui, slots);
            }
        }
    }

    private static void moveOneRecipeItemIntoCraftingGrid(class_465<? extends class_1703> gui,
                                                          class_1735 slotGridFirst,
                                                          class_1799 ingredientReference,
                                                          IntArrayList targetSlots)
    {
        class_1703 container = gui.method_17577();
        int index = 0;
        int slotNum = -1;
        int slotCount = targetSlots.size();

        while (index < slotCount)
        {
            slotNum = getSlotNumberOfSmallestStackFromDifferentInventory(container, slotGridFirst, ingredientReference, slotCount);

            // Didn't find ingredient items
            if (slotNum < 0)
            {
                break;
            }

            // Pick up the ingredient stack from the found slot
            leftClickSlot(gui, slotNum);

            // Successfully picked up ingredient items
            if (areStacksEqual(ingredientReference, gui.method_17577().method_34255()))
            {
                int filled = putSingleItemIntoSlots(gui, targetSlots, index);
                index += filled;

                if (filled < 1)
                {
                    break;
                }
            }
            // Failed to pick up the stack, break to avoid infinite loops
            // TODO: we could also "blacklist" this slot and try to continue...?
            else
            {
                break;
            }
        }

        // Return the rest of the items to the original slot
        if (slotNum >= 0 && isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            leftClickSlot(gui, slotNum);
        }
    }

    private static boolean moveItemFromCursorToSlots(class_465<? extends class_1703> gui,
                                                     IntArrayList slotNumbers)
    {
        for (int slotNum : slotNumbers)
        {
            leftClickSlot(gui, slotNum);

            if (isStackEmpty(gui.method_17577().method_34255()))
            {
                return true;
            }
        }

        return false;
    }

    public static void moveItemsFromInventory(class_465<? extends class_1703> gui,
                                               int slotTo,
                                               class_1263 invSrc,
                                               class_1799 stackTemplate,
                                               boolean fillStacks)
    {
        class_1703 container = gui.method_17577();

        for (class_1735 slot : container.field_7761)
        {
            if (slot == null)
            {
                continue;
            }

            if (slot.field_7871 == invSrc && areStacksEqual(stackTemplate, slot.method_7677()))
            {
                if (fillStacks)
                {
                    if (clickSlotsToMoveItems(gui, slot.field_7874, slotTo) == false)
                    {
                        break;
                    }
                }
                else
                {
                    clickSlotsToMoveSingleItem(gui, slot.field_7874, slotTo);
                    break;
                }
            }
        }
    }

    private static int getSlotNumberOfLargestMatchingStackFromDifferentInventory(class_1703 container,
                                                                                 class_1735 slotReference,
                                                                                 class_1799 stackReference)
    {
        int slotNum = -1;
        int largest = 0;

        for (class_1735 slot : container.field_7761)
        {
            if (areSlotsInSameInventory(slot, slotReference) == false && slot.method_7681() &&
                areStacksEqual(stackReference, slot.method_7677()))
            {
                int stackSize = getStackSize(slot.method_7677());

                if (stackSize > largest)
                {
                    slotNum = slot.field_7874;
                    largest = stackSize;
                }
            }
        }

        return slotNum;
    }

    /**
     * Returns the slot number of the slot that has the smallest stackSize that is still equal to or larger
     * than idealSize. The slot must also NOT be in the same inventory as slotReference.
     * If an adequately large stack is not found, then the largest one is selected.
     */
    private static int getSlotNumberOfSmallestStackFromDifferentInventory(class_1703 container,
                                                                          class_1735 slotReference,
                                                                          class_1799 stackReference,
                                                                          int idealSize)
    {
        int slotNumSmallest = -1;
        int slotNumLargest = -1;
        int smallest = Integer.MAX_VALUE;
        int largest = 0;

        for (class_1735 slot : container.field_7761)
        {
            if (areSlotsInSameInventory(slot, slotReference) == false && slot.method_7681() &&
                areStacksEqual(stackReference, slot.method_7677()))
            {
                int stackSize = getStackSize(slot.method_7677());

                if (stackSize < smallest && stackSize >= idealSize)
                {
                    slotNumSmallest = slot.field_7874;
                    smallest = stackSize;
                }

                if (stackSize > largest)
                {
                    slotNumLargest = slot.field_7874;
                    largest = stackSize;
                }
            }
        }

        return slotNumSmallest != -1 ? slotNumSmallest : slotNumLargest;
    }

    /**
     * Return the slot numbers of slots that have items identical to stackReference.
     * If preferPartial is true, then stacks with a stackSize less that getMaxStackSize() are
     * at the beginning of the list (not ordered though) and full stacks are at the end, otherwise the reverse is true.
     * @param container
     * @param slotReference
     * @param sameInventory if true, then the returned slots are from the same inventory, if false, then from a different inventory
     * @param stackReference
     * @param preferPartial
     * @param treatHotbarAsDifferent
     * @param reverse if true, returns the slots starting from the end of the inventory
     * @return
     */
    @SuppressWarnings("SameParameterValue")
    private static IntArrayList getSlotNumbersOfMatchingStacks(class_1703 container,
                                                               class_1735 slotReference,
                                                               boolean sameInventory,
                                                               class_1799 stackReference,
                                                               boolean preferPartial,
                                                               boolean treatHotbarAsDifferent,
                                                               boolean reverse)
    {
        IntArrayList slots = new IntArrayList(64);
        final int maxSlot = container.field_7761.size() - 1;
        final int increment = reverse ? -1 : 1;

        for (int i = reverse ? maxSlot : 0; i >= 0 && i <= maxSlot; i += increment)
        {
            class_1735 slot = container.method_7611(i);

            if (slot != null && slot.method_7681() &&
                areSlotsInSameInventory(slot, slotReference, treatHotbarAsDifferent) == sameInventory &&
                areStacksEqual(slot.method_7677(), stackReference))
            {
                if ((getStackSize(slot.method_7677()) < stackReference.method_7914()) == preferPartial)
                {
                    slots.add(0, slot.field_7874);
                }
                else
                {
                    slots.add(slot.field_7874);
                }
            }
        }

        return slots;
    }

    @SuppressWarnings("SameParameterValue")
    private static IntArrayList getSlotNumbersOfMatchingStacks(class_1703 container,
                                                               class_1799 stackReference,
                                                               boolean preferPartial)
    {
        IntArrayList slots = new IntArrayList(64);
        final int maxSlot = container.field_7761.size() - 1;

        for (int i = 0; i <= maxSlot; ++i)
        {
            class_1735 slot = container.method_7611(i);

            if (slot != null && slot.method_7681() && areStacksEqual(slot.method_7677(), stackReference))
            {
                if ((getStackSize(slot.method_7677()) < stackReference.method_7914()) == preferPartial)
                {
                    slots.add(0, slot.field_7874);
                }
                else
                {
                    slots.add(slot.field_7874);
                }
            }
        }

        return slots;
    }

    public static int getPlayerInventoryIndexWithItem(class_1799 stackReference, class_1661 inv)
    {
        final int size = inv.field_7547.size();

        for (int index = 0; index < size; ++index)
        {
            class_1799 stack = inv.field_7547.get(index);

            if (areStacksEqual(stack, stackReference))
            {
                return index;
            }
        }

        return -1;
    }

    @SuppressWarnings("SameParameterValue")
    private static IntArrayList getSlotNumbersOfEmptySlots(class_1703 container,
                                                           class_1735 slotReference,
                                                           boolean sameInventory,
                                                           boolean treatHotbarAsDifferent,
                                                           boolean reverse)
    {
        IntArrayList slots = new IntArrayList(64);
        final int maxSlot = container.field_7761.size() - 1;
        final int increment = reverse ? -1 : 1;

        for (int i = reverse ? maxSlot : 0; i >= 0 && i <= maxSlot; i += increment)
        {
            class_1735 slot = container.method_7611(i);

            if (slot != null && slot.method_7681() == false &&
                areSlotsInSameInventory(slot, slotReference, treatHotbarAsDifferent) == sameInventory)
            {
                slots.add(slot.field_7874);
            }
        }

        return slots;
    }

    @SuppressWarnings("SameParameterValue")
    private static IntArrayList getSlotNumbersOfEmptySlotsInPlayerInventory(class_1703 container,
                                                                            boolean reverse)
    {
        IntArrayList slots = new IntArrayList(64);
        final int maxSlot = container.field_7761.size() - 1;
        final int increment = reverse ? -1 : 1;

        for (int i = reverse ? maxSlot : 0; i >= 0 && i <= maxSlot; i += increment)
        {
            class_1735 slot = container.method_7611(i);

            if (slot != null && (slot.field_7871 instanceof class_1661) && slot.method_7681() == false)
            {
                slots.add(slot.field_7874);
            }
        }

        return slots;
    }

    public static boolean areStacksEqual(class_1799 stack1, class_1799 stack2)
    {
        return class_1799.method_31577(stack1, stack2);
    }

    private static boolean areSlotsInSameInventory(class_1735 slot1, class_1735 slot2)
    {
        return areSlotsInSameInventory(slot1, slot2, false);
    }

    private static boolean areSlotsInSameInventory(class_1735 slot1, class_1735 slot2, boolean treatHotbarAsDifferent)
    {
        if (slot1.field_7871 == slot2.field_7871)
        {
            if (treatHotbarAsDifferent && slot1.field_7871 instanceof class_1661)
            {
                int index1 = AccessorUtils.getSlotIndex(slot1);
                int index2 = AccessorUtils.getSlotIndex(slot2);
                // Don't ever treat the offhand slot as a different inventory
                return index1 == 40 || index2 == 40 || (index1 < 9) == (index2 < 9);
            }

            return true;
        }

        return false;
    }

    private static class_1799[] getOriginalStacks(class_1703 container)
    {
        class_1799[] originalStacks = new class_1799[container.field_7761.size()];

        for (int i = 0; i < originalStacks.length; i++)
        {
            originalStacks[i] = container.field_7761.get(i).method_7677().method_7972();
        }

        return originalStacks;
    }

    private static void restoreOriginalStacks(class_1703 container, class_1799[] originalStacks)
    {
        for (int i = 0; i < originalStacks.length; i++)
        {
            class_1799 stackSlot = container.method_7611(i).method_7677();

            if (areStacksEqual(stackSlot, originalStacks[i]) == false ||
                (isStackEmpty(stackSlot) == false && getStackSize(stackSlot) != getStackSize(originalStacks[i])))
            {
                container.method_7611(i).method_7673(originalStacks[i]);
            }
        }
    }

    private static int getTargetSlot(class_1703 container, class_1799[] originalStacks)
    {
        List<class_1735> slots = container.field_7761;

        for (int i = 0; i < originalStacks.length; i++)
        {
            class_1799 stackOrig = originalStacks[i];
            class_1799 stackNew = slots.get(i).method_7677();

            if ((isStackEmpty(stackOrig) && isStackEmpty(stackNew) == false) ||
               (isStackEmpty(stackOrig) == false && isStackEmpty(stackNew) == false &&
               getStackSize(stackNew) == (getStackSize(stackOrig) + 1)))
            {
                return i;
            }
        }

        return -1;
    }

    /*
    private void clickSlotsToMoveItems(Slot slot, ContainerScreen<? extends Container> gui, boolean matchingOnly, boolean toOtherInventory)
    {
        for (Slot slotTmp : gui.getContainer().slots)
        {
            if (slotTmp.id != slot.id && areSlotsInSameInventory(slotTmp, slot) == toOtherInventory &&
                slotTmp.hasStack() && (matchingOnly == false || areStacksEqual(slot.getStack(), slotTmp.getStack())))
            {
                this.clickSlotsToMoveItemsFromSlot(slotTmp, gui, toOtherInventory);
                return;
            }
        }

        // Move the hovered-over slot's stack last
        if (toOtherInventory)
        {
            this.clickSlotsToMoveItemsFromSlot(slot, gui, toOtherInventory);
        }
    }
    */

    private static void clickSlotsToMoveItemsFromSlot(class_1735 slotFrom,
                                                      class_465<? extends class_1703> gui,
                                                      boolean toOtherInventory)
    {
        // Left click to pick up the found source stack
        leftClickSlot(gui, slotFrom.field_7874);

        if (isStackEmpty(gui.method_17577().method_34255()))
        {
            return;
        }

        for (class_1735 slotDst : gui.method_17577().field_7761)
        {
            class_1799 stackDst = slotDst.method_7677();

            if (areSlotsInSameInventory(slotDst, slotFrom) != toOtherInventory &&
                (isStackEmpty(stackDst) || areStacksEqual(stackDst, gui.method_17577().method_34255())))
            {
                // Left click to (try and) place items to the slot
                leftClickSlot(gui, slotDst.field_7874);
            }

            if (isStackEmpty(gui.method_17577().method_34255()))
            {
                return;
            }
        }

        // Couldn't fit the entire stack to the target inventory, return the rest of the items
        if (isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            leftClickSlot(gui, slotFrom.field_7874);
        }
    }

    private static boolean clickSlotsToMoveSingleItem(class_465<? extends class_1703> gui,
                                                      int slotFrom,
                                                      int slotTo)
    {
        //System.out.println("clickSlotsToMoveSingleItem(from: " + slotFrom + ", to: " + slotTo + ")");
        class_1799 stack = gui.method_17577().field_7761.get(slotFrom).method_7677();

        if (isStackEmpty(stack))
        {
            return false;
        }

        // Click on the from-slot to take items to the cursor - if there is more than one item in the from-slot,
        // right click on it, otherwise left click.
        if (getStackSize(stack) > 1)
        {
            rightClickSlot(gui, slotFrom);
        }
        else
        {
            leftClickSlot(gui, slotFrom);
        }

        // Right click on the target slot to put one item to it
        rightClickSlot(gui, slotTo);

        // If there are items left in the cursor, then return them back to the original slot
        if (isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            // Left click again on the from-slot to return the rest of the items to it
            leftClickSlot(gui, slotFrom);
        }

        return true;
    }

    private static boolean clickSlotsToMoveSingleItemByShiftClick(class_465<? extends class_1703> gui,
                                                                  int slotFrom)
    {
        class_1735 slot = gui.method_17577().field_7761.get(slotFrom);
        class_1799 stack = slot.method_7677();

        if (isStackEmpty(stack))
        {
            return false;
        }

        if (getStackSize(stack) > 1)
        {
            // Left click on the from-slot to take all the items to the cursor
            leftClickSlot(gui, slotFrom);

            // Still items left in the slot, put the stack back and abort
            if (slot.method_7681())
            {
                leftClickSlot(gui, slotFrom);
                return false;
            }
            else
            {
                // Right click one item back to the slot
                rightClickSlot(gui, slotFrom);
            }
        }

        // ... and then shift-click on the slot
        shiftClickSlot(gui, slotFrom);

        if (isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            // ... and then return the rest of the items
            leftClickSlot(gui, slotFrom);
        }

        return true;
    }

    /**
     * Try move items from slotFrom to slotTo
     * @return true if at least some items were moved
     */
    private static boolean clickSlotsToMoveItems(class_465<? extends class_1703> gui,
                                                 int slotFrom,
                                                 int slotTo)
    {
        //System.out.println("clickSlotsToMoveItems(from: " + slotFrom + ", to: " + slotTo + ")");

        // Left click to take items
        leftClickSlot(gui, slotFrom);

        // Couldn't take the items, bail out now
        if (isStackEmpty(gui.method_17577().method_34255()))
        {
            return false;
        }

        boolean ret = true;
        int size = getStackSize(gui.method_17577().method_34255());

        // Left click on the target slot to put the items to it
        leftClickSlot(gui, slotTo);

        // If there are items left in the cursor, then return them back to the original slot
        if (isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            ret = getStackSize(gui.method_17577().method_34255()) != size;

            // Left click again on the from-slot to return the rest of the items to it
            leftClickSlot(gui, slotFrom);
        }

        return ret;
    }

    public static void dropStacksUntilEmpty(class_465<? extends class_1703> gui,
                                            int slotNum)
    {
        if (slotNum >= 0 && slotNum < gui.method_17577().field_7761.size())
        {
            class_1735 slot = gui.method_17577().method_7611(slotNum);
            int failsafe = 64;

            while (failsafe-- > 0 && slot.method_7681())
            {
                dropStack(gui, slotNum);
            }
        }
    }

    public static void dropStacksWhileHasItem(class_465<? extends class_1703> gui,
                                              int slotNum,
                                              class_1799 stackReference)
    {
        if (slotNum >= 0 && slotNum < gui.method_17577().field_7761.size())
        {
            class_1735 slot = gui.method_17577().method_7611(slotNum);
            int failsafe = 256;

            while (failsafe-- > 0 && areStacksEqual(slot.method_7677(), stackReference))
            {
                dropStack(gui, slotNum);
            }
        }
    }

    private static boolean shiftClickSlotWithCheck(class_465<? extends class_1703> gui,
                                                   int slotNum)
    {
        class_1735 slot = gui.method_17577().method_7611(slotNum);

        if (slot == null || slot.method_7681() == false)
        {
            return false;
        }

        int sizeOrig = getStackSize(slot.method_7677());
        shiftClickSlot(gui, slotNum);

        return slot.method_7681() == false || getStackSize(slot.method_7677()) != sizeOrig;
    }

    public static boolean tryMoveItemsVertically(class_465<? extends class_1703> gui,
                                                 class_1735 slot,
                                                 boolean moveUp,
                                                 MoveAmount amount)
    {
        // We require an empty cursor
        if (slot == null || isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            return false;
        }

        IntArrayList slots = getVerticallyFurthestSuitableSlotsForStackInSlot(gui.method_17577(), slot, moveUp);

        if (slots.isEmpty())
        {
            return false;
        }

        if (amount == MoveAmount.FULL_STACKS)
        {
            moveStackToSlots(gui, slot, slots, false);
        }
        else if (amount == MoveAmount.MOVE_ONE)
        {
            moveOneItemToFirstValidSlot(gui, slot, slots);
        }
        else if (amount == MoveAmount.LEAVE_ONE)
        {
            moveStackToSlots(gui, slot, slots, true);
        }
        else if (amount == MoveAmount.ALL_MATCHING)
        {
            moveMatchingStacksToSlots(gui, slot, moveUp);
        }

        return true;
    }

    private static void moveMatchingStacksToSlots(class_465<? extends class_1703> gui,
                                                  class_1735 slot,
                                                  boolean moveUp)
    {
        IntArrayList matchingSlots = getSlotNumbersOfMatchingStacks(gui.method_17577(), slot, true, slot.method_7677(), true, true, false);
        IntArrayList targetSlots = getSlotNumbersOfEmptySlots(gui.method_17577(), slot, false, true, false);
        targetSlots.addAll(getSlotNumbersOfEmptySlots(gui.method_17577(), slot, true, true, false));
        targetSlots.addAll(matchingSlots);

        matchingSlots.sort(new SlotVerticalSorterSlotNumbers(gui.method_17577(), !moveUp));
        targetSlots.sort(new SlotVerticalSorterSlotNumbers(gui.method_17577(), moveUp));

        for (int matchingSlot : matchingSlots)
        {
            int srcSlotNum = matchingSlot;
            class_1735 srcSlot = gui.method_17577().method_7611(srcSlotNum);
            class_1735 lastSlot = moveStackToSlots(gui, srcSlot, targetSlots, false);

            if (lastSlot == null || (lastSlot.field_7874 == srcSlot.field_7874 || (lastSlot.field_7872 > srcSlot.field_7872) == moveUp))
            {
                return;
            }
        }
    }

    private static class_1735 moveStackToSlots(class_465<? extends class_1703> gui,
                                         class_1735 slotFrom,
                                         IntArrayList slotsTo,
                                         boolean leaveOne)
    {
        class_1735 lastSlot = null;

        // Empty slot, nothing to do
        if (slotFrom.method_7681() == false)
        {
            return null;
        }

        // Pick up the stack
        leftClickSlot(gui, slotFrom.field_7874);

        if (leaveOne)
        {
            rightClickSlot(gui, slotFrom.field_7874);
        }

        for (int slotNum : slotsTo)
        {
            // Empty cursor, all done here
            if (isStackEmpty(gui.method_17577().method_34255()))
            {
                break;
            }

            class_1735 dstSlot = gui.method_17577().method_7611(slotNum);

            if (dstSlot.method_7680(gui.method_17577().method_34255()) &&
                (dstSlot.method_7681() == false || areStacksEqual(dstSlot.method_7677(), gui.method_17577().method_34255())))
            {
                leftClickSlot(gui, slotNum);
                lastSlot = dstSlot;
            }
        }

        // Return the rest of the items, if any
        if (isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            leftClickSlot(gui, slotFrom.field_7874);
        }

        return lastSlot;
    }

    private static void moveOneItemToFirstValidSlot(class_465<? extends class_1703> gui,
                                                    class_1735 slotFrom,
                                                    IntArrayList slotsTo)
    {
        // Pick up half of the the stack
        rightClickSlot(gui, slotFrom.field_7874);

        if (isStackEmpty(gui.method_17577().method_34255()))
        {
            return;
        }

        int sizeOrig = getStackSize(gui.method_17577().method_34255());

        for (int slotNum : slotsTo)
        {
            rightClickSlot(gui, slotNum);
            class_1799 stackCursor = gui.method_17577().method_34255();

            if (isStackEmpty(stackCursor) || getStackSize(stackCursor) != sizeOrig)
            {
                break;
            }
        }

        // Return the rest of the items, if any
        if (isStackEmpty(gui.method_17577().method_34255()) == false)
        {
            leftClickSlot(gui, slotFrom.field_7874);
        }
    }

    private static IntArrayList getVerticallyFurthestSuitableSlotsForStackInSlot(class_1703 container,
                                                                                  class_1735 slotIn,
                                                                                  boolean above)
    {
        if (slotIn == null || slotIn.method_7681() == false)
        {
            return IntArrayList.of();
        }

        IntArrayList slotNumbers = new IntArrayList();
        class_1799 stackSlot = slotIn.method_7677();

        for (class_1735 slotTmp : container.field_7761)
        {
            if (slotTmp.field_7874 != slotIn.field_7874 && slotTmp.field_7872 != slotIn.field_7872)
            {
                if (above == slotTmp.field_7872 < slotIn.field_7872)
                {
                    class_1799 stackTmp = slotTmp.method_7677();

                    if ((isStackEmpty(stackTmp) && slotTmp.method_7680(stackSlot)) ||
                        (areStacksEqual(stackTmp, stackSlot)) && slotTmp.method_7676(stackTmp) > getStackSize(stackTmp))
                    {
                        slotNumbers.add(slotTmp.field_7874);
                    }
                }
            }
        }

        slotNumbers.sort(new SlotVerticalSorterSlotNumbers(container, above));

        return slotNumbers;
    }

    public static void tryClearCursor(class_465<? extends class_1703> gui)
    {
        class_1799 stackCursor = gui.method_17577().method_34255();

        if (isStackEmpty(stackCursor) == false)
        {
            IntArrayList emptySlots = getSlotNumbersOfEmptySlotsInPlayerInventory(gui.method_17577(), false);

            if (emptySlots.isEmpty() == false)
            {
                leftClickSlot(gui, emptySlots.getInt(0));
            }
            else
            {
                IntArrayList matchingSlots = getSlotNumbersOfMatchingStacks(gui.method_17577(), stackCursor, true);

                if (matchingSlots.isEmpty() == false)
                {
                    for (int slotNum : matchingSlots)
                    {
                        class_1735 slot = gui.method_17577().method_7611(slotNum);
                        class_1799 stackSlot = slot.method_7677();

                        if (slot == null || areStacksEqual(stackSlot, stackCursor) == false ||
                            getStackSize(stackSlot) >= stackCursor.method_7914())
                        {
                            break;
                        }

                        if (slot.field_7871 instanceof class_1661)
                        {
                            leftClickSlot(gui, slotNum);
                            stackCursor = gui.method_17577().method_34255();
                        }
                    }
                }
            }

            if (isStackEmpty(gui.method_17577().method_34255()) == false)
            {
                dropItemsFromCursor(gui);
            }
        }
    }

    public static void resetLastSlotNumber()
    {
        slotNumberLast = -1;
    }

    public static MoveAction getActiveMoveAction()
    {
        return activeMoveAction;
    }

    public static void sortInventory(class_465<?> gui)
    {
        Pair<Integer, Integer> range = new IntIntMutablePair(Integer.MAX_VALUE, 0);
        class_1735 focusedSlot = AccessorUtils.getSlotUnderMouse(gui);
        class_310 mc = GameWrap.getClient();
        boolean shulkerBoxFix;

        if (focusedSlot == null)
        {
            return;
        }

        //System.out.printf("sort - focusedSlot[%d]: %s\n", focusedSlot.id, focusedSlot.hasStack() ? focusedSlot.getStack().getName().getString() : "<EMPTY>");
        class_1703 container = gui.method_17577();
        int limit = container.field_7761.size();
        int focusedIndex = -1;

        if (gui instanceof class_481 creative && !creative.method_47424())
        {
            return;
        }
        if (gui instanceof class_490 && (focusedSlot.field_7874 < 9 || focusedSlot.field_7874 > 44))
        {
            return;
        }

        // Do not try to sort shulkers inside a shulker
        shulkerBoxFix = gui instanceof class_495 && focusedSlot.field_7874 < 27;

        for (int i = 0; i < limit; i++)
        {
            class_1735 slot = container.field_7761.get(i);

            //System.out.printf("sort - slot[%d]: %s\n", i, slot.hasStack() ? slot.getStack().getName().getString() : "<EMPTY>");
            if (slot == focusedSlot)
            {
                focusedIndex = i;
            }
            if (slot.field_7871 == focusedSlot.field_7871)
            {
                if (i < range.first())
                {
                    range.first(i);
                }
                if (i >= range.second())
                {
                    range.second(i + 1);
                }
            }
        }

        if (focusedIndex == -1)
        {
            return;
        }

        if (focusedSlot.field_7871 instanceof class_1661)
        {
            if (range.left() == 5 && range.right() == 46)
            {
                // Creative, PlayerScreenHandler
                if (focusedIndex >= 9 && focusedIndex < 36)
                {
                    range.left(9).right(36);
                }
                else if (focusedIndex >= 36 && focusedIndex < 45)
                {
                    range.left(36).right(45);
                }
            }
            else if (range.right() - range.left() == 36)
            {
                // Normal containers
                if (focusedIndex < range.left() + 27)
                {
                    range.right(range.left() + 27);
                }
                else
                {
                    range.left(range.right() - 9);
                }
            }
        }

        // try to find usable hotbar slot
        int hotbarSlot = 8;
        if ( shulkerBoxFix )
        {
            var playerInventory = class_310.method_1551().field_1724.method_31548();
            while ( hotbarSlot >= 0 )
            {
                int slot_ix = container.method_37418(playerInventory, hotbarSlot).orElse(-1);
                if ( slot_ix != -1 && !isShulkerBox(container.method_7611(slot_ix).method_7677()) )
                {
                    break;
                }

                --hotbarSlot;
            }

            if ( hotbarSlot < 0 )
            {
                ItemScroller.LOGGER.warn("sortInventory(): no usable hotbar slot to sort shulkerbox");
                return;
            }
        }

        final int swapSlot = hotbarSlot;

        //System.out.printf("Sorting [%d, %d] (first, second)\n", range.first(), range.second());
        //System.out.printf("Sorting [%d, %d] (left, right)\n", range.left(), range.right());
        tryClearCursor(gui);
        tryMergeItems(gui, range.left(), range.right() - 1);

        if (Configs.Generic.SORT_ASSUME_EMPTY_BOX_STACKS.getBooleanValue())
        {
            class_2799 packet = new class_2799(class_2799.class_2800.field_12775);

            mc.method_1562().method_52787(packet);
            selectedSlotUpdateTask = () -> trySort(gui, range.first(), range.second(), shulkerBoxFix, swapSlot);
        }
        else
        {
            trySort(gui, range.first(), range.second(), shulkerBoxFix, swapSlot);
        }
    }

    private static void trySort(class_465<?> gui, int start, int end, boolean shulkerBoxFix, int swapSlot)
    {
        try
        {
            quickSort(gui, start, end, shulkerBoxFix, swapSlot);
        }
        catch (Exception err)
        {
            ItemScroller.LOGGER.error("trySort(): failed to sort items", err);
        }
    }

    private static void quickSort(class_465<?> gui, int start, int end, boolean shulkerBoxFix, int swapSlot)
    {
        var ct = end - start;
        var handler = gui.method_17577();

        // make snapshot of contents; give each item a temporary ID.
        // this ID also happens to be its slot index, relative to `start`.
        var snapshot = new ArrayList<>
        (
                IntStream.range(0, end - start)
                    .mapToObj(ix -> Pair.of(ix, handler.method_7611(start + ix).method_7677().method_7972()))
                    .filter(pair -> !(shulkerBoxFix && isShulkerBox(pair.value())))
                    .toList()
        );
        ct = snapshot.size();

        // because the array might have unsortable holes, build an index from array index to slot index
        int[] slotindex_by_arrayindex = snapshot.stream().mapToInt(pair -> start + pair.key()).toArray();

        // sort pairs
        List<Pair<Integer, class_1799>> sorted_pairs =
        (
            snapshot.stream()
                .sorted(
                    (left, right) ->
                        compareStacks(left.value(), right.value())
                    )
                .toList()
        );

        ItemScroller.LOGGER.debug(String.format
        (
            "======\nsort\n%s\n\n",
            IntStream.range(0, ct)
                .mapToObj(
                    ix -> String.format(
                        "%2d: %2d/%-20s  %2d/%-20s",
                        ix,
                        snapshot.get(ix).key(), snapshot.get(ix).value().method_7964().getString(),
                        sorted_pairs.get(ix).key(),sorted_pairs.get(ix).value().method_7964().getString()
                    )
                )
                .collect(Collectors.joining("\n"))
        ));

        // build index of an item's final position by its fake ID
        Map<Integer, Integer> finalpos_by_id =
        (
            IntStream.range(0, ct).boxed()
                .collect(Collectors.toMap(
                    ix -> sorted_pairs.get(ix).key(),
                    ix -> ix
                ))
        );

        // sort
        int limit = 0, max_limit = 200;
        Pair<Integer,class_1799> dst, hold = null;

        for (int src_ix = 0; src_ix < ct; ++src_ix)
        {
            // check if item is in correct position
            Pair<Integer,class_1799> src = snapshot.get(src_ix);
            int src_id = src.key();
            int dst_ix = finalpos_by_id.get(src_id);

            dst = snapshot.get(dst_ix);

            if (src_ix == dst_ix)
            {
                ItemScroller.LOGGER.debug("quickSort(): {} ok", src_ix);
                continue;
            }

            // pick up and hold "src"
            snapshot.set(src_ix, hold);
            hold = src;
            ItemScroller.LOGGER.debug("quickSort(): pick up {}; holding {}", src_ix, hold);
            clickSlot(gui, slotindex_by_arrayindex[src_ix], swapSlot, class_1713.field_7791);

            // continually place the held item into its correct place, following the chain to its end
            // todo: we could skip swapping empty slots, but for some reason, this is not reliable. it seems to swap
            //       in an item from the player's hotbar into the container.
            for (limit = 0; limit < max_limit; ++limit)
            {
                snapshot.set(dst_ix, hold);
                hold = dst;
                clickSlot(gui, slotindex_by_arrayindex[dst_ix], swapSlot, class_1713.field_7791);

                ItemScroller.LOGGER.debug("quickSort(): ... swap {} {}; holding {}", dst_ix, dst != null ? dst.value() : "null", hold);
                if (hold == null)
                {
                    break;
                }

                dst_ix = finalpos_by_id.get(hold.key());
                dst = snapshot.get(dst_ix);
            }

            if (limit == max_limit)
            {
                ItemScroller.LOGGER.warn("quickSort(): took too long to follow swap chain ??");
            }

        }
        if (hold != null)
        {
            ItemScroller.LOGGER.warn("quickSort(): sorting complete, but still holding {} ??", hold);
        }
    }

    private static int compareStacks(class_1799 stack1, class_1799 stack2)
    {
        class_310 mc = GameWrap.getClient();

        stack1 = stack1 != null ? stack1 : class_1799.field_8037;
        stack2 = stack2 != null ? stack2 : class_1799.field_8037;

        // boxes towards the end of the list
        boolean stack1IsBox = isShulkerBox(stack1);
        boolean stack2IsBox = isShulkerBox(stack2);

        if (Configs.Generic.SORT_SHULKER_BOXES_AT_END.getBooleanValue() && stack1IsBox != stack2IsBox)
        {
            return Boolean.compare(stack1IsBox, stack2IsBox);
        }

        // bundles towards the end of the list
        boolean stack1IsBundle = isBundle(stack1);
        boolean stack2IsBundle = isBundle(stack2);

        if (Configs.Generic.SORT_BUNDLES_AT_END.getBooleanValue() && stack1IsBundle != stack2IsBundle)
        {
            return Boolean.compare(stack1IsBundle, stack2IsBundle);
        }

        // order items according to user-defined top/bottom priority
        // a priority of -1 means that no priority was specified
        int priority1 = getCustomPriority(stack1);
        int priority2 = getCustomPriority(stack2);

        if (priority1 != -1 || priority2 != -1)
        {
            return Integer.compare(priority1, priority2);
        }

        // empty slots last
        boolean stack1IsEmpty = stack1.method_7960();
        boolean stack2IsEmpty = stack2.method_7960();

        if (stack1IsEmpty != stack2IsEmpty)
        {
            return Boolean.compare(stack1IsEmpty, stack2IsEmpty);
        }

        if (stack1IsEmpty)
        {
            // both stacks are empty
            return 0;
        }

        // sort by shulker box contents
        if (stack1IsBox && stack2IsBox)
        {
            List<class_1799> contents1 = stack1.method_57825(class_9334.field_49622, class_9288.field_49334).method_59712().toList();
            List<class_1799> contents2 = stack2.method_57825(class_9334.field_49622, class_9288.field_49334).method_59712().toList();
            int flip = (Configs.Generic.SORT_SHULKER_BOXES_INVERTED.getBooleanValue() ? -1 : 1);

            return Integer.compare(contents1.size(), contents2.size()) * flip;
        }

        // sort by bundle contents
        if (stack1IsBundle && stack2IsBundle)
        {
            class_9276 bundle1 = stack1.method_57825(class_9334.field_49650, class_9276.field_49289);
            class_9276 bundle2 = stack2.method_57825(class_9334.field_49650, class_9276.field_49289);
            int flip = (Configs.Generic.SORT_BUNDLES_INVERTED.getBooleanValue() ? -1 : 1);
            Fraction occupancy1 = bundle1.method_57428();
            Fraction occupancy2 = bundle2.method_57428();

            return occupancy1.compareTo(occupancy2) * flip;
        }

        SortingMethod method = (SortingMethod) Configs.Generic.SORT_METHOD_DEFAULT.getOptionListValue();

        if (method.equals(SortingMethod.CATEGORY_NAME) ||
            method.equals(SortingMethod.CATEGORY_COUNT) ||
            method.equals(SortingMethod.CATEGORY_RARITY) ||
            method.equals(SortingMethod.CATEGORY_RAWID) &&
            mc.field_1687 != null)
        {
            // Sort by category
            if (displayContext == null)
            {
                displayContext = SortingCategory.INSTANCE.buildDisplayContext(mc);
                // This isn't used here, but it is required to build the list of items,
                // as if we are opening the Creative Inventory Screen.
            }

            SortingCategory.Entry cat1 = SortingCategory.INSTANCE.fromItemStack(stack1);
            SortingCategory.Entry cat2 = SortingCategory.INSTANCE.fromItemStack(stack2);

            if (!cat1.getStringValue().equals(cat2.getStringValue()))
            {
                int index1 = Configs.Generic.SORT_CATEGORY_ORDER.getEntryIndex(cat1);
                int index2 = Configs.Generic.SORT_CATEGORY_ORDER.getEntryIndex(cat2);
                boolean stack1UnspecifiedCategoryPriority = index1 == -1;
                boolean stack2UnspecifiedCategoryPriority = index2 == -1;

                if ( stack1UnspecifiedCategoryPriority != stack2UnspecifiedCategoryPriority)
                {
                    return Boolean.compare(stack1UnspecifiedCategoryPriority, stack2UnspecifiedCategoryPriority);
                }

                return Integer.compare(index1, index2);
            }
        }

        if (stack1.method_7909() != stack2.method_7909())
        {
            if (method.equals(SortingMethod.CATEGORY_NAME) || method.equals(SortingMethod.ITEM_NAME))
            {
                // Sort by Item Name
                return stack1.method_7964().getString().compareTo(stack2.method_7964().getString());
            }
            else if (method.equals(SortingMethod.CATEGORY_COUNT) || method.equals(SortingMethod.ITEM_COUNT))
            {
                // Sort by Item Count
                int result = Integer.compare(stack2.method_7947(), stack1.method_7947());
                if ( result != 0 )
                {
                    return result;
                }

                return Integer.compare(class_7923.field_41178.method_10206(stack1.method_7909()), class_7923.field_41178.method_10206(stack2.method_7909()));
            }
            else if (method.equals(SortingMethod.CATEGORY_RARITY) || method.equals(SortingMethod.ITEM_RARITY))
            {
                // Sort by Item Rarity
                int result = stack1.method_7932().compareTo(stack2.method_7932());
                if ( result != 0 )
                {
                    return result;
                }

                return Integer.compare(class_7923.field_41178.method_10206(stack1.method_7909()), class_7923.field_41178.method_10206(stack2.method_7909()));
            }
            else
            {
                // Sort by Item RawID
                return Integer.compare(class_7923.field_41178.method_10206(stack1.method_7909()), class_7923.field_41178.method_10206(stack2.method_7909()));
            }
        }
        if (areStacksEqual(stack1, stack2) == false)
        {
            // Sort's Data Components by Hash Code
            return Integer.compare(stack1.method_57353().hashCode(), stack2.method_57353().hashCode());
        }

        return Integer.compare(stack2.method_7947(), stack1.method_7947());
    }

    private static int getCustomPriority(class_1799 stack)
    {
        if (stack == null || stack.method_7960())
        {
            // No priority for empty stacks
            return -1;
        }

        // Get item ID and name to check against custom priority lists
        String itemID = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        String itemName = stack.method_7964().getString();

        if (itemID.equals(itemName))
        {
            itemName = null;
        }

        // Top priority check
        int idTopPriority = topSortingPriorityList.indexOf(itemID);
        int nameTopPriority = itemName != null ? topSortingPriorityList.indexOf(itemName) : -1;

        // Bottom priority check
        int idBottomPriority = bottomSortingPriorityList.indexOf(itemID);
        int nameBottomPriority = itemName != null ? bottomSortingPriorityList.indexOf(itemName) : -1;

        // Sort at the top: Prefer name priority if it exists
        if (nameTopPriority != -1)
        {
            return -topSortingPriorityList.size() + nameTopPriority - 2;
        }
        if (idTopPriority != -1)
        {
            return -topSortingPriorityList.size() + idTopPriority - 2;
        }

        // Sort at the bottom: Prefer name priority if it exists
        if (nameBottomPriority != -1)
        {
            return bottomSortingPriorityList.size() + nameBottomPriority;
        }
        if (idBottomPriority != -1)
        {
            return bottomSortingPriorityList.size() + idBottomPriority;
        }

        // Default: no specific priority found
        return -1;
    }

    public static boolean onPong(class_2617 packet)
    {
        if (selectedSlotUpdateTask != null)
        {
            selectedSlotUpdateTask.run();
            selectedSlotUpdateTask = null;
            return true;
        }
        return false;
    }

    private static boolean isShulkerBox(class_1799 stack)
    {
        return stack.method_7909() instanceof class_1747 bi && bi.method_7711() instanceof class_2480;
    }

    private static boolean isEmptyShulkerBox(class_1799 stack)
    {
        return isShulkerBox(stack) && stack.method_57825(class_9334.field_49622, class_9288.field_49334).method_59712().findAny().isEmpty();
    }

    private static boolean isBundle(class_1799 stack)
    {
        return stack.method_31574(class_1802.field_27023) || stack.method_57353().method_57832(class_9334.field_49650);
    }

    private static boolean isEmptyBundle(class_1799 stack)
    {
        return isBundle(stack) && fi.dy.masa.malilib.util.InventoryUtils.bundleCountItems(stack) < 1;
    }

    public static int stackMaxSize(class_1799 stack, boolean assumeShulkerStacking)
    {
        if (stack.method_7960())
        {
            return 64;
        }

        if (assumeShulkerStacking && Configs.Generic.SORT_ASSUME_EMPTY_BOX_STACKS.getBooleanValue())
        {
            if (isEmptyShulkerBox(stack))
            {
                return 64;
            }
        }

        return stack.method_57825(class_9334.field_50071, 1);
    }

    /**
     * @return are there still items left in the original slot?
     */
    private static boolean addStackTo(class_465<? extends class_1703> gui, class_1735 slot, class_1735 target)
    {
        if (slot == null || target == null)
        {
            return false;
        }

        class_1799 stack = slot.method_7677();
        class_1799 targetStack = target.method_7677();

        if (stack.method_7960() || !class_1799.method_7984(stack, targetStack))
        {
            return !stack.method_7960();
        }

        if (targetStack.method_7960())
        {
            clickSlot(gui, slot, slot.field_7874, 0, class_1713.field_7790);
            clickSlot(gui, target, target.field_7874, 0, class_1713.field_7790);
            //System.out.printf("Moved stack from slot %d to slot %d\n", slot.id, target.id);
            //ItemScroller.printDebug("Moved stack from slot {} to slot {}", slot.id, target.id);
            return false;
        }

        int stackSize = stack.method_7947();
        int targetSize = targetStack.method_7947();
        assumeEmptyShulkerStacking = true;
        int maxSize = stackMaxSize(stack, true);
        //System.out.printf("Merging %s into %s, maxSize: %d\n", stack, targetStack, maxSize);
        //ItemScroller.printDebug("Merging {} into {}, maxSize: {}", stack, targetStack, maxSize);

        if (targetSize >= maxSize)
        {
            return true;
        }

        clickSlot(gui, slot, slot.field_7874, 0, class_1713.field_7790);
        clickSlot(gui, target, target.field_7874, 0, class_1713.field_7790);
        clickSlot(gui, slot, slot.field_7874, 0, class_1713.field_7790);
        assumeEmptyShulkerStacking = false;
        int amount = stackSize + targetSize - maxSize;

        return amount > 0;
    }

    private static void tryMergeItems(class_465<?> gui, int left, int right)
    {
        Map<ItemType, Integer> nonFullStacks = new HashMap<>();

        for (int i = left; i <= right; i++)
        {
            class_1735 slot = gui.method_17577().method_7611(i);

            if (slot.method_7681())
            {
                class_1799 stack = slot.method_7677();

                if (stack.method_7947() >= stackMaxSize(stack, true)) {
                    // ignore overstacking items.
                    continue;
                }

                ItemType key = new ItemType(stack);
                int slotNum = nonFullStacks.getOrDefault(key, -1);

                if (slotNum == -1)
                {
                    nonFullStacks.put(key, i);
                }
                else
                {
                    if (addStackTo(gui, slot, gui.method_17577().method_7611(slotNum)))
                    {
                        nonFullStacks.put(key, i);
                    }
                }
            }
        }
    }

    /*
    private static class SlotVerticalSorterSlots implements Comparator<Slot>
    {
        private final boolean topToBottom;

        public SlotVerticalSorterSlots(boolean topToBottom)
        {
            this.topToBottom = topToBottom;
        }

        @Override
        public int compare(Slot slot1, Slot slot2)
        {
            if (slot1.yPos == slot2.yPos)
            {
                return (slot1.id < slot2.id) == this.topToBottom ? -1 : 1;
            }

            return (slot1.yPos < slot2.yPos) == this.topToBottom ? -1 : 1;
        }
    }
    */

    private static class SlotVerticalSorterSlotNumbers implements IntComparator
    {
        private final class_1703 container;
        private final boolean topToBottom;

        public SlotVerticalSorterSlotNumbers(class_1703 container, boolean topToBottom)
        {
            this.container = container;
            this.topToBottom = topToBottom;
        }

        @Override
        public int compare(int slotNum1, int slotNum2)
        {
            if (Objects.equals(slotNum1, slotNum2))
            {
                return 0;
            }

            class_1735 slot1 = this.container.method_7611(slotNum1);
            class_1735 slot2 = this.container.method_7611(slotNum2);

            if (slot1.field_7872 == slot2.field_7872)
            {
                return (slot1.field_7874 < slot2.field_7874) == this.topToBottom ? -1 : 1;
            }

            return (slot1.field_7872 < slot2.field_7872) == this.topToBottom ? -1 : 1;
        }
    }

    public static void clickSlot(class_465<? extends class_1703> gui,
                                 int slotNum,
                                 int mouseButton,
                                 class_1713 type)
    {
        if (slotNum >= 0 && slotNum < gui.method_17577().field_7761.size())
        {
            class_1735 slot = gui.method_17577().method_7611(slotNum);
            clickSlot(gui, slot, slotNum, mouseButton, type);
        }
        else
        {
            try
            {
                class_310 mc = class_310.method_1551();
                mc.field_1761.method_2906(gui.method_17577().field_7763, slotNum, mouseButton, type, mc.field_1724);
            }
            catch (Exception e)
            {
                ItemScroller.LOGGER.warn("Exception while emulating a slot click: gui: '{}', slotNum: {}, mouseButton; {}, SlotActionType: {}",
                                         gui.getClass().getName(), slotNum, mouseButton, type, e);
            }
        }
    }

    public static void clickSlot(class_465<? extends class_1703> gui,
                                 class_1735 slot,
                                 int slotNum,
                                 int mouseButton,
                                 class_1713 type)
    {
        try
        {
            AccessorUtils.handleMouseClick(gui, slot, slotNum, mouseButton, type);
        }
        catch (Exception e)
        {
            ItemScroller.LOGGER.warn("Exception while emulating a slot click: gui: '{}', slotNum: {}, mouseButton; {}, SlotActionType: {}",
                                     gui.getClass().getName(), slotNum, mouseButton, type, e);
        }
    }

    public static void leftClickSlot(class_465<? extends class_1703> gui, class_1735 slot, int slotNumber)
    {
        clickSlot(gui, slot, slotNumber, 0, class_1713.field_7790);
    }

    public static void rightClickSlot(class_465<? extends class_1703> gui, class_1735 slot, int slotNumber)
    {
        clickSlot(gui, slot, slotNumber, 1, class_1713.field_7790);
    }

    public static void shiftClickSlot(class_465<? extends class_1703> gui, class_1735 slot, int slotNumber)
    {
        clickSlot(gui, slot, slotNumber, 0, class_1713.field_7794);
    }

    public static void leftClickSlot(class_465<? extends class_1703> gui, int slotNum)
    {
        clickSlot(gui, slotNum, 0, class_1713.field_7790);
    }

    public static void rightClickSlot(class_465<? extends class_1703> gui, int slotNum)
    {
        clickSlot(gui, slotNum, 1, class_1713.field_7790);
    }

    public static void shiftClickSlot(class_465<? extends class_1703> gui, int slotNum)
    {
        clickSlot(gui, slotNum, 0, class_1713.field_7794);
    }

    public static void dropItemsFromCursor(class_465<? extends class_1703> gui)
    {
        clickSlot(gui, -999, 0, class_1713.field_7790);
    }

    public static void dropItem(class_465<? extends class_1703> gui, int slotNum)
    {
        clickSlot(gui, slotNum, 0, class_1713.field_7795);
    }

    public static void dropStack(class_465<? extends class_1703> gui, int slotNum)
    {
        clickSlot(gui, slotNum, 1, class_1713.field_7795);
    }

    public static void swapSlots(class_465<? extends class_1703> gui, int slotNum, int otherSlot)
    {
        //System.out.printf("swapSlots: [%d -> %d]\n", slotNum, otherSlot);

        clickSlot(gui, slotNum, 8, class_1713.field_7791);
        clickSlot(gui, otherSlot, 8, class_1713.field_7791);
        clickSlot(gui, slotNum, 8, class_1713.field_7791);
    }

    private static void dragSplitItemsIntoSlots(class_465<? extends class_1703> gui,
                                                IntArrayList targetSlots)
    {
        class_1799 stackInCursor = gui.method_17577().method_34255();

        if (isStackEmpty(stackInCursor))
        {
            return;
        }

        if (targetSlots.size() == 1)
        {
            leftClickSlot(gui, targetSlots.getInt(0));
            return;
        }

        int numSlots = gui.method_17577().field_7761.size();

        // Start the drag
        clickSlot(gui, -999, 0, class_1713.field_7789);

        for (int slotNum : targetSlots)
        {
            if (slotNum >= numSlots)
            {
                break;
            }

            clickSlot(gui, slotNum, 1, class_1713.field_7789);
        }

        // End the drag
        clickSlot(gui, -999, 2, class_1713.field_7789);
    }

    /**************************************************************
     * Compatibility code for pre-1.11 vs. 1.11+
     * Well kind of, as in make the differences minimal,
     * only requires changing these things for the ItemStack
     * related changes.
     *************************************************************/

    public static final class_1799 EMPTY_STACK = class_1799.field_8037;

    public static boolean isStackEmpty(class_1799 stack)
    {
        return stack.method_7960();
    }

    public static int getStackSize(class_1799 stack)
    {
        return stack.method_7947();
    }

    public static void setStackSize(class_1799 stack, int size)
    {
        stack.method_7939(size);
    }

    public static class_1799 copyStack(class_1799 stack, boolean empty)
    {
        if (empty)
            return stack.method_51164();
        else
            return stack.method_7972();
    }
}
