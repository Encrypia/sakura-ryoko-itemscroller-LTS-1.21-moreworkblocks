package fi.dy.masa.itemscroller.util;

import java.util.Collection;
import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import com.google.common.collect.ImmutableList;
import fi.dy.masa.malilib.config.IConfigLockedListEntry;
import fi.dy.masa.malilib.config.IConfigLockedListType;
import fi.dy.masa.malilib.util.StringUtils;
import fi.dy.masa.itemscroller.Reference;

public class SortingCategory implements IConfigLockedListType
{
    public static final SortingCategory INSTANCE = new SortingCategory();
    public ImmutableList<Entry> VALUES = ImmutableList.copyOf(Entry.values());

    @Nullable
    public class_1761.class_8128 buildDisplayContext(class_310 mc)
    {
        if (mc.field_1687 == null)
        {
            return null;
        }

        class_1761.class_8128 ctx = new class_1761.class_8128(mc.field_1687.method_45162(), true, mc.field_1687.method_30349());

        class_7923.field_44687.method_10220().filter((group) ->
                group.method_47312() == class_1761.class_7916.field_41052).forEach((group) ->
                group.method_47306(ctx));

        return ctx;
    }

    public Entry fromItemStack(class_1799 stack)
    {
        for (int i = 0; i < class_7923.field_44687.method_10204(); i++)
        {
            class_1761 itemGroup = class_7923.field_44687.method_10200(i);

            if (itemGroup != null && itemGroup.method_47312().equals(class_1761.class_7916.field_41052))
            {
                Collection<class_1799> stacks;
                Iterator<class_1799> iter;

                if (itemGroup.method_47310())
                {
                    stacks = itemGroup.method_47313();
                    iter = stacks.iterator();

                    while (iter.hasNext())
                    {
                        if (class_1799.method_7984(iter.next(), stack))
                        {
                            return fromItemGroup(itemGroup);
                        }
                    }

                }

                stacks = itemGroup.method_45414();
                iter = stacks.iterator();

                while (iter.hasNext())
                {
                    if (class_1799.method_7984(iter.next(), stack))
                    {
                        return fromItemGroup(itemGroup);
                    }
                }

            }
        }

        return Entry.OTHER;
    }

    @Nullable
    public Entry fromItemGroup(class_1761 group)
    {
        class_2960 id = class_7923.field_44687.method_10221(group);

        if (id != null)
        {
            return Entry.fromString(id.method_12832());
        }

        return Entry.OTHER;
    }

    @Override
    public ImmutableList<IConfigLockedListEntry> getDefaultEntries()
    {
        ImmutableList.Builder<IConfigLockedListEntry> list = ImmutableList.builder();

        VALUES.forEach((list::add));

        return list.build();
    }

    @Override
    @Nullable
    public IConfigLockedListEntry fromString(String string)
    {
        return Entry.fromString(string);
    }

    public enum Entry implements IConfigLockedListEntry
    {
        BUILDING_BLOCKS     ("building_blocks",     "building_blocks"),
        COLORED_BLOCKS      ("colored_blocks",      "colored_blocks"),
        NATURAL             ("natural_blocks",      "natural_blocks"),
        FUNCTIONAL          ("functional_blocks",   "functional_blocks"),
        REDSTONE            ("redstone_blocks",     "redstone_blocks"),
        TOOLS               ("tools_and_utilities", "tools_and_utilities"),
        COMBAT              ("combat",              "combat"),
        FOOD_AND_DRINK      ("food_and_drinks",     "food_and_drinks"),
        INGREDIENTS         ("ingredients",         "ingredients"),
        SPAWN_EGGS          ("spawn_eggs",          "spawn_eggs"),
        OPERATOR            ("op_blocks",           "op_blocks"),
        OTHER               ("other",               "other");

        private final String configKey;
        private final String translationKey;

        Entry(String configKey, String translationKey)
        {
            this.configKey = configKey;
            this.translationKey = Reference.MOD_ID+".gui.label.sorting_category."+translationKey;
        }

        @Override
        public String getStringValue()
        {
            return this.configKey;
        }

        @Override
        public String getDisplayName()
        {
            return StringUtils.getTranslatedOrFallback(this.translationKey, this.configKey);
        }

        @Nullable
        public static Entry fromString(String key)
        {
            for (Entry entry : values())
            {
                if (entry.configKey.equalsIgnoreCase(key))
                {
                    return entry;
                }
                else if (entry.translationKey.equalsIgnoreCase(key))
                {
                    return entry;
                }
                else if (StringUtils.hasTranslation(entry.translationKey) && StringUtils.translate(entry.translationKey).equalsIgnoreCase(key))
                {
                    return entry;
                }
            }

            return null;
        }
    }
}
