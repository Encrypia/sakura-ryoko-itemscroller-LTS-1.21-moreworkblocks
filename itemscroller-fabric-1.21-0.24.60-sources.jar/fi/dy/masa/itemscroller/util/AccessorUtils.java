package fi.dy.masa.itemscroller.util;

import javax.annotation.Nullable;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_465;
import net.minecraft.class_492;
import fi.dy.masa.itemscroller.mixin.screen.IMixinMerchantScreen;
import fi.dy.masa.itemscroller.mixin.screen.IMixinScreenWithHandler;
import fi.dy.masa.itemscroller.mixin.item.IMixinSlot;

public class AccessorUtils
{
    @Nullable
    public static class_1735 getSlotUnderMouse(class_465<?> gui)
    {
        return ((IMixinScreenWithHandler) gui).itemscroller_getHoveredSlot();
    }

    @Nullable
    public static class_1735 getSlotAtPosition(class_465<?> gui, int x, int y)
    {
        return ((IMixinScreenWithHandler) gui).itemscroller_getSlotAtPositionInvoker(x, y);
    }

    public static void handleMouseClick(class_465<?> gui, class_1735 slotIn, int slotId, int mouseButton, class_1713 type)
    {
        ((IMixinScreenWithHandler) gui).itemscroller_handleMouseClickInvoker(slotIn, slotId, mouseButton, type);
    }

    public static int getGuiLeft(class_465<?> gui)
    {
        return ((IMixinScreenWithHandler) gui).itemscroller_getGuiLeft();
    }

    public static int getGuiTop(class_465<?> gui)
    {
        return ((IMixinScreenWithHandler) gui).itemscroller_getGuiTop();
    }

    public static int getGuiXSize(class_465<?> gui)
    {
        return ((IMixinScreenWithHandler) gui).itemscroller_getBackgroundWidth();
    }

    public static int getGuiYSize(class_465<?> gui)
    {
        return ((IMixinScreenWithHandler) gui).itemscroller_getBackgroundHeight();
    }

    public static int getSelectedMerchantRecipe(class_492 gui)
    {
        return ((IMixinMerchantScreen) gui).itemscroller_getSelectedMerchantRecipe();
    }

    public static int getSlotIndex(class_1735 slot)
    {
        return ((IMixinSlot) slot).itemscroller_getSlotIndex();
    }
}
