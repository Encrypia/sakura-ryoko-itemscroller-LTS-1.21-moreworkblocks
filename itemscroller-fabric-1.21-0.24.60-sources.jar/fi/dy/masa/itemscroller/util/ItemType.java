package fi.dy.masa.itemscroller.util;

import javax.annotation.Nonnull;
import net.minecraft.class_1799;
import java.util.HashMap;
import java.util.Map;
import it.unimi.dsi.fastutil.ints.IntArrayList;

/**
 * Wrapper class for ItemStack, which implements equals()
 * for the item, damage and NBT, but not stackSize.
 */
public record ItemType(class_1799 stack)
{
    public ItemType(@Nonnull class_1799 stack)
    {
        this.stack = stack.method_7960() ? InventoryUtils.EMPTY_STACK : InventoryUtils.copyStack(stack, false);
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        //result = prime * result + ((stack == null) ? 0 : stack.hashCode());
        result = prime * result + this.stack.method_7909().hashCode();
        result = prime * result + (this.stack.method_57353() != null ? this.stack.method_57353().hashCode() : 0);
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (this.getClass() != obj.getClass())
            return false;

        ItemType other = (ItemType) obj;

        return class_1799.method_31577(this.stack, other.stack);
    }

    /**
     * Returns a map that has a list of the indices for each different item in the input list
     *
     * @param stacks
     * @return
     */
    public static Map<ItemType, IntArrayList> getSlotsPerItem(class_1799[] stacks)
    {
        Map<ItemType, IntArrayList> mapSlots = new HashMap<>();

        for (int i = 0; i < stacks.length; i++)
        {
            class_1799 stack = stacks[i];

            if (InventoryUtils.isStackEmpty(stack) == false)
            {
                ItemType item = new ItemType(stack);
                IntArrayList slots = mapSlots.computeIfAbsent(item, k -> new IntArrayList());

                slots.add(i);
            }
        }

        return mapSlots;
    }
}
